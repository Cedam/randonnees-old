# Getting Started

0) Prérequis
  installation de la JDK 8 ou version supérieur (privilégier la JDK 11 pour utilisation de HTTP/2)
  installation de maven 3 (il est possible d'utiliser la version fournie dans Eclipse)
  installer Node.js 12
  installer yarn 1.21
  
1) Maven : ajouter et compléter le fichier .settings.xml dans le répertoire .m2 du repertoire utilisateur

2) Modifier le répertoire de cache de yarn (C:\Apps\yarn\repository par exemple)
  yarn config set cache-folder <path>
  référence : https://yarnpkg.com/fr/docs/cli/cache#toc-change-the-cache-path-for-yarn

3) Eclipse
  configurer les versions pour le jdk et maven
  configurer l'encodage en UTF-8
  configurer le formatteur


Notes:
- commande pour la generation d'un certificat auto-signé pour utiliser TLS (exemple mot de passe : password)
  keytool -genkeypair -alias <nom_projet> -keyalg RSA -keysize 2048 -storetype PKCS12 -keystore <nom_projet>.p12 -validity 36500

- lancement du backend en standalone
  java -jar <jar_name>.jar

- tâches à réaliser
   gestion de la traduction par défaut du message du BasicController
   ajout swagger
   mettre à jour la version du pom.xml avec le init.sh

- points à documenter :
   utilisation lombok
   gestion de la sécurité (https, cors, ...)
   gestion de la locale et traduction avec messages.properties
   gestion des exceptions, notamment runtime
   connexion à la base de données
   génération des scripts de bdd et versionning
   gestion de l'authentification
   gestion des logs + LoggingAspect
   swagger
   déploiement sur un environnement
   packaging du front et mise à disposition par le back


### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.2.1.RELEASE/maven-plugin/)
* [Spring Security](https://docs.spring.io/spring-boot/docs/2.2.1.RELEASE/reference/htmlsingle/#boot-features-security)
* [Spring Data JPA](https://docs.spring.io/spring-boot/docs/2.2.1.RELEASE/reference/htmlsingle/#boot-features-jpa-and-spring-data)
* [Spring LDAP](https://docs.spring.io/spring-boot/docs/2.2.1.RELEASE/reference/htmlsingle/#boot-features-ldap)
* [Spring Boot Actuator](https://docs.spring.io/spring-boot/docs/2.2.1.RELEASE/reference/htmlsingle/#production-ready)
* [Spring Web](https://docs.spring.io/spring-boot/docs/2.2.1.RELEASE/reference/htmlsingle/#boot-features-developing-web-applications)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/docs/2.2.1.RELEASE/reference/htmlsingle/#using-boot-devtools)
* [Spring Configuration Processor](https://docs.spring.io/spring-boot/docs/2.2.1.RELEASE/reference/htmlsingle/#configuration-metadata-annotation-processor)

### Guides
The following guides illustrate how to use some features concretely:

* [Securing a Web Application](https://spring.io/guides/gs/securing-web/)
* [Spring Boot and OAuth2](https://spring.io/guides/tutorials/spring-boot-oauth2/)
* [Authenticating a User with LDAP](https://spring.io/guides/gs/authenticating-ldap/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Building a RESTful Web Service with Spring Boot Actuator](https://spring.io/guides/gs/actuator-service/)
* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)
* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/bookmarks/)

