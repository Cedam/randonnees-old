INSERT INTO AUTHORITY (AUT_ID, AUT_NAME)
VALUES (1, 'ROLE_ADMIN'),
       (2, 'ROLE_SYSTEM'),
       (10, 'ROLE_SUPPLY'),
       (11, 'ROLE_ADMIN_SUPPLY'),
       (30, 'ROLE_PUB'),
       (31, 'ROLE_ADMIN_PUB'),
       (40, 'ROLE_EXPENSE'),
       (41, 'ROLE_ADMIN_EXPENSE');


-- default password is "admin" for admin user
INSERT INTO USER(USR_ID, USR_USER_NAME, USR_PASSWORD, USR_FIRST_NAME, USR_LAST_NAME, USR_IS_ENABLED)
VALUES (1, 'admin', '$2a$10$6g8kTaoxPvkNcHRiI.GFAegiNuGjKXnnx5jJEPIbp3XCBvBe91jM.', 'Admin', 'User', 1);

INSERT INTO USER2AUTHORITY (USR_ID, AUT_ID)
VALUES (1, 1);

-- default password is "system" for system user
INSERT INTO USER(USR_ID, USR_USER_NAME, USR_PASSWORD, USR_FIRST_NAME, USR_LAST_NAME, USR_IS_ENABLED)
VALUES (2, 'system', '$2a$10$ylRNvnwyT04jMHzxzp2qrO9ryPhHbH.8NRACbQjdbyUOb5Kk.bDi.', 'System', 'User', 0);

INSERT INTO USER2AUTHORITY (USR_ID, AUT_ID)
VALUES (2, 2);

-- default password is "super_admin" for super_admin user
INSERT INTO USER(USR_ID, USR_USER_NAME, USR_PASSWORD, USR_FIRST_NAME, USR_LAST_NAME, USR_IS_ENABLED)
VALUES (3, 'super_admin', '$2y$12$6qqMhe0Qw5Y4OrOSwkRqc.jwLjoWCbfFuD6/R/rUJ2zi.KcEXRpZO', 'Super', 'Admin', 1);

INSERT INTO USER2AUTHORITY (USR_ID, AUT_ID)
VALUES (3, 1),
       (3, 11),
       (3, 31),
       (3, 41);
