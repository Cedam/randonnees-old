SET @username = 'anthony';

USE mon_agence;


-- PREMIERE REQUETE POUR RECUPERER L'ID DE L'UTILISATEUR
SELECT USR_ID
FROM user
WHERE USR_USER_NAME = @username;


-- SET L'ID USER POUR QUE LES REQUETES SUIVANTES POUR S'EFFECTUER
SET @user_id = 41;


-- DEBUT DES REQUETES UTILISANT L'ID USER POUR RECUPERER TOUTES SES DONNEES
SELECT USR_FIRST_NAME, USR_LAST_NAME, USR_USER_NAME, EMPI_AGENCY, EMPI_CUSTOMER, EMPI_LICENCE_PLATE,
       EMPI_OPERATION_CODE, EMPI_SERIAL_NUMBER, COMP_MILEAGE_ALLOWANCE
FROM user
JOIN employee_identity ON user.usr_id = employee_identity.empi_id
JOIN compensation ON employee_identity.empi_compensation = compensation.comp_id
WHERE user.usr_id = @user_id;


SELECT GR_CREATION_DATE, GR_MONTH
FROM generated_report
WHERE generated_report.empi_id = @user_id;


SELECT TIK_DATE_ARCHIVED, TIK_CODE, TIK_CREATION_DATE, TIK_IS_VALID, TCMC_COMPANY_AMOUNT, TCMC_CUSTOMER,
       TCMC_EMPLOYEE_AMOUNT
FROM ticket
JOIN ticket_customer_meal_cost ON ticket_customer_meal_cost.tik_id = ticket.tik_id
WHERE ticket.empi_id = @user_id;


SELECT TIK_DATE_ARCHIVED, TIK_CODE, TIK_CREATION_DATE, TIK_IS_VALID, TEBT_COMPANY_AMOUNT, TEBT_CUSTOMER,
       TEBT_VEHICLE, place_start.PLA_NAME, place_end.PLA_NAME
FROM ticket
JOIN ticket_exceptional_business_travel ON ticket_exceptional_business_travel.tik_id = ticket.tik_id
JOIN place as place_start ON place_start.PLA_ID = PLA_START_ID
JOIN place as place_end ON place_end.PLA_ID = PLA_END_ID
WHERE ticket.empi_id = @user_id;


SELECT TIK_DATE_ARCHIVED, TIK_CODE, TIK_CREATION_DATE, TIK_IS_VALID, TVC_COMPANY_AMOUNT, TVC_CUSTOMER,
       TVC_EMPLOYEE_AMOUNT, TVC_PURPOSE
FROM ticket
JOIN ticket_various_cost ON ticket_various_cost.tik_id = ticket.tik_id
WHERE ticket.empi_id = @user_id;


SELECT TIK_DATE_ARCHIVED, TIK_CODE, TIK_CREATION_DATE, TIK_IS_VALID, TVBT_COMPANY_AMOUNT, TVBT_CUSTOMER,
       TVBT_EMPLOYEE_AMOUNT, TVBT_PURPOSE
FROM ticket
JOIN ticket_various_business_travel ON ticket_various_business_travel.tik_id = ticket.tik_id
WHERE ticket.empi_id = @user_id;


SELECT TIK_DATE_ARCHIVED, TIK_CODE, TIK_CREATION_DATE, TIK_IS_VALID, TSMC_COMPANY_AMOUNT,
       TSMC_EMPLOYEE_AMOUNT, TSMC_SITE_MEETING
FROM ticket
JOIN ticket_site_meal_cost ON ticket_site_meal_cost.tik_id = ticket.tik_id
WHERE ticket.empi_id = @user_id;


SELECT TIK_DATE_ARCHIVED, TIK_CODE, TIK_CREATION_DATE, TIK_IS_VALID, TFU_COMPANY_AMOUNT,
       TFU_CUSTOMER, TFU_EMPLOYEE_AMOUNT, TFU_PURPOSE
FROM ticket
JOIN ticket_fuel ON ticket_fuel.tik_id = ticket.tik_id
WHERE ticket.empi_id = @user_id;


SELECT TIK_DATE_ARCHIVED, TIK_CODE, TIK_CREATION_DATE, TIK_IS_VALID, TLMB_BEDROOM_AMOUNT,
       TLMB_BREAKFAST_AMOUNT, TLMB_COMPANY_AMOUNT, TLMB_CUSTOMER, TLMB_DINNER_AMOUNT, TLMB_LUNCH_AMOUNT
FROM ticket
JOIN ticket_lodging_meal_business ON ticket_lodging_meal_business.tik_id = ticket.tik_id
WHERE ticket.empi_id = @user_id;