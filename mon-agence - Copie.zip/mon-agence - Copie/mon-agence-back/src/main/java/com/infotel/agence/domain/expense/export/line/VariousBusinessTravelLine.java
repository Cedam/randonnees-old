package com.infotel.agence.domain.expense.export.line;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Cette classe permet le stockage d'une ligne du tableau "Frais divers liés au déplacement" présent dans la feuille
 * "Déplacement Commerciaux Ouest".
 *
 * @author arob
 */
@Setter
@Getter
public class VariousBusinessTravelLine extends AbstractLine {
    private LocalDate date;
    private String purpose;
    private String customer;
    private BigDecimal employeeAmount;
    private BigDecimal companyAmount;

    public VariousBusinessTravelLine() {
        super(2, 5);
    }
}
