package com.infotel.agence.service.expense.impl.report.pdf;

import com.infotel.agence.domain.expense.ticket.Ticket;
import com.infotel.agence.domain.expense.ticket.TicketCode;
import com.infotel.agence.exception.TechnicalException;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.lang.NonNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Cette classe permet l'ouverture, l'écriture et la sauvegarde d'un fichier pdf gérant les images des notes de frais.
 *
 * @author arob
 */
public class PdfFileGenerator {
    private final PDDocument document;
    private Map<TicketCode, InputStream> pdfSeparatorInputStream;

    public PdfFileGenerator() {
        document = new PDDocument();
    }

    /**
     * Permets de load les images relatives aux types de tickets. Ces informations sont necessaires pour pouvoir utiliser
     * la fonctino write().
     *
     * @param pdfSeparatorFolder
     */
    public void load(@NonNull String pdfSeparatorFolder) {
        pdfSeparatorInputStream = new LinkedHashMap<>();
        ClassLoader classLoader = this.getClass().getClassLoader();

        for (TicketCode code : TicketCode.values()) {
            if (code != TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL) {
                String filename = String.format("%s%s%s", pdfSeparatorFolder, code.name(), ".png");
                InputStream inputStream = classLoader.getResourceAsStream(filename);

                if (inputStream == null) {
                    throw new TechnicalException("Le fichier {} est introuvable. Impossible de continuer la génération.", filename);
                }
                pdfSeparatorInputStream.put(code, inputStream);
            }
        }
    }

    /**
     * Permets d'écrire les images des tickets dans le document PDF.
     *
     * @param data
     * @throws IOException
     */
    public void write(@NonNull Map<TicketCode, List<Ticket>> data) throws IOException {
        for (Map.Entry<TicketCode, List<Ticket>> entry : data.entrySet()) {
            final TicketCode code = entry.getKey();
            final List<Ticket> tickets = entry.getValue();

            // Si le type != "EXCEPTIONAl_BUSINESS_TRAVEL" et que des images sont à traiter
            if (!code.equals(TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL) && CollectionUtils.isNotEmpty(tickets)) {

                // Insertion de l'en-tête propre au type de ticket
                writeTicketTypeSeparator(document, code);

                for (Ticket ticket : tickets) {
                    // Insertion de l'image propre au ticket
                    writeTicketPictureInDocument(document, ticket);
                }
            }
        }
    }

    /**
     * Sauvegarde le document PDF dans l'outputStream donnée en paramètre et ferme le document.
     *
     * @param outputStream
     * @throws IOException
     */
    public void save(@NonNull OutputStream outputStream) throws IOException {
        document.save(outputStream);
        document.close();
    }

    /**
     * Permets d'écrire le séparateur propre au type de ticket donné en entrée.
     *
     * @param document
     * @param code
     * @throws IOException
     */
    private void writeTicketTypeSeparator(@NonNull PDDocument document, @NonNull TicketCode code) throws IOException {
        // On ajoute une nouvelle page contenant l'image de séparation propre au type de ticket actuel
        writePictureInDocument(document, pdfSeparatorInputStream.get(code).readAllBytes());
    }

    /**
     * Permets d'écrire l'image du ticket donné en entrée.
     *
     * @param document
     * @param ticket
     * @throws IOException
     */
    private void writeTicketPictureInDocument(@NonNull PDDocument document, @NonNull Ticket ticket) throws IOException {
        if (ticket.getReceiptPicture() != null) {
            writePictureInDocument(document, ticket.getReceiptPicture().getReceiptPicture());
        }
    }

    /**
     * Permets d'écrire le byteArray d'image donné en entrée. L'image sera centrée et redimensionner pour rentrer dans une page A4 portrait.
     *
     * @param document
     * @param byteArray
     * @throws IOException
     */
    private void writePictureInDocument(@NonNull PDDocument document, @NonNull byte[] byteArray) throws IOException {
        float pageHeight = PDRectangle.LETTER.getHeight();
        float pageWidth = PDRectangle.LETTER.getWidth();
        float pageRatio = pageWidth / pageHeight;

        PDImageXObject pdImage = PDImageXObject.createFromByteArray(document,
                byteArray,
                null);

        PDPage pdPage = new PDPage();

        try (PDPageContentStream contentStream = new PDPageContentStream(document, pdPage)) {
            // Print de la version "rationalisée" de l'image
            float imgWidth = pdImage.getWidth();
            float imgHeight = pdImage.getHeight();
            float imgRatio = imgWidth / imgHeight;

            if (imgWidth > pageWidth || imgHeight > pageHeight) {
                float wc = pdImage.getWidth() / pageWidth;

                if (imgRatio >= pageRatio) {
                    contentStream.drawImage(pdImage, 0, (pageHeight - imgHeight / wc) / 2, pageWidth, imgHeight / wc);
                } else {
                    float pi = pageRatio / imgRatio;
                    contentStream.drawImage(pdImage, (pageWidth - pageWidth / pi) / 2, 0, pageWidth / pi, (imgHeight / pi) / wc);
                }
            } else {
                contentStream.drawImage(pdImage, (pageWidth - imgWidth) / 2, (pageHeight - imgHeight) / 2, imgWidth, imgHeight);
            }
        }

        document.addPage(pdPage);
    }
}
