package com.infotel.agence.service.expense;

import com.infotel.agence.domain.expense.Place;
import com.infotel.agence.domain.expense.dto.PlaceDTO;
import com.infotel.agence.service.expense.impl.PlaceService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN_EXPENSE;
import static com.infotel.agence.security.SecurityRole.Constant.ROLE_EXPENSE;

/**
 * Interface pour le service qui gère les entités {@link PlaceService}
 *
 * @author arob
 */
public interface IPlaceService {

    /**
     * Retourne la place référencée par l'id en paramètre
     *
     * @param id id
     * @return une place
     */
    @RolesAllowed(ROLE_EXPENSE)
    Place findById(long id);

    /**
     * Retourne l'ensemble des places sous forme de list
     *
     * @return la liste des places
     */
    @RolesAllowed({ ROLE_EXPENSE, ROLE_ADMIN_EXPENSE })
    List<Place> findAllList();

    /**
     * Retourne un sous-ensemble des places sous forme de page
     *
     * @return une page des places
     */
    @RolesAllowed({ ROLE_EXPENSE, ROLE_ADMIN_EXPENSE })
    Page<Place> findAllPage(Pageable pageable);

    /**
     * Crée une nouvelle place
     *
     * @param placeDTO place
     * @return la nouvelle place
     */
    @RolesAllowed({ ROLE_EXPENSE, ROLE_ADMIN_EXPENSE })
    Place create(PlaceDTO placeDTO);

    /**
     * Met à jour une place existante
     *
     * @param id       l'id de la place existante
     * @param placeDTO place mise à jour
     * @return place mise à jour
     */
    @RolesAllowed(ROLE_EXPENSE)
    Place update(long id, PlaceDTO placeDTO);

    /**
     * Fusionne la placeA dans la placeB.
     * Tous les tickets utilisant placeA ou placeB seront modifiés à isValid=false.
     * Toutes les distances pointant vers placeA pointeront vers placeB. Si une distance existante vers placeB rentre
     * en conflit avec une des modifications, cette dernière est ignorée.
     * La placeA sera suprimée.
     *
     * @param placeIdDelete    l'id de la place qui sera supprimée
     * @param placeIdRecipient l'id de la place qui contiendra la fusion
     */
    @RolesAllowed(ROLE_ADMIN_EXPENSE)
    void merge(long placeIdDelete, long placeIdRecipient);
}
