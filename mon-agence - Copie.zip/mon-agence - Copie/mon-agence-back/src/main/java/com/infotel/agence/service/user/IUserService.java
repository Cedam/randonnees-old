package com.infotel.agence.service.user;

import com.infotel.agence.domain.user.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.lang.NonNull;
import org.springframework.security.core.userdetails.UserDetailsService;

import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;

/**
 * Interface pour le service qui gère les entités {@link User}
 *
 * @author ARLI / AROB
 */
public interface IUserService extends UserDetailsService {

    /**
     * Mise à jour du token de rafraichissement pour un user donné
     *
     * @param username     login utilisateur
     * @param refreshToken token de rafraichissement
     */
    void setRefreshToken(@NonNull String username, @NonNull String refreshToken);

    /**
     * Retourne la liste de tous les utilisateurs
     *
     * @return liste des utilisateurs
     */
    List<User> findAllList();

    /**
     * Retourne un sous-ensemble des utilisateurs sous forme de page
     *
     * @return une page des utilisateurs
     */
    @RolesAllowed(ROLE_ADMIN)
    Page<User> findAllPage(Pageable pageable);

    /**
     * Retourne l'utilisateur référencé par l'id en paramètre
     *
     * @param id id
     * @return un utilisateur
     */
    @RolesAllowed(ROLE_ADMIN)
    User findById(long id);

    /**
     * Supprime l'utilisateur referencé par l'id.
     *
     * @param id id
     */
    void deleteById(long id);
}
