package com.infotel.agence.config.locale;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;

import java.util.*;

/**
 * Configuration to manage internationalization.
 *
 * @author ARLI
 * @see <a href="https://www.baeldung.com/spring-boot-internationalization">https://www.baeldung.com/spring-boot-internationalization</a>
 */
@Configuration
public class LocaleConfiguration implements WebMvcConfigurer {

    /**
     * Allow to set the locale in use from the data sent by the client.
     */
    @Bean
    public LocaleResolver localeResolver() {
        CookieLocaleResolver cookieLocaleResolver = new CookieLocaleResolver();
        cookieLocaleResolver.setCookieName("NG_TRANSLATE_LANG_KEY");
        cookieLocaleResolver.setDefaultLocale(Locale.FRANCE);
        return cookieLocaleResolver;
    }

    /**
     * Interceptor to switch the locale if the parameter lang is set.
     */
    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor() {
        LocaleChangeInterceptor lci = new LocaleChangeInterceptor();
        lci.setParamName("lang");
        return lci;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(localeChangeInterceptor());
    }
}
