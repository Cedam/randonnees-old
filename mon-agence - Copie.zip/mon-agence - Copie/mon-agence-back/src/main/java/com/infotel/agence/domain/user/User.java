package com.infotel.agence.domain.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.infotel.agence.domain.Resource;
import lombok.*;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Set;

/**
 * Entité Utilisateur
 *
 * @author ARLI
 */
@Entity
@Data
@Builder
@Table(name = "USER", uniqueConstraints = @UniqueConstraint(columnNames = { "USR_USER_NAME" }, name = "UC_USER_NAME"))
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@ToString(exclude = { "password", "refreshToken" })
@Generated
public class User implements UserDetails, Resource {

    private static final long serialVersionUID = 8549504809592270427L;

    /**
     * Id de l'utilisateur
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USR_ID")
    private Long id;

    /**
     * Login de l'utilisateur
     */
    @NotNull(message = "Le login est obligatoire")
    @Size(min = 4, max = 255, message = "Le login doit être compris entre 4 et 255 caractères")
    @Column(name = "USR_USER_NAME")
    private String username;

    /**
     * Mot de passe de l'utilisateur
     */
    @JsonIgnore
    @NotNull(message = "Le mot de passe est obligatoire")
    @Size(max = 255, message = "Le mot de passe ne doit pas dépasser 255 caractères")
    @Column(name = "USR_PASSWORD")
    private String password;

    /**
     * Nom de l'utilisateur
     */
    @NotNull(message = "Le nom de famille est obligatoire")
    @Size(max = 255, message = "Le nom de famille ne doit pas dépasser 255 caractères")
    @Column(name = "USR_LAST_NAME")
    private String lastname;

    /**
     * Prénom de l'utilisateur
     */
    @NotNull(message = "Le prénom est obligatoire")
    @Size(max = 255, message = "Le prénom ne doit pas dépasser 255 caractères")
    @Column(name = "USR_FIRST_NAME")
    private String firstname;

    /**
     * Autorisations de l'utilisateur
     */
    // @formatter:off
    @NotEmpty(message = "L'utilisateur ne possède pas d'autorisations")
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "USER2AUTHORITY",
        joinColumns = { @JoinColumn(name = "USR_ID") },
        inverseJoinColumns = { @JoinColumn(name = "AUT_ID") },
        foreignKey = @ForeignKey(name = "FK_USER2AUTHORITY_USER"),
        inverseForeignKey = @ForeignKey(name = "FK_USER2AUTHORITY_AUTHORITY"),
        indexes = {
            @Index(name = "IDX_USER2AUTHORITY_USRID", columnList = "USR_ID"),
            @Index(name = "IDX_USER2AUTHORITY_AUTID", columnList = "AUT_ID")
        })
    // @formatter:on
    private Set<Authority> authorities;

    /**
     * Vrai si le user est actif
     */
    @NotNull
    @JsonIgnore
    @Column(name = "USR_IS_ENABLED")
    private boolean enabled;

    /**
     * Token pour le rafraichissement de la session
     */
    @JsonIgnore
    @Column(name = "USR_REFRESH_TOKEN")
    private String refreshToken;

    public User(final String username, final String password, final String lastname, final String firstname, final Authority... authorities) {
        this.username = username;
        this.password = password;
        this.lastname = lastname;
        this.firstname = firstname;
        this.authorities = Set.of(authorities);
        this.enabled = true;
    }

    @JsonIgnore
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @JsonIgnore
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @JsonIgnore
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

}
