package com.infotel.agence.service.expense.impl.report.excel.writer;

import com.infotel.agence.domain.expense.export.line.VariousBusinessTravelLine;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.lang.NonNull;

import java.util.Map;
import java.util.function.Function;

import static com.infotel.agence.service.expense.impl.report.excel.ExcelFileGenerator.SHEET_EXCEPTIONAL_BUSINESS_TRAVEL;

/**
 * Implémentation spécifique à l'écriture des données liées au tableau "Frais divers liés au déplacement" présent dans la feuille "Déplacement Commerciaux Ouest".
 *
 * @author arob
 */
public class VariousBusinessTravelChartWriter extends AbstractChartWriter<VariousBusinessTravelLine> {
    private static final Map<Integer, Function<VariousBusinessTravelLine, ?>> BINDING = Map.of(
            1, VariousBusinessTravelLine::getDate,
            2, VariousBusinessTravelLine::getPurpose,
            6, VariousBusinessTravelLine::getCustomer,
            7, VariousBusinessTravelLine::getEmployeeAmount,
            8, VariousBusinessTravelLine::getCompanyAmount
    );

    public VariousBusinessTravelChartWriter(XSSFWorkbook workbook) {
        super(workbook);
    }

    @Override
    protected int getLineOffset() {
        return 5;
    }

    @Override
    protected Map<Integer, Function<VariousBusinessTravelLine, ?>> getExtractorsByColumn() {
        return BINDING;
    }

    @Override
    protected XSSFSheet getTargetSheet() {
        return getSheet(SHEET_EXCEPTIONAL_BUSINESS_TRAVEL);
    }

    @Override
    protected void fillFormula(@NonNull Row row, int startRow, int rowNb) {
        fillOneSumFormula(row.getCell(7), "H", startRow + 1, rowNb + 1);
        fillOneSumFormula(row.getCell(8), "I", startRow + 1, rowNb + 1);
    }
}
