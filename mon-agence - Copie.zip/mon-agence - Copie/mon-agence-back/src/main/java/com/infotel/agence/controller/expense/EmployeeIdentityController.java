package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.service.expense.IEmployeeIdentityService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.ResponseEntity.ok;

/**
 * Controleur pour la gestion des {@link EmployeeIdentity}
 *
 * @author arob
 */
@RestController
@RequestMapping(value = "/api/employeeIdentities", produces = APPLICATION_JSON_VALUE)
public class EmployeeIdentityController {

    private final IEmployeeIdentityService employeeIdentityService;

    public EmployeeIdentityController(IEmployeeIdentityService employeeIdentityService) {
        this.employeeIdentityService = employeeIdentityService;
    }

    /**
     * Retourne l'identité employé de l'user actuellement connecté
     *
     * @return l'identité de l'employé
     */
    @GetMapping("")
    public ResponseEntity<EmployeeIdentity> findEmployeeIdentity() {
        return ok(employeeIdentityService.findCurrent());
    }
}
