package com.infotel.agence.controller.user;

import com.infotel.agence.domain.user.User;
import com.infotel.agence.service.user.IUserService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.*;

import static org.springframework.http.ResponseEntity.noContent;
import static org.springframework.http.ResponseEntity.ok;

/**
 * Controleur pour la gestion des utilisateurs
 *
 * @author ARLI / AROB
 */
@Controller
@RequestMapping(value = "api/users", produces = MediaType.APPLICATION_JSON_VALUE)
public class UserController {

    private final IUserService userService;

    public UserController(IUserService userService) {
        this.userService = userService;
    }

    /**
     * Retourne la liste de tous les utilisateurs
     *
     * @return liste des utilisateurs
     */
    @GetMapping("/all")
    public ResponseEntity<List<User>> findAllUsersList() {
        return ok(userService.findAllList());
    }

    /**
     * Retourne la page contenant une partie des utilisateurs
     *
     * @return un sous-ensemble des utilisateurs
     */
    @GetMapping("")
    public ResponseEntity<Page<User>> findAllUsersPage(Pageable pageable) {
        return ok(userService.findAllPage(pageable));
    }

    /**
     * Retourne l'utilisateur référencé par l'id en paramètre
     *
     * @param id id
     * @return user
     */
    @GetMapping("/{id}")
    public ResponseEntity<User> findUserById(@PathVariable long id) {
        return ok(userService.findById(id));
    }

    /**
     * Supprime l'utilisateur référencé par l'id en paramètre.
     * Si l'id passé en paramètre est celui de l'utilisateur connecté, aucune suppression n'est effectuée.
     *
     * @param id id
     * @return void
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable long id) {
        userService.deleteById(id);
        return noContent().build();
    }
}
