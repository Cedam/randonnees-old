package com.infotel.agence.service.expense;

import com.infotel.agence.domain.expense.dto.TicketDTO;
import com.infotel.agence.domain.expense.dto.TicketStatisticsDTO;
import com.infotel.agence.domain.expense.ticket.Ticket;
import com.infotel.agence.domain.expense.ticket.TicketCode;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import javax.annotation.security.RolesAllowed;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static com.infotel.agence.security.SecurityRole.Constant.*;

/**
 * Interface pour le service qui gère les entités {@link Ticket}
 *
 * @author arob
 */
public interface ITicketService {

    /**
     * Retourne le ticket référencé par l'id en paramètre
     *
     * @param id id
     * @return un ticket
     */
    @RolesAllowed(ROLE_EXPENSE)
    Ticket findById(long id);

    /**
     * Retourne l'ensemble des tickets
     *
     * @param pageable   objet Pageable
     * @param ticketCode objet TicketCode du ticket afin de filtrer les tickets
     * @param startDate  date de début afin de filtrer les tickets
     * @param endDate    date de fin afin de filtrer les tickets
     * @param isArchived archivé accepté ou non afin de filtrer les tickets
     * @return une page contenant l'ensemble des tickets
     */
    @RolesAllowed(ROLE_EXPENSE)
    Page<Ticket> findAll(Pageable pageable, TicketCode ticketCode, LocalDate startDate, LocalDate endDate, Boolean isArchived);

    /**
     * Retourne l'ensemble des tickets nécessaire pour proceder à de la validation
     *
     * @return liste de tickets
     */
    @RolesAllowed(ROLE_EXPENSE)
    List<Ticket> findAllToVerify();

    /**
     * Retourne l'ensemble des tickets nécessaire pour proceder à une generation de note de frais
     *
     * @param startDate
     * @param endDate
     * @return une page contenant l'ensemble des tickets
     */
    @RolesAllowed(ROLE_EXPENSE)
    Map<TicketCode, List<Ticket>> findAllToGenerate(LocalDate startDate, LocalDate endDate);

    /**
     * Supprime le ticket référencé par l'id en paramètre
     *
     * @param id id
     */
    @RolesAllowed(ROLE_EXPENSE)
    void deleteById(long id);

    /**
     * Supprimer tous les tickets de l'utilisateur référencé par l'id en paramètre
     *
     * @param userId l'id de l'utilisateur dont il faut supprimer les tickets
     */
    @RolesAllowed(ROLE_ADMIN)
    void deleteAllOfUser(long userId);

    /**
     * Crée un nouveau ticket
     *
     * @param ticketDTO ticketDTO
     * @return le nouveau ticket
     */
    @RolesAllowed(ROLE_EXPENSE)
    Ticket create(TicketDTO ticketDTO);

    /**
     * Met à jour un ticket existant
     *
     * @param ticketDTO ticketDTO
     * @return ticket mis à jour
     */
    @RolesAllowed(ROLE_EXPENSE)
    Ticket update(long id, TicketDTO ticketDTO);

    /**
     * Permet de récuperer la date du ticket (non-archivé) le plus ancien ainsi que la date du ticket (non-archivé) du ticket le plus récent.
     *
     * @return une paire de date : une map de date : {"olderDate": LocalDate la plus ancienne, "youngerDate": LocalDate la plus récente}
     */
    @RolesAllowed(ROLE_EXPENSE)
    Map<String, LocalDate> getLimits();

    /**
     * Permets de récuperer les sommes pour chaque type de ticket ainsi qu'un total pour l'utilisateur connecté.
     * Seul les tickets validés et non archivés sont considérés.
     *
     * @param startDate Date de début de la période à considerer
     * @param endDate   Date de fin de la période à considerer
     * @return Un dictionnaire contenant pour chaque type de ticket (TicketCode), ses statistiques (TicketStatisticsDTO).
     */
    @RolesAllowed(ROLE_EXPENSE)
    Map<TicketCode, TicketStatisticsDTO> statistics(LocalDate startDate, LocalDate endDate);

    /**
     * Permets de valider ou dévalider le ticket ayant l'id passé en paramètre.
     *
     * @param ticketId Id du ticket à valider.
     * @param valid    état voulu pour le paramètre valid du ticket
     * @return Le ticket mis à jour.
     */
    @RolesAllowed(ROLE_EXPENSE)
    Ticket updateValidity(long ticketId, boolean valid);

    /**
     * Permets d'archiver (archived=true) les tickets présent dans l'interval de temps passé en paramètres.
     *
     * @param startDate date de début des tickets à archiver.
     * @param endDate   date de fin des tickets à archiver.
     */
    @RolesAllowed(ROLE_EXPENSE)
    void archiveTicketBetween(LocalDate startDate, LocalDate endDate);

    /**
     * Fonction appelée afin de supprimer tous les tickets plus anciens que la date en paramètre et étant archivés.
     *
     * @param date
     */
    @RolesAllowed(ROLE_SYSTEM)
    void deleteTicketsOlderThan(LocalDate date);
}
