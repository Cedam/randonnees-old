package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.domain.expense.GeneratedReport;
import com.infotel.agence.domain.expense.dto.GeneratedReportDTO;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.repository.expense.GeneratedReportRepository;
import com.infotel.agence.security.SecurityUtils;
import com.infotel.agence.service.expense.IEmployeeIdentityService;
import com.infotel.agence.service.expense.IGeneratedReportService;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.io.*;
import java.time.*;
import java.time.format.*;
import java.util.*;

/**
 * Service qui gère les entités {@link GeneratedReport}
 *
 * @author arob
 */
@Service
@Log4j2
public class GeneratedReportService implements IGeneratedReportService {
    public static final String NON_NULL_REPORT = "Le rapport doit être non-null !";
    public static final String UNKNOWN_REPORT = "Aucune archive n''est référencée par l''id {0}.";
    public static final String NULL_DATE_DELETE_OLDER = "La date de suppression doit être différente de nulle.";

    private final GeneratedReportRepository generatedReportRepository;

    private final IEmployeeIdentityService employeeIdentityService;

    public GeneratedReportService(final GeneratedReportRepository generatedReportRepository,
                                  final IEmployeeIdentityService employeeIdentityService) {
        this.generatedReportRepository = generatedReportRepository;
        this.employeeIdentityService = employeeIdentityService;
    }

    @Override
    public GeneratedReport create(GeneratedReport generatedReport) {
        if (generatedReport == null) {
            throw new TechnicalException(NON_NULL_REPORT);
        }

        return generatedReportRepository.save(generatedReport);
    }

    @Override
    public List<GeneratedReportDTO> findAllList() {
        return generatedReportRepository.findAllGeneratedReportDTO(SecurityUtils.getCurrentUserId());
    }

    @Override
    public void findPdfFileOfId(long id, OutputStream outputStream) throws IOException {
        if (generatedReportRepository.existsByIdForUserId(id, SecurityUtils.getCurrentUserId()) == 1) {
            outputStream.write(generatedReportRepository.findPdfFileOfId(id));
        } else {
            throw new TechnicalException(UNKNOWN_REPORT, id);
        }
    }

    @Override
    public void findXlsxFileOfId(long id, OutputStream outputStream) throws IOException {
        if (generatedReportRepository.existsByIdForUserId(id, SecurityUtils.getCurrentUserId()) == 1) {
            outputStream.write(generatedReportRepository.findXlsxFileOfId(id));
        } else {
            throw new TechnicalException(UNKNOWN_REPORT, id);
        }
    }

    @Override
    public void findZipFileOfId(long id, OutputStream outputStream) throws IOException {
        if (generatedReportRepository.existsByIdForUserId(id, SecurityUtils.getCurrentUserId()) == 1) {
            outputStream.write(generatedReportRepository.findZipFileOfId(id));
        } else {
            throw new TechnicalException(UNKNOWN_REPORT, id);
        }
    }

    @Override
    public String getFilename(long id) {
        EmployeeIdentity employeeIdentity = employeeIdentityService.findCurrent();

        GeneratedReport report = generatedReportRepository.findOneById(id);

        return String.format("%s_noteFrais_%s",
                employeeIdentity.getSerialNumber(),
                Month.of(report.getMonth()).getDisplayName(TextStyle.FULL, Locale.FRANCE));
    }

    @Override
    public void deleteGeneratedReportsOlderThan(LocalDate date) {
        if (date == null) {
            throw new BusinessException(NULL_DATE_DELETE_OLDER);
        }

        int nbDeleted = generatedReportRepository.deleteGeneratedReportsOlderThan(date);
        log.info("Suppression de {} tickets lors de la purge mensuelle automatique.", nbDeleted);
    }
}
