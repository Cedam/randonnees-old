package com.infotel.agence.service.expense;

import javax.annotation.security.RolesAllowed;
import java.io.OutputStream;
import java.time.LocalDate;
import java.util.Map;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_EXPENSE;

/**
 * Interface pour le service qui gère la génération des fichiers de comptes-rendus.
 *
 * @author arob
 */
public interface IReportGeneratorService {
    /**
     * Genere le compte rendu excel pour la période de temps donnée
     *
     * @param startDate    date de début de la période de temps à considérer
     * @param endDate      date de fin de la période de temps à considérer
     * @param filename     le nom à donner aux differents fichiers
     * @param month        mois pour lequel la note de frais est généré, compris dans l'interval [1,12]
     * @param outputStream
     */
    @RolesAllowed(ROLE_EXPENSE)
    void export(LocalDate startDate, LocalDate endDate, String filename, int month, OutputStream outputStream);

    /**
     * Permet de récuperer la date du ticket (non-archivé et validé) le plus ancien ainsi que la date du ticket (non-archivé et validé) du ticket le plus récent.
     *
     * @return une paire de date : une map de date : {"olderDate": LocalDate la plus ancienne, "youngerDate": LocalDate la plus récente}
     */
    @RolesAllowed(ROLE_EXPENSE)
    Map<String, LocalDate> getLimits();

    /**
     * Retourne le nom du fichier à generer.
     *
     * @param month mois pour lequel la note de frais est généré, compris dans l'interval [1,12]
     * @return le nom à mettre aux fichiers
     */
    @RolesAllowed(ROLE_EXPENSE)
    String getFilename(int month);
}
