package com.infotel.agence.domain.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.infotel.agence.domain.Resource;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Entité Autorisation
 *
 * @author ARLI
 */
@Entity
@Data
@Table(name = "AUTHORITY", uniqueConstraints = @UniqueConstraint(columnNames = { "AUT_NAME" }, name = "UC_AUT_NAME"))
@NoArgsConstructor
@Generated
public class Authority implements GrantedAuthority, Resource {

    private static final long serialVersionUID = -293921584837164820L;

    /**
     * Id de l'autorisation
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    @Column(name = "AUT_ID")
    private Long id;

    /**
     * Nom de l'autorisation
     */
    @NotNull
    @Size(max = 20)
    @Column(name = "AUT_NAME", length = 20)
    private String name;

    public Authority(String name) {
        this.name = name;
    }

    @JsonIgnore
    @Override
    public String getAuthority() {
        return name;
    }
}
