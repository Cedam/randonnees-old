package com.infotel.agence.controller.order;

import com.infotel.agence.domain.order.Mail;
import com.infotel.agence.service.order.IMailService;

import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.*;
import java.net.*;
import java.util.*;

import static com.infotel.agence.utils.URIUtils.buildCreatedResourceURI;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.ResponseEntity.*;

/**
 * Controleur pour la gestion des mails
 *
 * @author JUBA
 */
@RestController
@RequestMapping(value = "/api/mails", produces = APPLICATION_JSON_VALUE)
@Log4j2
public class MailController {

    private final IMailService mailService;

    public MailController(IMailService mailService) {
        this.mailService = mailService;
    }

    /**
     * Retourne le mail référencé par l'id en paramètre
     *
     * @param id id
     * @return mail
     */
    @GetMapping("/{id}")
    public ResponseEntity<Mail> findMailById(@PathVariable Long id) {
        return ok(mailService.findById(id));
    }

    /**
     * Retourne l'ensemble des mails
     *
     * @return liste des mails
     */
    @GetMapping
    public ResponseEntity<List<Mail>> findAllMails() {
        return ok(mailService.findAll());
    }

    /**
     * Créer un nouveau mail
     *
     * @param mail mail
     * @return nouveau mail
     */
    @PostMapping(value = "", consumes = APPLICATION_JSON_VALUE)// FIXME ALI restore @Valid
    public ResponseEntity<Mail> createMail(@RequestBody Mail mail, HttpServletRequest httpServletRequest) {
        Mail newMail = mailService.create(mail);
        URI location = buildCreatedResourceURI(httpServletRequest, newMail);
        return created(location).body(newMail);
    }

    /**
     * Met à jour un mail existant
     *
     * @param id   id du mail
     * @param mail mail
     * @return mail mis à jour
     */
    @PutMapping(value = "/{id}", consumes = APPLICATION_JSON_VALUE)// FIXME ALI restore @Valid
    public ResponseEntity<Mail> updateMail(@PathVariable long id, @RequestBody Mail mail) {
        return ok(mailService.update(mail));
    }

    /**
     * Supprime le mail référencé par l'id en paramètre
     *
     * @param id id
     * @return void
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMail(@PathVariable long id) {
        mailService.deleteById(id);
        return noContent().build();
    }
}
