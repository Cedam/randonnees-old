package com.infotel.agence.repository.expense;

import com.infotel.agence.domain.expense.ReceiptPicture;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * {@link ReceiptPicture} repository
 *
 * @author arob
 */
@Repository
public interface ReceiptPictureRepository extends JpaRepository<ReceiptPicture, Long> {
    Optional<ReceiptPicture> findByTicketId(long idTicket);

    void deleteByTicketId(long idTicket);
}
