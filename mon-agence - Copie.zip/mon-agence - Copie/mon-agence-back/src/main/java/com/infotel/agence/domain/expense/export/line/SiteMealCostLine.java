package com.infotel.agence.domain.expense.export.line;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Cette classe permet le stockage d'une ligne du tableau "Frais de repas chantier et réunion de travail" présent dans
 * la feuille "Frais de repas chantier".
 *
 * @author arob
 */
@Setter
@Getter
public class SiteMealCostLine extends AbstractLine {
    private LocalDate date;
    private String siteOrMeeting;
    private BigDecimal employeeAmount;
    private BigDecimal companyAmount;

    public SiteMealCostLine() {
        super(2, 4);
    }
}
