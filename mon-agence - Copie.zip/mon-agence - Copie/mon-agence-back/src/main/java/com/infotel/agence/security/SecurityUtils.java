package com.infotel.agence.security;

import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.TechnicalException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Regroupe un ensemble de fonctions utiles pour vérifier les droits de l'utilisateur courant
 *
 * @author ARLI
 */
public class SecurityUtils {

    private SecurityUtils() {
        // private constructor
    }

    /**
     * Retourne l'utilisateur courant si il existe
     *
     * @return utilisateur courant
     */
    public static Optional<User> getCurrentUser() {
        return getCurrentAuthentication().map(auth -> {
            if (auth.getPrincipal() instanceof User) {
                return (User) auth.getPrincipal();
            } else {
                return null;
            }
        });
    }

    /**
     * Retourne l'id de l'utilisateur courant si il existe
     *
     * @return l'id de l'utilisateur courant
     * @throws TechnicalException si aucun utilisateur n'est connecté
     */
    public static Long getCurrentUserId() {
        return getCurrentUser()
                .orElseThrow(() -> new TechnicalException("Aucun utilisateur connecté"))
                .getId();
    }

    /**
     * Contrôle que l'utilisateur courant possède au moins une des roles passés en paramètre
     *
     * @param roles liste des roles
     * @return true si l'utilisateur courant possède au moins un des roles
     */
    public static boolean hasCurrentUserAnyRole(final SecurityRole... roles) {
        Set<String> requiredRoles = Arrays.stream(roles)
                .map(SecurityRole::getRole)
                .collect(Collectors.toSet());

        return getCurrentAuthentication()
                .map(Authentication::getAuthorities)
                .orElse(Collections.emptySet())
                .stream()
                .anyMatch(auth -> requiredRoles.contains(auth.getAuthority()));
    }

    /**
     * Récupère le contexte d'authentification
     *
     * @return contexte d'authentification
     */
    private static Optional<Authentication> getCurrentAuthentication() {
        return Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication());
    }
}
