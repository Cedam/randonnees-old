package com.infotel.agence.domain.expense.ticket;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**
 * Entité Ticket lié à un achat de carburant
 *
 * @author arob
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Generated
@SuperBuilder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "TICKET_FUEL")
@PrimaryKeyJoinColumn(foreignKey = @ForeignKey(name = "FK_TICKETFUEL_TICKET"))
public class FuelTicket extends Ticket {

    /**
     * Objet du TicketFuel
     */
    @Size(max = 255, message = "L'objet de l'achat ne doit pas dépasser 255 caractères")
    @Column(name = "TFU_PURPOSE")
    private String purpose;

    /**
     * Client du TicketFuel
     */
    @Size(max = 255, message = "Le nom du client ne doit pas dépasser 255 caractères")
    @Column(name = "TFU_CUSTOMER")
    private String customer;

    /**
     * Somme payer par l'employe pour le TicketFuel
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée par l'employé ne peut pas dépasser 9999,99")
    @Column(name = "TFU_EMPLOYEE_AMOUNT")
    private BigDecimal employeeAmount;

    /**
     * Somme prépayer par l'entreprise pour le TicketFuel
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur prepayée par l'entreprise ne peut pas dépasser 9999,99")
    @Column(name = "TFU_COMPANY_AMOUNT")
    private BigDecimal companyAmount;
}
