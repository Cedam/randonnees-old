package com.infotel.agence.service.expense;

import com.infotel.agence.domain.expense.ReceiptPicture;

import javax.annotation.security.RolesAllowed;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_EXPENSE;

/**
 * Interface pour le service qui gère les entités {@link ReceiptPicture}
 *
 * @author arob
 */
public interface IReceiptPictureService {

    /**
     * Retourne l'image référencée appartenant au ticket dont l'id est en paramètre
     *
     * @param idTicket l'id du ticket lié
     * @return une instance de ReceiptPicture
     */
    @RolesAllowed(ROLE_EXPENSE)
    ReceiptPicture findByTicketId(long idTicket);

    /**
     * Crée et retourne une nouvelle image
     *
     * @param receiptPicture les informations de la nouvelle image
     * @return l'image nouvellement créée
     */
    @RolesAllowed(ROLE_EXPENSE)
    ReceiptPicture create(ReceiptPicture receiptPicture);

    /**
     * Supprime l'image liée au ticket dont l'id est en paramètre
     *
     * @param idTicket l'id du ticket lié
     */
    @RolesAllowed(ROLE_EXPENSE)
    void deleteByTicketId(long idTicket);
}
