package com.infotel.agence.config.aop;

import lombok.extern.log4j.Log4j2;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Aspect for logging execution (input/output) of service and repository Spring components.<br>
 * Only available for "dev" profile and if logs are set to TRACE level.
 *
 * @author ARLI
 */
@Aspect
@Component
@Profile("dev")
@Log4j2
public class LoggingAspect {

    /**
     * A pointcut that matches all services in the application.
     */
    @Pointcut("within(@org.springframework.stereotype.Service *)" //
            + " && within(com.infotel..service..*)")
    public void servicesClassPointcut() {
        // The method is empty because this is just a Pointcut.
    }

    /**
     * A pointcut that matches all repositories in the application.
     */
    @Pointcut("within(@org.springframework.stereotype.Repository *)" //
            + " && within(com.infotel..repository..*)")
    public void repositoriesClassPointcut() {
        // The method is empty because this is just a Pointcut.
    }

    /**
     * A pointcut that matches all controllers in the application.
     */
    @Pointcut("within(@org.springframework.stereotype.Controller *)" //
            + " && within(com.infotel..controller..*)")
    public void controllersClassPointcut() {
        // The method is empty because this is just a Pointcut.
    }

    /**
     * Advice that logs when a method is entered and exited.
     *
     * @param joinPoint join point for advice
     * @return result result of the method
     * @throws Throwable throws IllegalArgumentException
     */
    @Around("repositoriesClassPointcut() || servicesClassPointcut() || controllersClassPointcut()")
    public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
        this.writeToLog("Entering {}.{}() with argument[s] = {}", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName(),
                Arrays.toString(joinPoint.getArgs()));

        try {
            Object result = joinPoint.proceed();
            this.writeToLog("Exiting {}.{}() with result = {}", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName(),
                    result);
            return result;

        } catch (IllegalArgumentException e) {
            this.writeToLog("Illegal argument: {} in {}.{}()", Arrays.toString(joinPoint.getArgs()), joinPoint.getSignature().getDeclaringTypeName(),
                    joinPoint.getSignature().getName());
            throw e;
        }
    }

    /**
     * Write the log if TRACE level is enabled.
     *
     * @param message message
     * @param params  parameters to fill in the message
     */
    private void writeToLog(String message, Object... params) {
        if (log.isTraceEnabled()) {
            log.trace(message, params);
        }
    }

}
