package com.infotel.agence.domain.expense.ticket;

import com.infotel.agence.domain.expense.Place;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**
 * Entité Ticket lié à un déplacement exceptionnel
 *
 * @author arob
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Generated
@SuperBuilder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "TICKET_EXCEPTIONAL_BUSINESS_TRAVEL")
@PrimaryKeyJoinColumn(foreignKey = @ForeignKey(name = "FK_TICKETEXCEPTIONALBUSINESSTRAVEL_TICKET"))
public class ExceptionalBusinessTravelTicket extends Ticket {

    /**
     * Place de départ du déplacement exceptionnel
     */
    @ManyToOne
    @JoinColumn(name = "PLA_START_ID", foreignKey = @ForeignKey(name = "FK_TEBT_PLA_START"))
    private Place startPlace;

    /**
     * Place d'arrivé du déplacement exceptionnel
     */
    @ManyToOne
    @JoinColumn(name = "PLA_END_ID", foreignKey = @ForeignKey(name = "FK_TEBT_PLA_EN"))
    private Place endPlace;

    /**
     * Vehicule du TicketExceptionalBusinessTravel
     */
    @Size(max = 255, message = "Le nom du véhicule ne doit pas dépasser 255 caractères")
    @Column(name = "TEBT_VEHICLE")
    private String vehicle;

    /**
     * Client du TicketExceptionalBusinessTravel
     */
    @Size(max = 255, message = "Le nom du client ne doit pas dépasser 255 caractères")
    @Column(name = "TEBT_CUSTOMER")
    private String customer;

    /**
     * Somme prépayer par l'entreprise pour le TicketExceptionalBusinessTravel
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur prepayée par l'entreprise ne peut pas dépasser 9999,99")
    @Column(name = "TEBT_COMPANY_AMOUNT")
    private BigDecimal companyAmount;
}
