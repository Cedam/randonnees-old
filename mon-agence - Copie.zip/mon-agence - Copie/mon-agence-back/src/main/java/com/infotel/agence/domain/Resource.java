package com.infotel.agence.domain;

public interface Resource {
    Long getId();
}
