package com.infotel.agence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot application's main class
 *
 * @author ARLI
 */
@SpringBootApplication
public class MonAgenceApplication {

    /**
     * Method that starts up the Spring ApplicationContext
     *
     * @param args args
     */
    public static void main(String[] args) {
        SpringApplication.run(MonAgenceApplication.class, args);
    }

}
