package com.infotel.agence.domain.expense.ticket;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**
 * Entité Ticket lié à un frais divers
 *
 * @author arob
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Generated
@SuperBuilder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "TICKET_VARIOUS_COST")
@PrimaryKeyJoinColumn(foreignKey = @ForeignKey(name = "FK_TICKETVARIOUSCOST_TICKET"))
public class VariousCostTicket extends Ticket {

    /**
     * Objet du TicketVariousCost
     */
    @Size(max = 255, message = "L'objet de l'achat ne doit pas dépasser 255 caractères")
    @Column(name = "TVC_PURPOSE")
    private String purpose;

    /**
     * Client du TicketVariousCost
     */
    @Size(max = 255, message = "Le nom du client ne doit pas dépasser 255 caractères")
    @Column(name = "TVC_CUSTOMER")
    private String customer;

    /**
     * Valeur payé par l'employé sur le TicketVariousCost
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée par l'employé ne peut pas dépasser 9999,99")
    @Column(name = "TVC_EMPLOYEE_AMOUNT")
    private BigDecimal employeeAmount;

    /**
     * Valeur prépayé par la société pour le TicketVariousCost
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée par la société ne peut pas dépasser 9999,99")
    @Column(name = "TVC_COMPANY_AMOUNT")
    private BigDecimal companyAmount;
}
