package com.infotel.agence.domain.expense.dto;

import com.infotel.agence.domain.expense.Compensation;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Digits;
import java.math.BigDecimal;

/**
 * DTO de la classe {@link Compensation}
 *
 * @author arob
 */
@Data
@Generated
@NoArgsConstructor
public class CompensationDTO {

    /**
     * Chevaux fiscaux de la compensation
     */
    private int cv;

    /**
     * Indemnité kilométrique de la compensation
     */
    @Digits(integer = 4, fraction = 3, message = "L'indémnité kilométrique ne peut pas dépasser 9,999")
    private BigDecimal mileageAllowance;
}
