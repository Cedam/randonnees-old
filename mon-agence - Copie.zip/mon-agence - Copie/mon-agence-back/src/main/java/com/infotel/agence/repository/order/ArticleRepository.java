package com.infotel.agence.repository.order;

import com.infotel.agence.domain.order.Article;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * {@link Article} repository
 *
 * @author JUBA
 */
@Repository
public interface ArticleRepository extends JpaRepository<Article, Long> {
}
