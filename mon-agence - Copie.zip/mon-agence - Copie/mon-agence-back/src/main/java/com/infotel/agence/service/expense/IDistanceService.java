package com.infotel.agence.service.expense;

import com.infotel.agence.domain.expense.Distance;
import com.infotel.agence.domain.expense.dto.DistanceDTO;
import com.infotel.agence.service.expense.impl.DistanceService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN_EXPENSE;
import static com.infotel.agence.security.SecurityRole.Constant.ROLE_EXPENSE;

/**
 * Interface pour le service qui gère les entités {@link DistanceService}
 *
 * @author arob
 */
public interface IDistanceService {

    /**
     * Crée une nouvelle distance
     *
     * @param distanceDTO distance
     * @return la nouvelle distance
     */
    @RolesAllowed(ROLE_EXPENSE)
    Distance create(DistanceDTO distanceDTO);

    /**
     * Retourne la distance référencée par les ids de place en paramètre
     *
     * @param idPlaceA id de la première place
     * @param idPlaceB id de la deuxième place
     * @return une distance
     */
    @RolesAllowed(ROLE_EXPENSE)
    Distance findByPlacesId(long idPlaceA, long idPlaceB);

    /**
     * Retourne les distances référencées par l'id de place en paramètre
     *
     * @param idPlace id de la première place
     * @return une distance
     */
    @RolesAllowed(ROLE_EXPENSE)
    List<Distance> findByPlaceId(long idPlace);

    /**
     * Retourne la distance référencée par l'id donné en paramètre
     *
     * @param distanceId id de la distance
     * @return une distance
     */
    @RolesAllowed(ROLE_EXPENSE)
    Distance findById(long distanceId);

    /**
     * Met à jour une distance existante
     *
     * @param distanceDTO distance
     * @return distance mise à jour
     */
    @RolesAllowed(ROLE_EXPENSE)
    Distance update(long id, DistanceDTO distanceDTO);

    /**
     * Retourne l'ensemble des distances sous forme de page
     *
     * @return page de distances
     */
    @RolesAllowed(ROLE_EXPENSE)
    Page<Distance> findAll(Pageable pageable);

    /**
     * Supprime la distance referencée par l'id donné en paramètre
     *
     * @param idDistance l'id de la distacne à supprimer
     */
    @RolesAllowed(ROLE_ADMIN_EXPENSE)
    void deleteById(long idDistance);
}
