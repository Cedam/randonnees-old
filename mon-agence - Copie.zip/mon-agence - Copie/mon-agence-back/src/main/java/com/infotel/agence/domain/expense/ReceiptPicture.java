package com.infotel.agence.domain.expense;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.infotel.agence.domain.Resource;
import com.infotel.agence.domain.expense.ticket.Ticket;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Generated
@Table(name = "RECEIPT_PICTURE", uniqueConstraints = @UniqueConstraint(name = "UK_RECEIPTPICTURE_TIKID", columnNames = "RPIC_TIK_ID"))
public class ReceiptPicture implements Resource {
    /**
     * Id du reçu
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RPIC_ID")
    private Long id;

    /**
     * Image justificative du ticket
     */
    @Lob
    @Column(name = "RPIC_IMAGE", length = 100000)
    private byte[] receiptPicture;

    /**
     * Nom de l'image
     */
    @Size(max = 255, message = "Le nom de l'image ne doit pas dépasser 255 caractères")
    @Column(name = "RPIC_NAME")
    private String name;

    /**
     * Mime-type de l'image
     */
    @Size(max = 50, message = "Le Mime-type de l'image ne doit pas dépasser 50 caractères")
    @Column(name = "RPIC_MIME_TYPE", length = 50)
    private String mimeType;

    @OneToOne
    @JoinColumn(name = "RPIC_TIK_ID", nullable = false, foreignKey = @ForeignKey(name = "FK_RECEIPTPICTURE_TICKET"))
    @NotNull
    @JsonIgnore
    // Lors de la suppression automatique, la suppression d'un ticket
    // doit entrainer la suppression de l'image correspondante.
    @OnDelete(action = OnDeleteAction.CASCADE)
    // UNIQUE KEY en haut
    private Ticket ticket;
}
