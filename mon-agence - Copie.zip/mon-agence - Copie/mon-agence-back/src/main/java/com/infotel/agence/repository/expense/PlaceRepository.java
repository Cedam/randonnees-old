package com.infotel.agence.repository.expense;

import com.infotel.agence.domain.expense.Place;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * {@link Place} repository
 *
 * @author arob
 */
@Repository
public interface PlaceRepository extends JpaRepository<Place, Long> {
}
