package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.ReceiptPicture;
import com.infotel.agence.domain.expense.dto.TicketDTO;
import com.infotel.agence.domain.expense.ticket.Ticket;
import com.infotel.agence.domain.expense.ticket.TicketCode;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.service.expense.IReceiptPictureService;
import com.infotel.agence.service.expense.ITicketService;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.*;
import javax.validation.*;
import java.io.*;
import java.net.*;
import java.time.*;
import java.util.*;

import static com.infotel.agence.utils.URIUtils.buildCreatedResourceURI;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;
import static org.springframework.http.ResponseEntity.*;

/**
 * Controleur pour la gestion des {@link Ticket}
 *
 * @author arob
 */
@RestController
@RequestMapping(value = "/api/tickets", produces = APPLICATION_JSON_VALUE)
public class TicketController {

    private final ITicketService ticketService;
    private final IReceiptPictureService receiptPictureService;

    private final ObjectMapper objectMapper;

    public TicketController(ITicketService ticketService, IReceiptPictureService receiptPictureService, ObjectMapper objectMapper) {
        this.ticketService = ticketService;
        this.receiptPictureService = receiptPictureService;
        this.objectMapper = objectMapper;
    }

    /**
     * Retourne le ticket référencé par l'id en paramètre
     *
     * @param id id
     * @return ticket
     */
    @GetMapping("/{id}")
    public ResponseEntity<Ticket> findTicketById(@PathVariable long id) {
        return ok(ticketService.findById(id));
    }

    /**
     * Retourne l'ensemble des tickets
     *
     * @param pageable   les informations relatives à la page souhaitée
     * @param ticketCode le type de ticket souhaité
     * @param startDate  la date la plus ancienne souhaitée
     * @param endDate    la date la plus récente souhaitée
     * @param isArchived envoyer ou non les tickets archivés
     * @return liste des tickets sous formes de page et filtrer
     */
    @GetMapping
    public ResponseEntity<Page<Ticket>> findAllTickets(Pageable pageable, TicketCode ticketCode, @DateTimeFormat(iso = ISO.DATE) LocalDate startDate,
                                                       @DateTimeFormat(iso = ISO.DATE) LocalDate endDate, boolean isArchived) {
        return ok(ticketService.findAll(pageable, ticketCode, startDate, endDate, isArchived));
    }

    /**
     * Retourne l'ensemble des tickets pour procéder à des validations
     *
     * @return liste de tickets
     */
    @GetMapping("/toVerify")
    public ResponseEntity<List<Ticket>> findAllTicketsToVerify() {
        return ok(ticketService.findAllToVerify());
    }

    /**
     * Retourne l'ensemble des codes de ticket existants
     *
     * @return liste de codes
     */
    @GetMapping("/allCodes")
    public ResponseEntity<Map<String, String>> findAllTicketCode() {
        return ok(TicketCode.toMap());
    }

    /**
     * Supprime le ticket référencé par l'id en paramètre
     *
     * @param id id
     * @return void
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTicket(@PathVariable long id) {
        ticketService.deleteById(id);
        return noContent().build();
    }

    /**
     * Créer un nouveau ticket
     *
     * @param ticketDTO ticketDTO
     * @return le nouveau ticket
     */
    @PostMapping(consumes = MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Ticket> createTicket(@RequestPart String ticketDTO,
                                               @RequestParam(required = false) MultipartFile receiptPicture,
                                               HttpServletRequest httpServletRequest) {
        TicketDTO ticket;

        try {
            ticket = objectMapper.readValue(ticketDTO, TicketDTO.class);
        } catch (JsonProcessingException e) {
            throw new TechnicalException("Unparseable object.", e);
        }

        Ticket newTicket = ticketService.create(ticket);

        try {
            if (receiptPicture != null && !receiptPicture.isEmpty()) {

                ReceiptPicture receiptData = new ReceiptPicture();
                receiptData.setReceiptPicture(receiptPicture.getBytes());
                receiptData.setName(receiptPicture.getOriginalFilename());
                receiptData.setMimeType(receiptPicture.getContentType());

                receiptData.setTicket(newTicket);

                receiptPictureService.create(receiptData);
            }
        } catch (IOException e) {
            throw new TechnicalException("Unreadable file object.", e);
        }

        URI location = buildCreatedResourceURI(httpServletRequest, newTicket);
        return created(location).body(newTicket);
    }

    /**
     * Met à jour un ticket existant
     *
     * @param id        id du ticket
     * @param ticketDTO ticketDTO
     * @return ticket mis à jour
     */
    @PutMapping(value = "/{id}", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Ticket> updateTicket(@PathVariable long id, @Valid @RequestBody TicketDTO ticketDTO) {
        return ok(ticketService.update(id, ticketDTO));
    }

    /**
     * Met à true la validité d'un ticket existant
     *
     * @param id id du ticket
     * @return ticket mis à jour
     */
    @PatchMapping(value = "/{id}/verify")
    public ResponseEntity<Ticket> updateTicketValidity(@PathVariable long id) {
        return ok(ticketService.updateValidity(id, true));
    }

    /**
     * Permet de récuperer la date du ticket (non-archivé) le plus ancien ainsi que la date du ticket (non-archivé) du ticket le plus récent.
     *
     * @return une map de date : {"olderDate": LocalDate la plus ancienne, "youngerDate": LocalDate la plus récente}
     */
    @GetMapping("/limits")
    public ResponseEntity<Map<String, LocalDate>> getLimits() {
        return ok(ticketService.getLimits());
    }
}