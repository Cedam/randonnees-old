package com.infotel.agence.domain.expense.ticket;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**
 * Entité lié à un repas client
 *
 * @author arob
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Generated
@SuperBuilder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "TICKET_SITE_MEAL_COST")
@PrimaryKeyJoinColumn(foreignKey = @ForeignKey(name = "FK_TICKETSITEMEALCOST_TICKET"))
public class SiteMealCostTicket extends Ticket {

    /**
     * Lieu du chantier ou de la réunion du TicketSiteMealCost
     */
    @Size(max = 255, message = "Le lieu du chantier ou de la réunion ne peut pas dépasser 255 caractères")
    @Column(name = "TSMC_SITE_MEETING")
    private String siteOrMeeting;

    /**
     * Valeur payé par l'employé sur le TicketSiteMealCost
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée par l'employé ne peut pas dépasser 9999,99")
    @Column(name = "TSMC_EMPLOYEE_AMOUNT")
    private BigDecimal employeeAmount;

    /**
     * Valeur prépayé par la société pour le TicketSiteMealCost
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée par la société ne peut pas dépasser 9999,99")
    @Column(name = "TSMC_COMPANY_AMOUNT")
    private BigDecimal companyAmount;
}
