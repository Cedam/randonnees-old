package com.infotel.agence.config.security;

import lombok.Data;
import lombok.Generated;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.util.List;

/**
 * Properties to describe how to manage CORS request.
 *
 * @author ARLI
 */
@Data
@Generated
@ConfigurationProperties(prefix = "security.cors", ignoreUnknownFields = false)
@Validated
public class CorsProperties {

    /**
     * Tells browsers to allow that origin (domains) to access the resource
     */
    @NotEmpty
    private List<String> allowedOrigins;

    /**
     * Specifies the method or methods allowed when accessing the resource
     */
    @NotEmpty
    private List<String> allowedMethods;

    /**
     * Indicate which HTTP headers can be used when making the actual request
     */
    @NotEmpty
    private List<String> allowedHeaders;

    /**
     * Whitelisted headers that browsers are allowed to access.
     */
    @NotEmpty
    private List<String> exposedHeaders;

    /**
     * Indicates whether or not the response to the request can be exposed when the credentials flag is true.
     */
    @NotNull
    private Boolean allowCredentials;

    /**
     * Indicates how long the results of a preflight request can be cached.
     */
    @Positive
    private Long maxAge;
}
