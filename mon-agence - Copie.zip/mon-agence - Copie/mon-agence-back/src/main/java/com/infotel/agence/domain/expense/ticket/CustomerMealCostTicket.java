package com.infotel.agence.domain.expense.ticket;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**
 * Entité Ticket lié à un repas client
 *
 * @author arob
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Generated
@SuperBuilder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "TICKET_CUSTOMER_MEAL_COST")
@PrimaryKeyJoinColumn(foreignKey = @ForeignKey(name = "FK_TICKETCUSTOMERMEALCOST_TICKET"))
public class CustomerMealCostTicket extends Ticket {

    /**
     * Client lié au TicketCustomerMealCost
     */
    @Size(max = 255, message = "Le nom du client ne doit pas dépasser 255 caractères")
    @Column(name = "TCMC_CUSTOMER")
    private String customer;

    /**
     * Valeur payé par l'employé sur le TicketCustomerMealCost
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée par l'employé ne peut pas dépasser 9999,99")
    @Column(name = "TCMC_EMPLOYEE_AMOUNT")
    private BigDecimal employeeAmount;

    /**
     * Valeur prépayé par la société pour le TicketCustomerMealCost
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée par la société ne peut pas dépasser 9999,99")
    @Column(name = "TCMC_COMPANY_AMOUNT")
    private BigDecimal companyAmount;
}
