package com.infotel.agence.tasks;

import com.infotel.agence.config.property.ExpenseProperties;
import com.infotel.agence.service.expense.IGeneratedReportService;
import com.infotel.agence.service.expense.ITicketService;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.*;

@Component
public class Tasks {

    private final ITicketService ticketService;
    private final IGeneratedReportService generatedReportService;
    private final ExpenseProperties expenseProperties;

    public Tasks(final ITicketService ticketService,
                 final IGeneratedReportService generatedReportService,
                 final ExpenseProperties expenseProperties) {
        this.ticketService = ticketService;
        this.generatedReportService = generatedReportService;
        this.expenseProperties = expenseProperties;
    }

    /**
     * Routine permettant, le premier jour de chaque mois, de supprimer toutes les images et leur ticket associé si ce dernier
     * est vieux de plus de 6 mois et si celui-ci est archivé.
     */
    @Scheduled(cron = "0 0 0 1 * ?") // Lancement le premier de chaque mois à 00:00, peu importe le jour de la semaine
    public void deleteArchivedTickets() {
        // Choix de la date de suppression
        LocalDate date = LocalDate.now().minusMonths(expenseProperties.getTicketsExpirationDelayMonths());

        // Supprimer tous les tickets plus vieux que la date donnée
        ticketService.deleteTicketsOlderThan(date);
    }

    /**
     * Routine permettant, le premier jour de chaque mois, de supprimer toutes les archives si ces dernières
     * sont vieilles de plus de 12 mois.
     */
    @Scheduled(cron = "0 0 0 1 * ?") // Lancement le premier de chaque mois à 00:00, peu importe le jour de la semaine
    public void deleteGeneratedReports() {
        // Choix de la date de suppression
        LocalDate date = LocalDate.now().minusMonths(expenseProperties.getReportsExpirationDelayMonths());

        // Supprimer tous les tickets plus vieux que la date donnée
        generatedReportService.deleteGeneratedReportsOlderThan(date);
    }
}
