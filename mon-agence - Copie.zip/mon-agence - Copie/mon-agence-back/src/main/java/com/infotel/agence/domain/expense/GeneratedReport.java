package com.infotel.agence.domain.expense;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.Generated;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * Entité lié à l'archivage d'un compte rendus de notes de frais.
 *
 * @author arob
 */
@Entity
@Data
@Generated
@Table(name = "GENERATED_REPORT",
        indexes = { @Index(name = "IDX_GR_CREATION_DATE", columnList = "GR_CREATION_DATE") })
public class GeneratedReport {

    /**
     * Id de l'archive
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "GR_ID")
    private Long id;

    /**
     * Date de création du compte rendu
     */
    @NotNull
    @Column(name = "GR_CREATION_DATE")
    private LocalDate creationDate;

    /**
     * Mois désigné par le compte rendu
     */
    @Column(name = "GR_MONTH")
    private int month;

    /**
     * Compte rendus sous format zip
     */
    @Lob
    @Column(name = "GR_ZIP_FILE", length = 100000)
    @JsonIgnore
    private byte[] zipFile;

    /**
     * Compte rendus sous format pdf
     */
    @Lob
    @Column(name = "GR_PDF_FILE", length = 100000)
    @JsonIgnore
    private byte[] pdfFile;

    /**
     * Compte rendus sous format xlsx
     */
    @Lob
    @Column(name = "GR_XLSX_FILE", length = 100000)
    @JsonIgnore
    private byte[] xlsxFile;

    /**
     * Employée possédant le compte rendu
     */
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "EMPI_ID", foreignKey = @ForeignKey(name = "FK_GENERATEDREPORT_EMPLOYEEIDENTITY"))
    @JsonIgnore
    // Lors de la suppression d'un utilisateur, la suppression des archives qui lui sont liées doit être automatique.
    @OnDelete(action = OnDeleteAction.CASCADE)
    private EmployeeIdentity employeeIdentity;
}
