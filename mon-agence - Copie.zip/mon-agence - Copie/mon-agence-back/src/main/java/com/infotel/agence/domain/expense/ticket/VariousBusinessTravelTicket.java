package com.infotel.agence.domain.expense.ticket;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**
 * Entité Ticket lié à un frais divers lié au déplacement
 *
 * @author arob
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Generated
@SuperBuilder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "TICKET_VARIOUS_BUSINESS_TRAVEL")
@PrimaryKeyJoinColumn(foreignKey = @ForeignKey(name = "FK_TICKETVARIOUSBUSINESSTRAVEL_TICKET"))
public class VariousBusinessTravelTicket extends Ticket {

    /**
     * Objet du TicketVariousBusinessTravel
     */
    @Size(max = 255, message = "L'objet de l'achat ne doit pas dépasser 255 caractères")
    @Column(name = "TVBT_PURPOSE")
    private String purpose;

    /**
     * Client du TicketVariousBusinessTravel
     */
    @Size(max = 255, message = "Le nom du client ne doit pas dépasser 255 caractères")
    @Column(name = "TVBT_CUSTOMER")
    private String customer;

    /**
     * Valeur payé par l'employé sur le TicketVariousBusinessTravel
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payé par l'employé ne peut pas dépasser 9999,99")
    @Column(name = "TVBT_EMPLOYEE_AMOUNT")
    private BigDecimal employeeAmount;

    /**
     * Valeur prépayé par la société pour le TicketVariousBusinessTravel
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payé par la société ne peut pas dépasser 9999,99")
    @Column(name = "TVBT_COMPANY_AMOUNT")
    private BigDecimal companyAmount;
}
