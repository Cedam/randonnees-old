package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.Compensation;
import com.infotel.agence.domain.expense.dto.CompensationDTO;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.CompensationRepository;
import com.infotel.agence.security.SecurityUtils;
import com.infotel.agence.service.expense.ICompensationService;

import ma.glasnost.orika.MapperFacade;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.*;
import java.util.*;

/**
 * Service qui gère les entités {@link Compensation}
 *
 * @author arob
 */
@Service
public class CompensationService implements ICompensationService {

    public static final String UNKNOWN_COMP = "Aucune compensation n''est référencée par l''id {0}";
    public static final String NON_NULL_COMP = "La compensation doit être non-null !";

    private final CompensationRepository compensationRepository;

    private final MapperFacade mapperFacade;

    public CompensationService(final CompensationRepository compensationRepository,
                               final MapperFacade mapperFacade) {
        this.compensationRepository = compensationRepository;
        this.mapperFacade = mapperFacade;
    }

    @Override
    public Compensation findById(long id) {
        return compensationRepository.findById(id)
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_COMP, id));
    }

    @Override
    public Page<Compensation> findAllPage(Pageable pageable) {
        return compensationRepository.findAll(pageable);
    }

    @Override
    public List<Compensation> findAllList() {
        return compensationRepository.findAll();
    }

    @Override
    public Compensation create(CompensationDTO compensationDTO) {
        if (compensationDTO == null) {
            throw new TechnicalException(NON_NULL_COMP);
        }
        return compensationRepository.save(mapperFacade.map(compensationDTO, Compensation.class));
    }

    @Override
    public Compensation update(long id, CompensationDTO compensationDTO) {
        if (compensationRepository.existsById(id)) {
            Compensation compensation = mapperFacade.map(compensationDTO, Compensation.class);
            compensation.setId(id);

            return compensationRepository.save(compensation);
        }
        throw new UnknownEntityException(UNKNOWN_COMP, id);
    }

    @Override
    public BigDecimal getCurrentUserMileageAllowance() {
        Long userId = SecurityUtils.getCurrentUserId();

        return compensationRepository.getCurrentUserMileageAllowance(userId);
    }
}
