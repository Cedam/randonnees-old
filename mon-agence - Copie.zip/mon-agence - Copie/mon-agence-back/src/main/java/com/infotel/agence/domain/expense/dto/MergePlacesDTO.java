package com.infotel.agence.domain.expense.dto;

import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

/**
 * DTO contenant les ids de place necessaire à une fusion.
 *
 * @author arob
 */
@Data
@Generated
@NoArgsConstructor
public class MergePlacesDTO {
    private Long placeIdDelete;
    private Long placeIdRecipient;
}
