package com.infotel.agence.service.expense.impl.report.excel.writer;

import com.infotel.agence.domain.expense.export.line.VariousCostLine;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.lang.NonNull;

import java.util.Map;
import java.util.function.Function;

import static com.infotel.agence.service.expense.impl.report.excel.ExcelFileGenerator.SHEET_VARIOUS_COST;

/**
 * Implémentation spécifique à l'écriture des données liées au tableau "Frais divers non lié à un déplacement" présent dans la feuille "Frais divers".
 *
 * @author arob
 */
public class VariousCostChartWriter extends AbstractChartWriter<VariousCostLine> {
    private static final Map<Integer, Function<VariousCostLine, ?>> BINDING = Map.of(
            1, VariousCostLine::getDate,
            2, VariousCostLine::getPurpose,
            4, VariousCostLine::getCustomer,
            5, VariousCostLine::getEmployeeAmount,
            6, VariousCostLine::getCompanyAmount
    );

    public VariousCostChartWriter(XSSFWorkbook workbook) {
        super(workbook);
    }

    @Override
    protected Map<Integer, Function<VariousCostLine, ?>> getExtractorsByColumn() {
        return BINDING;
    }

    @Override
    protected XSSFSheet getTargetSheet() {
        return getSheet(SHEET_VARIOUS_COST);
    }

    @Override
    protected void fillFormula(@NonNull Row row, int startRow, int rowNb) {
        fillOneSumFormula(row.getCell(5), "F", startRow + 1, rowNb + 1);
        fillOneSumFormula(row.getCell(6), "G", startRow + 1, rowNb + 1);
    }
}
