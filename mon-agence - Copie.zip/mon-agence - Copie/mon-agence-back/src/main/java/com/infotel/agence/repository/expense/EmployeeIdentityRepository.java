package com.infotel.agence.repository.expense;

import com.infotel.agence.domain.expense.EmployeeIdentity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * {@link EmployeeIdentity} repository
 *
 * @author arob
 */
@Repository
public interface EmployeeIdentityRepository extends JpaRepository<EmployeeIdentity, Long> {
}
