package com.infotel.agence.domain.order;

/**
 * Status d'une demande {@link Request}
 */
public enum RequestStatus {
    PENDING("A traiter"),
    IN_PROGRESS("En cours de traitement"),
    DONE("Traité");

    private String label;

    RequestStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
