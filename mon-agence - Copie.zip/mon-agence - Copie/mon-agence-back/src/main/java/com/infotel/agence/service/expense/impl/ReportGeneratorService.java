package com.infotel.agence.service.expense.impl;

import com.infotel.agence.config.property.ExpenseProperties;
import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.domain.expense.GeneratedReport;
import com.infotel.agence.domain.expense.export.ExcelEmployeeIdentity;
import com.infotel.agence.domain.expense.ticket.Ticket;
import com.infotel.agence.domain.expense.ticket.TicketCode;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.repository.expense.TicketRepository;
import com.infotel.agence.security.SecurityUtils;
import com.infotel.agence.service.expense.*;
import com.infotel.agence.service.expense.impl.report.excel.ExcelFileGenerator;
import com.infotel.agence.service.expense.impl.report.pdf.PdfFileGenerator;

import lombok.extern.log4j.Log4j2;
import ma.glasnost.orika.MapperFacade;
import org.springframework.stereotype.Service;

import java.io.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.zip.*;

/**
 * Service qui gère la génération des fichiers de comptes-rendus.
 *
 * @author arob
 */
@Service
@Log4j2
public class ReportGeneratorService implements IReportGeneratorService {

    public static final String NOT_NULL_DATES = "Les paramètres date de début (startDate) et date de fin (endDate) non-null sont obligatoires.";

    private final IEmployeeIdentityService employeeIdentityService;
    private final ITicketService ticketService;
    private final IDistanceService distanceService;
    private final IGeneratedReportService generatedReportService;
    private final TicketRepository ticketRepository;
    private final MapperFacade mapperFacade;
    private final ExpenseProperties expenseProperties;

    public ReportGeneratorService(IEmployeeIdentityService employeeIdentityService,
                                  ITicketService ticketService,
                                  TicketRepository ticketRepository,
                                  IDistanceService distanceService,
                                  IGeneratedReportService generatedReportService,
                                  MapperFacade mapperFacade,
                                  ExpenseProperties expenseProperties) {
        this.employeeIdentityService = employeeIdentityService;
        this.ticketService = ticketService;
        this.ticketRepository = ticketRepository;
        this.distanceService = distanceService;
        this.generatedReportService = generatedReportService;
        this.mapperFacade = mapperFacade;
        this.expenseProperties = expenseProperties;
    }

    /**
     * Permet la consolidation des données nécessaires à l'écriture des en-têtes dans le fichier de comptes-rendus excel.
     *
     * @param month mois
     * @return identité
     */
    private ExcelEmployeeIdentity computeIdentity(Month month) {
        EmployeeIdentity employeeIdentity = employeeIdentityService.findCurrent();

        ExcelEmployeeIdentity identity = new ExcelEmployeeIdentity();
        identity.setSerialNumber(employeeIdentity.getSerialNumber());
        identity.setMonth(month.getDisplayName(TextStyle.FULL, Locale.FRANCE));
        identity.setAgency(employeeIdentity.getAgency());
        identity.setCustomer(employeeIdentity.getCustomer());
        identity.setOperationCode(employeeIdentity.getOperationCode());
        identity.setLicencePlate(employeeIdentity.getLicencePlate());
        identity.setCv(employeeIdentity.getCompensation().getCv());
        identity.setMileageAllowance(employeeIdentity.getCompensation().getMileageAllowance());

        SecurityUtils.getCurrentUser().ifPresent(user -> {
            identity.setLastName(user.getLastname());
            identity.setFirstName(user.getFirstname());
        });

        return identity;
    }

    @Override
    public String getFilename(int month) {
        EmployeeIdentity employeeIdentity = employeeIdentityService.findCurrent();

        return String.format("%s_noteFrais_%s",
                employeeIdentity.getSerialNumber(),
                Month.of(month).getDisplayName(TextStyle.FULL, Locale.FRANCE));
    }

    @Override
    public void export(LocalDate startDate, LocalDate endDate, String filename, int month, OutputStream outputStream) {
        if (startDate == null || endDate == null) {
            throw new BusinessException(NOT_NULL_DATES);
        }

        // Création d'une nouvelle sauvegarde de compte rendu de notes de frais
        GeneratedReport generatedReport = new GeneratedReport();
        generatedReport.setEmployeeIdentity(employeeIdentityService.findCurrent());
        generatedReport.setCreationDate(LocalDate.now());
        generatedReport.setMonth(month);

        /*
            On génère les fichiers et on les sauvegarde dans la base de données
        */
        try {
            // On récupère les données concernées
            Map<TicketCode, List<Ticket>> data = ticketService.findAllToGenerate(startDate, endDate);

            // On génère le fichier excel
            ByteArrayOutputStream excelOutputStream = new ByteArrayOutputStream();

            generateExcel(data, Month.of(month), excelOutputStream);

            generatedReport.setXlsxFile(excelOutputStream.toByteArray());

            // On génère le fichier pdf
            ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();

            generatePDF(data, pdfOutputStream);

            generatedReport.setPdfFile(pdfOutputStream.toByteArray());
        } catch (IOException e) {
            log.error("Problème lors de la génération des fichiers de comptes rendus.", e);
            throw new TechnicalException("Problème lors de la génération des fichiers de comptes rendus.", e);
        }

        /*
            On utilise les fichiers présents dans generatedReport pour créer un zip associé
         */

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);

        try {
            zos.putNextEntry(new ZipEntry(filename.concat(".xlsx")));
            zos.write(generatedReport.getXlsxFile());

            zos.putNextEntry(new ZipEntry(filename.concat(".pdf")));
            zos.write(generatedReport.getPdfFile());

            zos.closeEntry();
            zos.close();
            generatedReport.setZipFile(baos.toByteArray());

        } catch (IOException e) {
            log.error("Problème lors de la génération du fichier zip de comptes rendus.", e);
            throw new TechnicalException("Problème lors de la génération du fichier zip de comptes rendus.", e);
        }

        /*
            On sauvegarde les fichiers générés et on renvoie le zip
         */
        GeneratedReport newGeneratedReport = generatedReportService.create(generatedReport);

        try {
            outputStream.write(newGeneratedReport.getZipFile());
        } catch (IOException e) {
            log.error("Problème lors du renvoie du fichier zip de comptes rendus.", e);
            throw new TechnicalException("Problème lors du renvoie du fichier zip de comptes rendus.", e);
        }

        // Si tout c'est bien passé, on archive les tickets concernées
        ticketService.archiveTicketBetween(startDate, endDate);
    }

    private void generateExcel(Map<TicketCode, List<Ticket>> data, Month month, OutputStream outputStream) throws IOException {
        final ExcelEmployeeIdentity identity = computeIdentity(month);

        ExcelFileGenerator handler = new ExcelFileGenerator(mapperFacade, distanceService);
        handler.load(expenseProperties.getExcelTemplatePath());

        handler.writeIdentity(identity);
        handler.writeTickets(data);

        handler.save(outputStream);
    }

    private void generatePDF(Map<TicketCode, List<Ticket>> data, OutputStream outputStream) throws IOException {
        PdfFileGenerator handler = new PdfFileGenerator();
        handler.load(expenseProperties.getPdfSeparatorFolderPath());

        handler.write(data);

        handler.save(outputStream);
    }

    @Override
    public Map<String, LocalDate> getLimits() {
        Long userId = SecurityUtils.getCurrentUserId();

        LocalDate olderDate = ticketRepository.findOlderDateToGenerate(userId);
        LocalDate youngerDate = ticketRepository.findYoungerDateToGenerate(userId);

        return Map.ofEntries(
                new AbstractMap.SimpleEntry<>("olderDate", (olderDate != null ? olderDate : LocalDate.now())),
                new AbstractMap.SimpleEntry<>("youngerDate", (youngerDate != null ? youngerDate : LocalDate.now())));
    }
}
