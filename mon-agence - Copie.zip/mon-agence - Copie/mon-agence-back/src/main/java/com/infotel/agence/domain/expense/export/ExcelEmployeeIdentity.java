package com.infotel.agence.domain.expense.export;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;

/**
 * Cette classe permet le stockage des informations relatives à l'identité d'un utilisateur en lien avec le fichier
 * excel des notes de frais.
 *
 * @author arob
 */
@Setter
@Getter
public class ExcelEmployeeIdentity {
    private String lastName;
    private String firstName;
    private String serialNumber;
    private String month;
    private String agency;
    private String customer;
    private String operationCode;
    private String licencePlate;
    private Integer cv;
    private BigDecimal mileageAllowance;

    public String getFullName() {
        return String.format("%s %s", StringUtils.upperCase(lastName), firstName);
    }
}
