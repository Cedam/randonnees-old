package com.infotel.agence.security;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.infotel.agence.security.CustomHttpHeaders.X_AUTHORIZATION;
import static com.infotel.agence.security.CustomHttpHeaders.X_REFRESH;

public class BasicAuthorizationFilter extends BasicAuthenticationFilter {

    private final TokenManager tokenManager;

    public BasicAuthorizationFilter(AuthenticationManager authenticationManager,
                                    AuthenticationEntryPoint authenticationEntryPoint,
                                    TokenManager tokenManager) {
        super(authenticationManager, authenticationEntryPoint);
        this.tokenManager = tokenManager;
    }

    @Override
    protected void onSuccessfulAuthentication(HttpServletRequest request,
                                              HttpServletResponse response,
                                              Authentication authentication) {
        response.addHeader(X_AUTHORIZATION, tokenManager.getAccessToken(authentication));
        response.addHeader(X_REFRESH, tokenManager.getRefreshToken(authentication));
    }
}
