package com.infotel.agence.domain.expense.export.line;

import java.util.List;

/**
 * Cette classe doit être parente des classes Row liées au fichier excel des notes de frais. Elle oblige la présence des
 * zones à fusionner au sein des tableaux.
 *
 * @author arob
 */
public abstract class AbstractLine {
    private List<MergeCellRegion> merges;

    /**
     * Ce constructeur permet l'initialisation d'une liste de cellule à fusionner au sein d'une ligne d'un tableau.
     *
     * @param merges
     */
    public AbstractLine(MergeCellRegion... merges) {
        this.merges = List.of(merges);
    }

    /**
     * Ce constructeur permet l'initialisation d'une liste de cellule à fusionner au sein d'une ligne d'un tableau.
     *
     * @param startMergeRegion
     * @param endMergeRegion
     */
    public AbstractLine(int startMergeRegion, int endMergeRegion) {
        this(new MergeCellRegion(startMergeRegion, endMergeRegion));
    }

    /**
     * Cette fonction permet de récuperer la liste de cellule à fusionner au sein d'une ligne d'un tableau.
     */
    public List<MergeCellRegion> getMerges() {
        return merges;
    }
}
