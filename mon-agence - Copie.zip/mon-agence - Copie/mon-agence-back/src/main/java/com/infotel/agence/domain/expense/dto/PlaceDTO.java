package com.infotel.agence.domain.expense.dto;

import com.infotel.agence.domain.expense.Place;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;

/**
 * DTO de la classe {@link Place}
 *
 * @author arob
 */
@Data
@Generated
@NoArgsConstructor
public class PlaceDTO {

    /**
     * Nom de la place
     */
    @Size(max = 255, message = "Le nom d'une place ne doit pas dépasser 255 caractères")
    private String name;
}
