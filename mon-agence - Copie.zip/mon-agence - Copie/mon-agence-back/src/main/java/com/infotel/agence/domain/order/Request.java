package com.infotel.agence.domain.order;

import com.infotel.agence.domain.Resource;
import com.infotel.agence.domain.user.User;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Entité Demande
 *
 * @author JUBA
 */
@Entity
@Data
@Table(name = "REQUEST")
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Builder
@Generated
public class Request implements Resource {

    /**
     * Id de la demande
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "REQ_ID")
    private Long id;

    /**
     * Status de la demande
     */
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "REQ_STATUS", length = 15)
    private RequestStatus status;

    /*
     * Auteur de la demande
     */
    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name = "USR_ID", foreignKey = @ForeignKey(name = "FK_USER_REQUEST"))
    private User author;

    /**
     * Liste des articles liés
     */
    // @formatter:off
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "REQUEST2ARTICLE",
            joinColumns = { @JoinColumn(name = "REQ_ID") },
            inverseJoinColumns = { @JoinColumn(name = "ART_ID") },
            foreignKey = @ForeignKey(name = "FK_REQUEST2ARTICLE_REQUEST"),
            inverseForeignKey = @ForeignKey(name = "FK_REQUEST2ARTICLE_ARTICLE"),
            indexes = {
                    @Index(name = "IDX_REQUEST2ARTICLE_REQID", columnList = "REQ_ID"),
                    @Index(name = "IDX_REQUEST2ARTICLE_ARTID", columnList = "ART_ID")
            })
    // @formatter:on
    private List<Article> articles;

    /**
     * Date de création de la demande
     */
    @NotNull
    // TODO ALI vérifier l'utilité du @DateTimeFormat
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
    @Column(name = "REQ_CREATION_DATE", columnDefinition = "TIMESTAMP")
    private LocalDateTime creationDate;

    /**
     * Date de traitement de la demande
     */
    // TODO ALI vérifier l'utilité du @DateTimeFormat et le format TIMESTAMP
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
    @Column(name = "REQ_PROCESSING_DATE", columnDefinition = "TIMESTAMP")
    private LocalDateTime processingDate;

}
