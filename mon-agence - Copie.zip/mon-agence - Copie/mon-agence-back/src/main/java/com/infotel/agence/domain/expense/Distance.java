package com.infotel.agence.domain.expense;

import com.infotel.agence.domain.Resource;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import java.math.BigDecimal;

/**
 * Entité lié à la distance entre deux places
 *
 * @author arob
 */
@Entity
@Data
@NoArgsConstructor
@Builder
@Generated
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "DISTANCE",
        indexes = { @Index(name = "IDX_DIST_ID", columnList = "DIST_ID") })
public class Distance implements Resource {

    /**
     * Id de la distance
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DIST_ID")
    private Long id;

    /**
     * Valeur de la distance
     */
    @Digits(integer = 7, fraction = 3, message = "La distance entre deux places ne peut pas dépasser 9999,99")
    @Column(name = "DIST_VALUE")
    private BigDecimal value;

    /**
     * Place de départ
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "PLA_ID_START", foreignKey = @ForeignKey(name = "FK_DISTANCE_PLACE_START"))
    private Place placeStart;

    /**
     * Place d'arrivé
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "PLA_ID_END", foreignKey = @ForeignKey(name = "FK_DISTANCE_PLACE_END"))
    private Place placeEnd;
}
