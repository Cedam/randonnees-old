package com.infotel.agence.domain.expense.ticket;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Enumération des types de Tickets pour la table {@link Ticket}
 *
 * @author arob
 */
public enum TicketCode {
    // @formatter:off
    EXCEPTIONAL_BUSINESS_TRAVEL("Frais de déplacement exceptionnel"),
    LODGING_MEAL_BUSINESS("Frais d'hébergement et de repas individuels"),
    VARIOUS_BUSINESS_TRAVEL("Frais divers liés à un déplacement"),
    CUSTOMER_MEAL_COST("Frais de repas client"),
    SITE_MEAL_COST("Frais de repas chantier et réunion de travail"),
    VARIOUS_COST("Frais divers hors déplacement"),
    FUEL("Frais de carburant");
    // @formatter:on

    private String label;

    TicketCode(String label) {
        this.label = label;
    }

    public static Map<String, String> toMap() {
        Map<String, String> result = new LinkedHashMap<>();

        for (TicketCode code : TicketCode.values()) {
            result.put(code.name(), code.getLabel());
        }

        return result;
    }

    public String getLabel() {
        return label;
    }
}