package com.infotel.agence.controller.order;

import com.infotel.agence.domain.order.Request;
import com.infotel.agence.service.order.IRequestService;

import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.*;
import java.net.*;
import java.util.*;

import static com.infotel.agence.utils.URIUtils.buildCreatedResourceURI;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.ResponseEntity.*;

/**
 * Controleur pour la gestion des demandes
 *
 * @author JUBA
 */
@RestController
@RequestMapping(value = "/api/demandes", produces = APPLICATION_JSON_VALUE)
@Log4j2
public class RequestController {

    private final IRequestService requestService;

    public RequestController(IRequestService requestService) {
        this.requestService = requestService;
    }

    /**
     * Retourne la demande référencée par l'id en paramètre
     *
     * @param id id
     * @return demande
     */
    @GetMapping("/{id}")
    public ResponseEntity<Request> findRequestById(@PathVariable long id) {
        return ok(requestService.findById(id));
    }

    /**
     * Retourne l'ensemble des demandes
     *
     * @return liste des demandes
     */
    @GetMapping
    public ResponseEntity<List<Request>> findAllRequests() {
        return ok(requestService.findAll());
    }

    /**
     * Créer une nouvelle demande
     *
     * @param request demande
     * @return nouvelle demande
     */
    @PostMapping(value = "", consumes = APPLICATION_JSON_VALUE) // FIXME ALI restore @Valid
    public ResponseEntity<Request> createRequest(@RequestBody Request request, HttpServletRequest httpServletRequest) {
        Request newRequest = requestService.create(request);
        URI location = buildCreatedResourceURI(httpServletRequest, newRequest);
        return created(location).body(newRequest);
    }

    /**
     * Met à jour une demande existante
     *
     * @param id      id de la demande
     * @param request demande
     * @return demande mise à jour
     */
    @PutMapping(value = "/{id}", consumes = APPLICATION_JSON_VALUE) // FIXME ALI restore @Valid
    public ResponseEntity<Request> updateRequest(@PathVariable long id, @RequestBody Request request) {
        return ok(requestService.update(request));
    }

    /**
     * Supprime la demande référencée par l'id en paramètre
     *
     * @param id id
     * @return void
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRequest(@PathVariable long id) {
        requestService.deleteById(id);
        return noContent().build();
    }
}
