package com.infotel.agence.config.mapper;

import com.infotel.agence.domain.expense.export.line.ExceptionalBusinessTravelLine;
import com.infotel.agence.domain.expense.ticket.ExceptionalBusinessTravelTicket;

import ma.glasnost.orika.BoundMapperFacade;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Instanciation des beans qui permettent le mapping des propriétés entre deux classes différentes
 *
 * @author ARLI
 */
@Configuration
public class MapperConfig {

    /**
     * Permet de générer des instances de {@link BoundMapperFacade}
     */
    @Bean
    public MapperFactory mapperFactory() {
        final DefaultMapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

        // mapping custom pour TicketExceptionalBusinessTravel <=> ExceptionalBusinessTravelLine
        mapperFactory.classMap(ExceptionalBusinessTravelTicket.class, ExceptionalBusinessTravelLine.class)
                .field("startPlace.name", "startPlace")
                .field("endPlace.name", "endPlace")
                .byDefault()
                .register();

        return mapperFactory;
    }

    /**
     * {@link MapperFacade} générique. Pour des raisons de performance, privilégier l'usage de {@link BoundMapperFacade} obtenu
     * à partir de {@link MapperFactory} dans le cas où un grand nombre d'objets d'une même classe doivent être mappés.
     */
    @Bean
    public MapperFacade mapperFacade() {
        return mapperFactory().getMapperFacade();
    }

}
