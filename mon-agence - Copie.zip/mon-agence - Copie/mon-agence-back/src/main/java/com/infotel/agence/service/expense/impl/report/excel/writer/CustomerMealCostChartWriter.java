package com.infotel.agence.service.expense.impl.report.excel.writer;

import com.infotel.agence.domain.expense.export.line.CustomerMealCostLine;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.lang.NonNull;

import java.util.Map;
import java.util.function.Function;

import static com.infotel.agence.service.expense.impl.report.excel.ExcelFileGenerator.SHEET_CUSTOMER_MEAL_COST;

/**
 * Implémentation spécifique à l'écriture des données liées au tableau "Frais repas client" présent dans la feuille "Frais de repas client".
 *
 * @author arob
 */
public class CustomerMealCostChartWriter extends AbstractChartWriter<CustomerMealCostLine> {
    private static final Map<Integer, Function<CustomerMealCostLine, ?>> BINDING = Map.of(
            1, CustomerMealCostLine::getDate,
            2, CustomerMealCostLine::getCustomer,
            5, CustomerMealCostLine::getEmployeeAmount,
            6, CustomerMealCostLine::getCompanyAmount
    );

    public CustomerMealCostChartWriter(XSSFWorkbook workbook) {
        super(workbook);
    }

    @Override
    protected Map<Integer, Function<CustomerMealCostLine, ?>> getExtractorsByColumn() {
        return BINDING;
    }

    @Override
    protected XSSFSheet getTargetSheet() {
        return getSheet(SHEET_CUSTOMER_MEAL_COST);
    }

    @Override
    protected void fillFormula(@NonNull final Row row, final int startRow, final int rowNb) {
        fillOneSumFormula(row.getCell(5), "F", startRow + 1, rowNb + 1);
        fillOneSumFormula(row.getCell(6), "G", startRow + 1, rowNb + 1);
    }
}
