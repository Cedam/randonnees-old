package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.ReceiptPicture;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.ReceiptPictureRepository;
import com.infotel.agence.security.SecurityUtils;
import com.infotel.agence.service.expense.IReceiptPictureService;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Service qui gère les entités {@link ReceiptPicture}
 *
 * @author arob
 */
@Service
@Log4j2
public class ReceiptPictureService implements IReceiptPictureService {
    public static final String UNKNOWN_RPIC = "Aucune image n''est référencée par l''id {0}";
    public static final String NON_NULL_RPIC = "L'image doit être non-null !";
    public static final String NULL_DATE_DELETE_OLDER = "La date de suppression doit être différente de nulle.";

    private final ReceiptPictureRepository receiptPictureRepository;

    public ReceiptPictureService(final ReceiptPictureRepository receiptPictureRepository) {
        this.receiptPictureRepository = receiptPictureRepository;
    }

    @Override
    public ReceiptPicture findByTicketId(long idTicket) {
        return receiptPictureRepository.findByTicketId(idTicket)
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_RPIC, idTicket));
    }

    @Override
    public ReceiptPicture create(ReceiptPicture receiptPicture) {
        if (receiptPicture == null) {
            throw new TechnicalException(NON_NULL_RPIC);
        }
        return receiptPictureRepository.save(receiptPicture);
    }

    @Override
    public void deleteByTicketId(long idTicket) {
        Long userId = SecurityUtils.getCurrentUserId();

        Optional<ReceiptPicture> receiptPicture = receiptPictureRepository.findByTicketId(idTicket);

        // Si une image existe ET si le ticket lié est bien un ticket de l'utilisateur connecté
        if (receiptPicture.isPresent() && receiptPicture.get().getTicket().getEmployeeIdentity().getId().equals(userId)) {
            // On supprime l'image
            receiptPictureRepository.deleteByTicketId(idTicket);
        }
    }
}
