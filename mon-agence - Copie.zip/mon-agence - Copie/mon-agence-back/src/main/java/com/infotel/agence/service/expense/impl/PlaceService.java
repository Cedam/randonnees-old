package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.Distance;
import com.infotel.agence.domain.expense.Place;
import com.infotel.agence.domain.expense.dto.DistanceDTO;
import com.infotel.agence.domain.expense.dto.PlaceDTO;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.PlaceRepository;
import com.infotel.agence.repository.expense.TicketRepository;
import com.infotel.agence.service.expense.IDistanceService;
import com.infotel.agence.service.expense.IPlaceService;

import ma.glasnost.orika.MapperFacade;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Service qui gère les entités {@link Place}
 *
 * @author arob
 */
@Service
public class PlaceService implements IPlaceService {

    public static final String UNKNOWN_PLACE = "Aucune place n''est référencée par l''id {0}";
    public static final String UNKNOWN_PLACES = "Aucune place n''est référencée par l''id {0} ou par l''id {1}";
    public static final String NON_NULL_PLACE = "La place doit être non-null !";

    private final PlaceRepository placeRepository;
    private final TicketRepository ticketRepository;
    private final IDistanceService distanceService;

    private final MapperFacade mapperFacade;

    public PlaceService(final PlaceRepository placeRepository,
                        final TicketRepository ticketRepository,
                        final IDistanceService distanceService,
                        final MapperFacade mapperFacade) {
        this.placeRepository = placeRepository;
        this.ticketRepository = ticketRepository;
        this.distanceService = distanceService;
        this.mapperFacade = mapperFacade;
    }

    @Override
    public Place findById(long id) {
        return placeRepository.findById(id)
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_PLACE, id));
    }

    @Override
    public List<Place> findAllList() {
        return placeRepository.findAll();
    }

    @Override
    public Page<Place> findAllPage(Pageable pageable) {
        return placeRepository.findAll(pageable);
    }

    @Override
    public Place create(PlaceDTO placeDTO) {
        if (placeDTO == null) {
            throw new TechnicalException(NON_NULL_PLACE);
        }

        return placeRepository.save(mapperFacade.map(placeDTO, Place.class));
    }

    @Override
    public Place update(long id, PlaceDTO placeDTO) {
        if (placeRepository.existsById(id)) {

            // Initialisation d'une entitée Place
            Place place = mapperFacade.map(placeDTO, Place.class);
            place.setId(id);

            // On dévalide les tickets concernées par la place
            ticketRepository.updateValidIfIdPlace(id, false);

            return placeRepository.save(place);
        }
        throw new UnknownEntityException(UNKNOWN_PLACE, id);
    }

    @Override
    public void merge(long placeIdDelete, long placeIdRecipient) {
        // On vérifie que les id de places existent
        if (!placeRepository.existsById(placeIdDelete) || !placeRepository.existsById(placeIdRecipient)) {
            throw new UnknownEntityException(UNKNOWN_PLACES, placeIdDelete, placeIdRecipient);
        }

        // Tous les tickets utilisant placeIdDelete ou placeIdRecipient seront modifiés à isValid=false.
        ticketRepository.updateValidIfIdPlace(placeIdDelete, false);
        ticketRepository.updateValidIfIdPlace(placeIdRecipient, false);

        // On récupère toutes les distances contenant la place que l'on souhaite supprimer
        List<Distance> distancesPlaceIdDelete;

        try {
            distancesPlaceIdDelete = distanceService.findByPlaceId(placeIdDelete);
        } catch (UnknownEntityException e) {
            // La place à supprimer ne contient aucune distance, elle peut être supprimer sans action supplementaire
            placeRepository.deleteById(placeIdDelete);
            return;
        }

        // Pour chacune de ces distances
        for (Distance distanceToDelete : distancesPlaceIdDelete) {
            // On regarde si une distance concurrente existe avec la place recevant le résultat de la fusion
            try {
                if (distanceToDelete.getPlaceStart().getId() == placeIdDelete) {
                    distanceService.findByPlacesId(distanceToDelete.getPlaceEnd().getId(), placeIdRecipient);
                } else {
                    distanceService.findByPlacesId(distanceToDelete.getPlaceStart().getId(), placeIdRecipient);
                }
                // Une distance concurrente existe déjà : on ne fait rien de plus en particulier
            } catch (UnknownEntityException e) {
                // Aucune distance concurrente n'existe : on crée une nouvelle distance pour placeIdRecipient
                Place placeRecipient = findById(placeIdRecipient);

                DistanceDTO newDistance = new DistanceDTO();
                newDistance.setPlaceStart(placeRecipient);
                newDistance.setValue(distanceToDelete.getValue());

                if (distanceToDelete.getPlaceStart().getId() == placeIdDelete) {
                    newDistance.setPlaceEnd(distanceToDelete.getPlaceEnd());
                } else {
                    newDistance.setPlaceEnd(distanceToDelete.getPlaceStart());
                }

                distanceService.create(newDistance);
            } finally {
                // finalement, on supprime la distance contenant placeIdDelete
                distanceService.deleteById(distanceToDelete.getId());
            }
        }

        // Pour conclure, la placeIdDelete est suprimée
        placeRepository.deleteById(placeIdDelete);
    }
}
