package com.infotel.agence.domain.expense.ticket;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.infotel.agence.domain.Resource;
import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.domain.expense.ReceiptPicture;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * Entité Ticket
 *
 * @author arob
 */
@Entity
@Data
@NoArgsConstructor
@Generated
@SuperBuilder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "TICKET",
        indexes = { @Index(name = "IDX_TIK_DATE", columnList = "TIK_CREATION_DATE"),
                @Index(name = "IDX_TIK_ARCHIVED", columnList = "TIK_DATE_ARCHIVED"),
                @Index(name = "IDX_TIK_CODE", columnList = "TIK_CODE") })
@Inheritance(strategy = InheritanceType.JOINED)
public class Ticket implements Resource {

    /**
     * Id du Ticket
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TIK_ID")
    private Long id;

    /**
     * Code correspondant au type du ticket
     */
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "TIK_CODE", length = 30)
    private TicketCode code;

    /**
     * Date du Ticket (justificatif)
     */
    @NotNull
    @Column(name = "TIK_CREATION_DATE")
    private LocalDate date;

    /**
     * Le ticket a t il été vérifié par l'utilisateur ?
     */
    @NotNull
    @Column(name = "TIK_IS_VALID")
    private boolean valid;

    /**
     * Le ticket a t il été archivé ? Si oui, une date est fournie, sinon, null.
     */
    @Column(name = "TIK_DATE_ARCHIVED")
    private LocalDate archived;

    /**
     * Image justificative du ticket
     */
    @OneToOne(mappedBy = "ticket", fetch = FetchType.LAZY)
    @JsonIgnore
    private ReceiptPicture receiptPicture;

    /**
     * Employée possédant le ticket
     */
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "EMPI_ID", foreignKey = @ForeignKey(name = "FK_TICKET_EMPLOYEEIDENTITY"))
    @JsonIgnore
    private EmployeeIdentity employeeIdentity;
}
