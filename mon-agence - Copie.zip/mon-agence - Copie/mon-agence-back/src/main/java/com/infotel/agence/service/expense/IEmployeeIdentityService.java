package com.infotel.agence.service.expense;

import com.infotel.agence.domain.expense.EmployeeIdentity;

import javax.annotation.security.RolesAllowed;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;
import static com.infotel.agence.security.SecurityRole.Constant.ROLE_EXPENSE;

/**
 * Interface pour le service qui gère les entités {@link EmployeeIdentity}
 *
 * @author arob
 */
public interface IEmployeeIdentityService {

    /**
     * Retourne l'identité d'employé actuellement connecté
     *
     * @return l'identité de l'employé
     */
    @RolesAllowed(ROLE_EXPENSE)
    EmployeeIdentity findCurrent();

    /**
     * Supprime l'identité employé désigné par l'id passé en paramètre
     *
     * @param id id de l'identé de l'employé
     */
    @RolesAllowed(ROLE_ADMIN)
    void deleteById(long id);
}
