package com.infotel.agence.config.security;

import lombok.Data;
import lombok.Generated;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;

/**
 * Propriétés pour la gestion des tokens JWT
 *
 * @author ARLI
 */
@Data
@Generated
@ConfigurationProperties(prefix = "security.jwt", ignoreUnknownFields = false)
@Validated
public class JwtProperties {

    @NotNull
    private String secretKey;

    @NotNull
    private Integer accessTokenValiditySeconds;

    @NotNull
    private Integer refreshTokenValiditySeconds;
}
