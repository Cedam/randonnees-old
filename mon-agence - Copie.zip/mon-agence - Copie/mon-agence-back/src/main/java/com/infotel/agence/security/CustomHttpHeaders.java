package com.infotel.agence.security;

public interface CustomHttpHeaders {
    String X_AUTHORIZATION = "x-authorization";
    String X_REFRESH = "x-refresh";
}
