package com.infotel.agence.domain.expense.export.line;

import org.apache.commons.math3.util.Pair;

/**
 * Classe permettant la gestion des zones à merger dans une ligne de tableur.
 *
 * @author arob
 */
public class MergeCellRegion extends Pair<Integer, Integer> {

    public MergeCellRegion(Integer start, Integer end) {
        super(start, end);
    }
}
