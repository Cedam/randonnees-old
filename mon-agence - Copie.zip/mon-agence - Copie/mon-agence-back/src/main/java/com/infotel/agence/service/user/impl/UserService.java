package com.infotel.agence.service.user.impl;

import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.user.UserRepository;
import com.infotel.agence.security.SecurityUtils;
import com.infotel.agence.service.expense.IEmployeeIdentityService;
import com.infotel.agence.service.expense.ITicketService;
import com.infotel.agence.service.user.IUserService;

import lombok.extern.log4j.Log4j2;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.lang.NonNull;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Service qui gère les entités {@link com.infotel.agence.domain.user.User}
 *
 * @author ARLI / AROB
 */
@Service
@Log4j2
public class UserService implements IUserService {
    public static final String UNKNOWN_USER = "Aucun utilisateur n''est référencé par l''id {0}";
    public static final String NOT_AUTHORIZED = "L'auto suppression n'est pas autorisée.";

    private final UserRepository userRepository;
    private final ITicketService ticketService;
    private final IEmployeeIdentityService employeeIdentityService;

    public UserService(final UserRepository userRepository,
                       final ITicketService ticketService,
                       final IEmployeeIdentityService employeeIdentityService) {
        this.userRepository = userRepository;
        this.ticketService = ticketService;
        this.employeeIdentityService = employeeIdentityService;
    }

    @Override
    public UserDetails loadUserByUsername(@NonNull String username) {
        return Optional.ofNullable(userRepository.findByUsername(username))
                .orElseThrow(() -> new UsernameNotFoundException("Unknown username"));
    }

    @Override
    public void setRefreshToken(@NonNull String username, @NonNull String refreshToken) {
        userRepository.setRefreshToken(username, refreshToken);
    }

    @Override
    public List<User> findAllList() {
        return userRepository.findAll();
    }

    @Override
    public Page<User> findAllPage(Pageable pageable) {
        return userRepository.findAll(pageable);
    }

    @Override
    public User findById(long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_USER, id));
    }

    @Override
    public void deleteById(long id) {
        // Si l'utilisateur qui va être supprimé est celui connecté
        if (SecurityUtils.getCurrentUserId() == id) {
            // On n'autorise pas la suppression
            throw new BusinessException(NOT_AUTHORIZED);
        }

        if (!userRepository.existsById(id)) {
            throw new UnknownEntityException(UNKNOWN_USER, id);
        }

        // Suppression pour le module note de frais
        ticketService.deleteAllOfUser(id);
        employeeIdentityService.deleteById(id);

        // Suppression globale
        userRepository.deleteById(id);
    }
}
