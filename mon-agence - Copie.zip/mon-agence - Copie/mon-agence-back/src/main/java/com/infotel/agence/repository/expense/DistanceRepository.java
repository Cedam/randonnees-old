package com.infotel.agence.repository.expense;

import com.infotel.agence.domain.expense.Distance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

/**
 * {@link Distance} repository
 *
 * @author arob
 */
@Repository
public interface DistanceRepository extends JpaRepository<Distance, Long>, QuerydslPredicateExecutor<Distance> {
}
