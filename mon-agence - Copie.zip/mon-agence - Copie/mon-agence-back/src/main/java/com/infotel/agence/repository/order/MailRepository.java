package com.infotel.agence.repository.order;

import com.infotel.agence.domain.order.Mail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * {@link Mail} repository
 *
 * @author JUBA
 */
@Repository
public interface MailRepository extends JpaRepository<Mail, Long> {
}
