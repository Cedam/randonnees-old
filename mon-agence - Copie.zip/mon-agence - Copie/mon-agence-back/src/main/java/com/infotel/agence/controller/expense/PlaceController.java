package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.Place;
import com.infotel.agence.domain.expense.dto.MergePlacesDTO;
import com.infotel.agence.domain.expense.dto.PlaceDTO;
import com.infotel.agence.service.expense.IPlaceService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.*;
import javax.validation.*;
import java.net.*;
import java.util.*;

import static com.infotel.agence.utils.URIUtils.buildCreatedResourceURI;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.ResponseEntity.*;

/**
 * Controleur pour la gestion des {@link Place}
 *
 * @author arob
 */
@RestController
@RequestMapping(value = "/api/places", produces = APPLICATION_JSON_VALUE)
public class PlaceController {

    private final IPlaceService placeService;

    public PlaceController(IPlaceService placeService) {
        this.placeService = placeService;
    }

    /**
     * Retourne la place référencée par l'id en paramètre
     *
     * @param id id
     * @return place
     */
    @GetMapping("/{id}")
    public ResponseEntity<Place> findPlaceById(@PathVariable long id) {
        return ok(placeService.findById(id));
    }

    /**
     * Retourne l'ensemble des places sous forme de liste
     *
     * @return liste des places
     */
    @GetMapping("/all")
    public ResponseEntity<List<Place>> findAllPlacesList() {
        return ok(placeService.findAllList());
    }

    /**
     * Retourne l'ensemble des places sous forme de page
     *
     * @return page des places
     */
    @GetMapping("")
    public ResponseEntity<Page<Place>> findAllPlacesPage(Pageable pageable) {
        return ok(placeService.findAllPage(pageable));
    }

    /**
     * Créer une nouvelle place
     *
     * @param placeDTO place
     * @return la nouvelle place
     */
    @PostMapping(value = "", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Place> createPlace(@Valid @RequestBody PlaceDTO placeDTO, HttpServletRequest httpServletRequest) {
        Place newPlace = placeService.create(placeDTO);
        URI location = buildCreatedResourceURI(httpServletRequest, newPlace);
        return created(location).body(newPlace);
    }

    /**
     * Met à jour une place existante
     *
     * @param id       id de la place
     * @param placeDTO place
     * @return la place mise à jour
     */
    @PutMapping(value = "/{id}", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Place> updatePlace(@PathVariable long id, @Valid @RequestBody PlaceDTO placeDTO) {
        return ok(placeService.update(id, placeDTO));
    }

    /**
     * Fusionne la placeA dans la placeB.
     * Tous les tickets utilisant placeA ou placeB seront modifiés à isValid=false.
     * Toutes les distances pointant vers placeA pointeront vers placeB. Si une distance existante vers placeB rentre
     * en conflit avec une des modifications, cette modification est ignorée.
     * La placeA sera suprimée.
     *
     * @param mergePlacesDTO les ids des places à fusionner
     * @return un noContent
     */
    @PostMapping(value = "/merge", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> mergePlaces(@RequestBody MergePlacesDTO mergePlacesDTO) {
        placeService.merge(mergePlacesDTO.getPlaceIdDelete(), mergePlacesDTO.getPlaceIdRecipient());
        return noContent().build();
    }
}
