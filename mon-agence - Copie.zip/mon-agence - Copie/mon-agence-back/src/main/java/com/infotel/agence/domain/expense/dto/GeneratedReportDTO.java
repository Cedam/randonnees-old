package com.infotel.agence.domain.expense.dto;

import com.infotel.agence.domain.expense.GeneratedReport;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * DTO de la classe {@link GeneratedReport}
 *
 * @author arob
 */
@Data
@Generated
@NoArgsConstructor
@AllArgsConstructor
public class GeneratedReportDTO {

    /**
     * Id de l'archive
     */
    private Long id;

    /**
     * Date de création du rapport
     */
    private LocalDate creationDate;

    /**
     * Mois désigné par le compte rendu
     */
    private int month;
}
