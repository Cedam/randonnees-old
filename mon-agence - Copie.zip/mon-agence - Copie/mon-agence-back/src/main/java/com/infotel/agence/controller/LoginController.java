package com.infotel.agence.controller;

import com.infotel.agence.domain.user.User;
import com.infotel.agence.security.SecurityUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

/**
 * Controleur pour la gestion de l'authentification
 *
 * @author ARLI
 */
@Controller
@RequestMapping(value = "api/login", produces = MediaType.APPLICATION_JSON_VALUE)
public class LoginController {

    /**
     * Renvoie le détail de l'utilisateur après avoir validé ses identifiants de connexion
     *
     * @return {@link User}
     */
    @PostMapping
    public ResponseEntity<User> identifyUser() {
        return SecurityUtils.getCurrentUser()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
    }

    @PostMapping("/renew")
    public ResponseEntity<Void> renewAccessToken(HttpServletRequest request) {
        // TODO ALI à implémenter
        return ResponseEntity.ok().build();
    }
}
