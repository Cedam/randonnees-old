package com.infotel.agence.service.expense;

import com.infotel.agence.domain.expense.GeneratedReport;
import com.infotel.agence.domain.expense.dto.GeneratedReportDTO;

import javax.annotation.security.RolesAllowed;
import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.util.List;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_EXPENSE;
import static com.infotel.agence.security.SecurityRole.Constant.ROLE_SYSTEM;

public interface IGeneratedReportService {
    /**
     * Crée une nouvelle archive de compte rendu
     *
     * @param generatedReport le comtpe rendu
     * @return la nouvelle archive
     */
    @RolesAllowed({ ROLE_EXPENSE })
    GeneratedReport create(GeneratedReport generatedReport);

    /**
     * Retourne l'ensemble des archives sous forme de list
     *
     * @return la liste des archives
     */
    @RolesAllowed({ ROLE_EXPENSE })
    List<GeneratedReportDTO> findAllList();

    /**
     * Retourne le byteArray du fichier Pdf de l'archive dont l'id est passé en paramètre.
     *
     * @param id           id de l'archive
     * @param outputStream
     * @throws IOException
     */
    @RolesAllowed({ ROLE_EXPENSE })
    void findPdfFileOfId(long id, OutputStream outputStream) throws IOException;

    /**
     * Retourne le byteArray du fichier Excel de l'archive dont l'id est passé en paramètre.
     *
     * @param id           id de l'archive
     * @param outputStream
     * @throws IOException
     */
    @RolesAllowed({ ROLE_EXPENSE })
    void findXlsxFileOfId(long id, OutputStream outputStream) throws IOException;

    /**
     * Retourne le byteArray du fichier Zip de l'archive dont l'id est passé en paramètre.
     *
     * @param id           id de l'archive
     * @param outputStream
     * @throws IOException
     */
    @RolesAllowed({ ROLE_EXPENSE })
    void findZipFileOfId(long id, OutputStream outputStream) throws IOException;

    /**
     * Permets de récuperer le nom à donner aux fichiers de l'archive dont l'id est passé en paramètre.
     *
     * @param id id de l'archive
     * @return
     */
    @RolesAllowed({ ROLE_EXPENSE })
    String getFilename(long id);

    /**
     * Fonction appelée afin de supprimer toutes les archives plus anciennes que la date en paramètre.
     *
     * @param date
     */
    @RolesAllowed(ROLE_SYSTEM)
    void deleteGeneratedReportsOlderThan(LocalDate date);
}
