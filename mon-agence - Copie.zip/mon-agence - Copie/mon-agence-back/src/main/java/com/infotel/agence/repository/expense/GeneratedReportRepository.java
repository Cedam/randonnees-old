package com.infotel.agence.repository.expense;

import com.infotel.agence.domain.expense.GeneratedReport;
import com.infotel.agence.domain.expense.dto.GeneratedReportDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

/**
 * {@link GeneratedReport} repository
 *
 * @author arob
 */
@Repository
public interface GeneratedReportRepository extends JpaRepository<GeneratedReport, Long> {

    GeneratedReport findOneById(long id);

    @Query("SELECT NEW com.infotel.agence.domain.expense.dto.GeneratedReportDTO(id, creationDate, month) " +
            "FROM GeneratedReport " +
            "WHERE employeeIdentity.id = :userId " +
            "ORDER BY creationDate DESC")
    List<GeneratedReportDTO> findAllGeneratedReportDTO(@Param("userId") Long userId);

    @Query("SELECT pdfFile " +
            "FROM GeneratedReport " +
            "WHERE id = :generatedReportId")
    byte[] findPdfFileOfId(@Param("generatedReportId") Long generatedReportId);

    @Query("SELECT xlsxFile " +
            "FROM GeneratedReport " +
            "WHERE id = :generatedReportId")
    byte[] findXlsxFileOfId(@Param("generatedReportId") Long generatedReportId);

    @Query("SELECT zipFile " +
            "FROM GeneratedReport " +
            "WHERE id = :generatedReportId")
    byte[] findZipFileOfId(@Param("generatedReportId") Long generatedReportId);

    @Query("SELECT COUNT(id) " +
            "FROM GeneratedReport " +
            "WHERE id = :generatedReportId AND employeeIdentity.id = :userId ")
    long existsByIdForUserId(@Param("generatedReportId") Long generatedReportId, @Param("userId") Long userId);

    @Transactional
    @Modifying
    @Query("DELETE FROM GeneratedReport WHERE creationDate < :date")
    int deleteGeneratedReportsOlderThan(@Param("date") LocalDate date);
}
