package com.infotel.agence.config.property;

import lombok.Data;
import lombok.Generated;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

/**
 * Propriétés liées au module "Note de frais".
 *
 * @author ARLI
 */
@Data
@Generated
@ConfigurationProperties(prefix = "expense", ignoreUnknownFields = false)
@Validated
public class ExpenseProperties {

    /**
     * Chemin vers le template excel pour la génration des Notes de frais
     */
    @NotEmpty
    private String excelTemplatePath;

    /**
     *
     */
    @NotEmpty
    private String pdfSeparatorFolderPath;

    /**
     * Durée de conservation des tickets archivés avant leur purge automatique
     */
    @Positive
    private Integer ticketsExpirationDelayMonths;

    /**
     * Durée de conservation des fichiers générés avant leur purge automatique
     */
    @Positive
    private Integer reportsExpirationDelayMonths;

}
