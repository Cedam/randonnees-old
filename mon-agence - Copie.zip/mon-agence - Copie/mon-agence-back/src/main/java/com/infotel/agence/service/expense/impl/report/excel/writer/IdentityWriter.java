package com.infotel.agence.service.expense.impl.report.excel.writer;

import com.infotel.agence.domain.expense.export.ExcelEmployeeIdentity;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.util.Pair;

import java.util.Map;
import java.util.function.Function;

import static com.infotel.agence.service.expense.impl.report.excel.ExcelFileGenerator.*;

/**
 * Gère l'écriture des informations liés à l'identité de l'utilisateur.
 *
 * @author arob
 */
public class IdentityWriter extends AbstractCellWriter {
    // Liste des fonctions à appeler pour l'identité simple
    private static final Map<Pair<Integer, Integer>, Function<ExcelEmployeeIdentity, ?>> BINDING_SIMPLE_IDENTITY = Map.of(
            Pair.of(2, 1), ExcelEmployeeIdentity::getFullName,
            Pair.of(2, 4), ExcelEmployeeIdentity::getSerialNumber,
            Pair.of(2, 6), ExcelEmployeeIdentity::getMonth,
            Pair.of(3, 1), ExcelEmployeeIdentity::getAgency,
            Pair.of(3, 4), ExcelEmployeeIdentity::getCustomer,
            Pair.of(3, 6), ExcelEmployeeIdentity::getOperationCode
    );

    // Liste des fonctions à appeler pour l'identité complexe
    private static final Map<Pair<Integer, Integer>, Function<ExcelEmployeeIdentity, ?>> BINDING_COMPLEX_IDENTITY = Map.of(
            Pair.of(2, 1), ExcelEmployeeIdentity::getFullName,
            Pair.of(2, 4), ExcelEmployeeIdentity::getSerialNumber,
            Pair.of(2, 8), ExcelEmployeeIdentity::getMonth,
            Pair.of(3, 1), ExcelEmployeeIdentity::getAgency,
            Pair.of(3, 4), ExcelEmployeeIdentity::getCustomer,
            Pair.of(3, 8), ExcelEmployeeIdentity::getOperationCode,
            Pair.of(4, 1), ExcelEmployeeIdentity::getLicencePlate,
            Pair.of(4, 4), ExcelEmployeeIdentity::getCv,
            Pair.of(4, 8), ExcelEmployeeIdentity::getMileageAllowance
    );

    public IdentityWriter(XSSFWorkbook workbook) {
        super(workbook);
    }

    /**
     * Permet d'écrire d'identité dans une feuille donnée
     *
     * @param identity identité de l'employé
     * @param sheet    feuille de calcul
     * @param binding  mapping des positions des cellules avec les extracteurs des valeurs
     */
    private void write(ExcelEmployeeIdentity identity, XSSFSheet sheet, Map<Pair<Integer, Integer>, Function<ExcelEmployeeIdentity, ?>> binding) {
        binding.forEach((coordinate, fn) -> {
            final XSSFCell cell = sheet.getRow(coordinate.getFirst()).getCell(coordinate.getSecond());
            fillOneCell(cell, fn.apply(identity));
        });
    }

    /**
     * Permet d'écrire l'identité dans toutes les feuilles nécessaire.
     *
     * @param identity identité de l'employé
     */
    public void write(ExcelEmployeeIdentity identity) {
        write(identity, getSheet(SHEET_CUSTOMER_MEAL_COST), BINDING_SIMPLE_IDENTITY);
        write(identity, getSheet(SHEET_SITE_MEAL_COST), BINDING_SIMPLE_IDENTITY);
        write(identity, getSheet(SHEET_VARIOUS_COST), BINDING_SIMPLE_IDENTITY);
        write(identity, getSheet(SHEET_EXCEPTIONAL_BUSINESS_TRAVEL), BINDING_COMPLEX_IDENTITY);
    }
}
