package com.infotel.agence.repository.user;

import com.infotel.agence.domain.user.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * {@link User} repository
 *
 * @author ARLI
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Retourne l'utilisateur qui possède le login passé en paramètre
     *
     * @param username login utilisateur
     * @return un utilisateur ou null si le login est inconnu
     */
    User findByUsername(String username);

    /**
     * Mise à jour du token de rafraichissement pour un user donné
     *
     * @param username     login utilisateur
     * @param refreshToken token de rafraichissement
     */
    @Transactional
    @Modifying
    @Query("UPDATE User u SET u.refreshToken = :refreshToken WHERE u.username = :username")
    void setRefreshToken(@Param("username") String username, @Param("refreshToken") String refreshToken);
}
