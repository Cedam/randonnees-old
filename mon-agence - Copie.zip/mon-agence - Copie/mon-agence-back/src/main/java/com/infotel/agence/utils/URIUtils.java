package com.infotel.agence.utils;

import com.infotel.agence.domain.Resource;

import org.springframework.lang.NonNull;

import javax.servlet.http.*;
import java.net.*;

/**
 * Ensemble de fonction utiles pour les {@link URI}
 *
 * @author ARLI
 */
public class URIUtils {

    private URIUtils() {
        // private constructor
    }

    /**
     * Ajoute l'id de la resource créée à la fin de l'url courante
     *
     * @param request  request
     * @param resource resource
     * @return URI
     */
    public static URI buildCreatedResourceURI(HttpServletRequest request, @NonNull Resource resource) {
        return URI.create(request.getRequestURI() + "/" + resource.getId()).normalize();
    }
}
