package com.infotel.agence.repository.order;

import com.infotel.agence.domain.order.Request;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * {@link Request} repository
 *
 * @author JUBA
 */
@Repository
public interface RequestRepository extends JpaRepository<Request, Long> {
}
