package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.domain.expense.dto.TicketDTO;
import com.infotel.agence.domain.expense.dto.TicketStatisticsDTO;
import com.infotel.agence.domain.expense.ticket.*;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.TicketRepository;
import com.infotel.agence.repository.user.UserRepository;
import com.infotel.agence.security.SecurityUtils;
import com.infotel.agence.service.expense.ICompensationService;
import com.infotel.agence.service.expense.IReceiptPictureService;
import com.infotel.agence.service.expense.ITicketService;

import com.querydsl.core.types.dsl.BooleanExpression;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.collections4.IterableUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.math.*;
import java.time.*;
import java.util.*;

/**
 * Service qui gère les entités {@link Ticket}
 *
 * @author arob
 */
@Service
@Log4j2
public class TicketService implements ITicketService {

    public static final String UNKNOWN_TICKET = "Aucun ticket n''est référencé par l''id {0}.";
    public static final String NULL_TICKET_CODE = "Le code du ticket ne doit pas être null !";
    public static final String UNKNOWN_TICKET_CODE = "Le code du ticket est inconnu !";
    public static final String NULL_DATES = "Une date de début (startDate) et une date de fin (endDate) doivent être présent et non null.";
    public static final String NULL_DATE_DELETE_OLDER = "La date de suppression doit être différente de nulle.";
    public static final String UNKNOWN_USER_ID = "Aucun utilisateur n''est référencé par l''id {0}.";

    private final TicketRepository ticketRepository;
    private final ICompensationService compensationService;
    private final IReceiptPictureService receiptPictureService;
    private final UserRepository userRepository;

    public TicketService(final TicketRepository ticketRepository,
                         final ICompensationService compensationService,
                         final IReceiptPictureService receiptPictureService,
                         final UserRepository userRepository) {
        this.ticketRepository = ticketRepository;
        this.compensationService = compensationService;
        this.receiptPictureService = receiptPictureService;
        this.userRepository = userRepository;
    }

    @Override
    public Ticket findById(long id) {
        Long userId = SecurityUtils.getCurrentUserId();

        return ticketRepository.findById(id)
                .filter(ticket -> ticket.getEmployeeIdentity().getId().equals(userId))
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_TICKET, id));
    }

    @Override
    public Page<Ticket> findAll(Pageable pageable, TicketCode ticketCode, LocalDate startDate, LocalDate endDate, Boolean isArchived) {
        Long userId = SecurityUtils.getCurrentUserId();

        // On envoit que les tickets de l'user actuellement connecté
        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId);

        if (ticketCode != null) {
            predicate = predicate.and(QTicket.ticket.code.eq(ticketCode));
        }

        if (startDate != null && endDate != null) {
            predicate = predicate.and(QTicket.ticket.date.between(startDate, endDate));
        }

        // Si iArchived == false -> on ne veut pas voir les ticket archivés
        if (isArchived != null && !isArchived) {
            //Alors on demande à ce que tous nos tickets aient isArchived a null
            predicate = predicate.and(QTicket.ticket.archived.isNull());
        }

        return ticketRepository.findAll(predicate, pageable);
    }

    @Override
    public List<Ticket> findAllToVerify() {
        Long userId = SecurityUtils.getCurrentUserId();

        // On envoit que les tickets de l'user actuellement connecté
        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId)
                // On envoit que les tickets non-validés
                .and(QTicket.ticket.valid.eq(false));

        return IterableUtils.toList(ticketRepository.findAll(predicate, Sort.by(Sort.Order.asc("code"), Sort.Order.asc("date"))));
    }

    @Override
    public Map<TicketCode, List<Ticket>> findAllToGenerate(LocalDate startDate, LocalDate endDate) {
        Long userId = SecurityUtils.getCurrentUserId();

        Map<TicketCode, List<Ticket>> res = new LinkedHashMap<>();

        // On ne considère que les tickets de l'utilisateur actuellement connecté
        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId)

                // On ne considère que les tickets validés
                .and(QTicket.ticket.valid.eq(true))

                // On ne considère que les tickets non archivés
                .and(QTicket.ticket.archived.isNull())

                // On ne considère que les tickets présent dans la période temporelle demandée
                .and(QTicket.ticket.date.between(startDate, endDate));

        for (TicketCode code : TicketCode.values()) {
            List<Ticket> tickets = new ArrayList<>();
            // On ne considère que les tickets du type actuel
            ticketRepository.findAll(predicate.and(QTicket.ticket.code.eq(code))).forEach(tickets::add);

            res.put(code, tickets);
        }

        return res;
    }

    @Override
    public void deleteById(long id) {
        Long userId = SecurityUtils.getCurrentUserId();

        Optional<Ticket> ticket = ticketRepository.findById(id);
        // On ne supprime que si c'est un ticket de l'user actuellement connecté
        if (ticket.isPresent() && ticket.get().getEmployeeIdentity().getId().equals(userId)) {
            receiptPictureService.deleteByTicketId(id);
            ticketRepository.deleteById(id);
        } else {
            throw new UnknownEntityException(UNKNOWN_TICKET, id);
        }
    }

    @Override
    public void deleteAllOfUser(long userId) {
        if (!userRepository.existsById(userId)) {
            throw new UnknownEntityException(UNKNOWN_USER_ID, userId);
        }

        log.error("~~~~~ Suppression de " + ticketRepository.deleteTicketsOfUser(userId) + " tickets.");
    }

    @Override
    public Map<String, LocalDate> getLimits() {
        Long userId = SecurityUtils.getCurrentUserId();

        LocalDate olderDate = ticketRepository.findOlderDate(userId);
        LocalDate youngerDate = ticketRepository.findYoungerDate(userId);

        return Map.ofEntries(
                new AbstractMap.SimpleEntry<>("olderDate", (olderDate != null ? olderDate : LocalDate.now())),
                new AbstractMap.SimpleEntry<>("youngerDate", (youngerDate != null ? youngerDate : LocalDate.now())));
    }

    @Override
    public Ticket create(TicketDTO ticketDTO) {
        Ticket ticket = fillTicket(null, ticketDTO);

        return ticketRepository.save(ticket);
    }

    @Override
    public Ticket update(long id, TicketDTO ticketDTO) {
        Ticket ticket = findById(id);

        ticket = fillTicket(ticket, ticketDTO);

        return ticketRepository.save(ticket);
    }

    private Ticket fillTicket(Ticket existingTicket, TicketDTO ticketDTO) {
        Ticket newTicket;

        Long userId = SecurityUtils.getCurrentUserId();

        if (ticketDTO.getCode() == null) {
            throw new TechnicalException(NULL_TICKET_CODE);
        }

        switch (ticketDTO.getCode()) {
            case CUSTOMER_MEAL_COST:
                newTicket = fillTicketCustomerMealCost((CustomerMealCostTicket) existingTicket, ticketDTO);
                break;
            case EXCEPTIONAL_BUSINESS_TRAVEL:
                newTicket = fillTicketExceptionalBusinessTravel((ExceptionalBusinessTravelTicket) existingTicket, ticketDTO);
                break;
            case FUEL:
                newTicket = fillTicketFuel((FuelTicket) existingTicket, ticketDTO);
                break;
            case LODGING_MEAL_BUSINESS:
                newTicket = fillTicketLodgingMealBusiness((LodgingMealBusinessTicket) existingTicket, ticketDTO);
                break;
            case SITE_MEAL_COST:
                newTicket = fillTicketSiteMealCost((SiteMealCostTicket) existingTicket, ticketDTO);
                break;
            case VARIOUS_BUSINESS_TRAVEL:
                newTicket = fillTicketVariousBusinessTravel((VariousBusinessTravelTicket) existingTicket, ticketDTO);
                break;
            case VARIOUS_COST:
                newTicket = fillTicketVariousCost((VariousCostTicket) existingTicket, ticketDTO);
                break;
            default:
                throw new TechnicalException(UNKNOWN_TICKET_CODE);
        }

        newTicket.setDate(ticketDTO.getDate());
        newTicket.setValid(ticketDTO.isValid());
        newTicket.setArchived(ticketDTO.getIsArchived());
        newTicket.setReceiptPicture(ticketDTO.getReceiptPicture());

        if (existingTicket == null) {
            newTicket.setCode(ticketDTO.getCode());

            // On fixe l'employée qui possède le ticket
            EmployeeIdentity empi = new EmployeeIdentity();
            empi.setId(userId);
            newTicket.setEmployeeIdentity(empi);
        }

        return newTicket;
    }

    private Ticket fillTicketCustomerMealCost(CustomerMealCostTicket existingTicket, TicketDTO ticketDTO) {
        CustomerMealCostTicket newTicket = existingTicket == null ? new CustomerMealCostTicket() : existingTicket;

        newTicket.setCustomer(ticketDTO.getCustomer());
        newTicket.setEmployeeAmount(ticketDTO.getEmployeeAmount());
        newTicket.setCompanyAmount(ticketDTO.getCompanyAmount());

        return newTicket;
    }

    private Ticket fillTicketExceptionalBusinessTravel(ExceptionalBusinessTravelTicket existingTicket, TicketDTO ticketDTO) {
        ExceptionalBusinessTravelTicket newTicket = existingTicket == null ? new ExceptionalBusinessTravelTicket() : existingTicket;

        newTicket.setStartPlace(ticketDTO.getStartPlace());
        newTicket.setEndPlace(ticketDTO.getEndPlace());
        newTicket.setVehicle(ticketDTO.getVehicle());
        newTicket.setCustomer(ticketDTO.getCustomer());
        newTicket.setCompanyAmount(ticketDTO.getCompanyAmount());

        return newTicket;
    }

    private Ticket fillTicketFuel(FuelTicket existingTicket, TicketDTO ticketDTO) {
        FuelTicket newTicket = existingTicket == null ? new FuelTicket() : existingTicket;

        newTicket.setPurpose(ticketDTO.getPurpose());
        newTicket.setCustomer(ticketDTO.getCustomer());
        newTicket.setEmployeeAmount(ticketDTO.getEmployeeAmount());
        newTicket.setCompanyAmount(ticketDTO.getCompanyAmount());

        return newTicket;
    }

    private Ticket fillTicketLodgingMealBusiness(LodgingMealBusinessTicket existingTicket, TicketDTO ticketDTO) {
        LodgingMealBusinessTicket newTicket = existingTicket == null ? new LodgingMealBusinessTicket() : existingTicket;

        newTicket.setBedroomAmount(ticketDTO.getBedroomAmount());
        newTicket.setBreakfastAmount(ticketDTO.getBreakfastAmount());
        newTicket.setLunchAmount(ticketDTO.getLunchAmount());
        newTicket.setDinnerAmount(ticketDTO.getDinnerAmount());
        newTicket.setCustomer(ticketDTO.getCustomer());
        newTicket.setCompanyAmount(ticketDTO.getCompanyAmount());

        return newTicket;
    }

    private Ticket fillTicketSiteMealCost(SiteMealCostTicket existingTicket, TicketDTO ticketDTO) {
        SiteMealCostTicket newTicket = existingTicket == null ? new SiteMealCostTicket() : existingTicket;

        newTicket.setSiteOrMeeting(ticketDTO.getSiteOrMeeting());
        newTicket.setEmployeeAmount(ticketDTO.getEmployeeAmount());
        newTicket.setCompanyAmount(ticketDTO.getCompanyAmount());

        return newTicket;
    }

    private Ticket fillTicketVariousBusinessTravel(VariousBusinessTravelTicket existingTicket, TicketDTO ticketDTO) {
        VariousBusinessTravelTicket newTicket = existingTicket == null ? new VariousBusinessTravelTicket() : existingTicket;

        newTicket.setPurpose(ticketDTO.getPurpose());
        newTicket.setCustomer(ticketDTO.getCustomer());
        newTicket.setEmployeeAmount(ticketDTO.getEmployeeAmount());
        newTicket.setCompanyAmount(ticketDTO.getCompanyAmount());

        return newTicket;
    }

    private Ticket fillTicketVariousCost(VariousCostTicket existingTicket, TicketDTO ticketDTO) {
        VariousCostTicket newTicket = existingTicket == null ? new VariousCostTicket() : existingTicket;

        newTicket.setPurpose(ticketDTO.getPurpose());
        newTicket.setCustomer(ticketDTO.getCustomer());
        newTicket.setEmployeeAmount(ticketDTO.getEmployeeAmount());
        newTicket.setCompanyAmount(ticketDTO.getCompanyAmount());

        return newTicket;
    }

    public Map<TicketCode, TicketStatisticsDTO> statistics(LocalDate startDate, LocalDate endDate) {
        Long userId = SecurityUtils.getCurrentUserId();
        BigDecimal mileageAllowance = compensationService.getCurrentUserMileageAllowance();

        if (startDate == null || endDate == null) {
            throw new BusinessException(NULL_DATES);
        }

        Map<TicketCode, TicketStatisticsDTO> stats = new LinkedHashMap<>();

        stats.put(TicketCode.CUSTOMER_MEAL_COST,
                ticketRepository.statsValueTicketCustomerMealCost(userId,
                        startDate,
                        endDate));

        stats.put(TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL,
                ticketRepository.statsValueTicketExceptionalBusinessTravel(userId, mileageAllowance,
                        startDate,
                        endDate));

        stats.put(TicketCode.FUEL,
                ticketRepository.statsValueTicketFuel(userId,
                        startDate,
                        endDate));

        stats.put(TicketCode.LODGING_MEAL_BUSINESS,
                ticketRepository.statsValueTicketLodgingMealBusiness(userId,
                        startDate,
                        endDate));

        stats.put(TicketCode.SITE_MEAL_COST,
                ticketRepository.statsValueTicketSiteMealCost(userId,
                        startDate,
                        endDate));

        stats.put(TicketCode.VARIOUS_BUSINESS_TRAVEL,
                ticketRepository.statsValueTicketVariousBusinessTravel(userId,
                        startDate,
                        endDate));

        stats.put(TicketCode.VARIOUS_COST,
                ticketRepository.statsValueTicketVariousCost(userId,
                        startDate,
                        endDate));

        return stats;
    }

    public Ticket updateValidity(long ticketId, boolean valid) {
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_TICKET, ticketId));

        ticket.setValid(valid);

        return ticketRepository.save(ticket);
    }

    public void archiveTicketBetween(LocalDate startDate, LocalDate endDate) {
        ticketRepository.archiveTicketBetween(SecurityUtils.getCurrentUserId(), startDate, endDate, LocalDate.now());
    }

    @Override
    public void deleteTicketsOlderThan(LocalDate date) {
        if (date == null) {
            throw new BusinessException(NULL_DATE_DELETE_OLDER);
        }

        int nbDeleted = ticketRepository.deleteTicketsOlderThan(date);
        log.info("Suppression de {} tickets lors de la purge mensuelle automatique.", nbDeleted);
    }
}
