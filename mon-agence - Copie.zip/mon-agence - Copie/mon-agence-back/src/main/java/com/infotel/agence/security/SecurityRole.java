package com.infotel.agence.security;

import com.infotel.agence.domain.user.Authority;

/**
 * Définition des roles des utilisateurs
 *
 * @author ARLI
 */
public enum SecurityRole {
    ADMIN(Constant.ROLE_ADMIN),
    SYSTEM(Constant.ROLE_SYSTEM),
    EXPENSE(Constant.ROLE_EXPENSE),
    ADMIN_EXPENSE(Constant.ROLE_ADMIN_EXPENSE),
    SUPPLY(Constant.ROLE_SUPPLY),
    ADMIN_SUPPLY(Constant.ROLE_ADMIN_SUPPLY);

    private String role;

    SecurityRole(String role) {
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    public Authority toAuthority() {
        return new Authority(role);
    }

    /**
     * Pour les annotations @RolesAllowed, @Secured, @PreAuthorized ..., il faut utiliser les constantes ci-dessous.
     */
    public class Constant {
        private Constant() {
            // private construtor
        }

        private static final String ROLE_PREFIX = "ROLE_";

        public static final String ROLE_SYSTEM = ROLE_PREFIX + "SYSTEM";
        public static final String ROLE_ADMIN = ROLE_PREFIX + "ADMIN";
        public static final String ROLE_EXPENSE = ROLE_PREFIX + "EXPENSE";
        public static final String ROLE_ADMIN_EXPENSE = ROLE_PREFIX + "ADMIN_EXPENSE";
        public static final String ROLE_SUPPLY = ROLE_PREFIX + "SUPPLY";
        public static final String ROLE_ADMIN_SUPPLY = ROLE_PREFIX + "ADMIN_SUPPLY";
    }
}
