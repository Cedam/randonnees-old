package com.infotel.agence.domain.expense.ticket;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**
 * Entité Ticket pour un frais lié à un repas ou à un hebergement
 *
 * @author arob
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Generated
@SuperBuilder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "TICKET_LODGING_MEAL_BUSINESS")
@PrimaryKeyJoinColumn(foreignKey = @ForeignKey(name = "FK_TICKETLODGINGMEALBUSINESS_TICKET"))
public class LodgingMealBusinessTicket extends Ticket {

    /**
     * Somme payer par l'employe pour une chambre sur le TicketLodgingMealBusiness
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée pour la chambre ne peut pas dépasser 9999,99")
    @Column(name = "TLMB_BEDROOM_AMOUNT")
    private BigDecimal bedroomAmount;

    /**
     * Sommes payer par l'employe pour un petit dejeuner sur le TicketLodgingMealBusiness
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée pour un petit déjeuner ne peut pas dépasser 9999,99")
    @Column(name = "TLMB_BREAKFAST_AMOUNT")
    private BigDecimal breakfastAmount;

    /**
     * Sommes payer par l'employe pour un dejeuner sur le TicketLodgingMealBusiness
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée pour un déjeuner ne peut pas dépasser 9999,99")
    @Column(name = "TLMB_LUNCH_AMOUNT")
    private BigDecimal lunchAmount;

    /**
     * Sommes payer par l'employe pour un diner sur le TicketLodgingMealBusiness
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée pour un diner ne peut pas dépasser 9999,99")
    @Column(name = "TLMB_DINNER_AMOUNT")
    private BigDecimal dinnerAmount;

    /**
     * Client du TicketLodgingMealBusiness
     */
    @Size(max = 255, message = "Le nom du client ne doit pas dépasser 255 caractères")
    @Column(name = "TLMB_CUSTOMER")
    private String customer;

    /**
     * Somme prépayer par l'entreprise pour le TicketLodgingMealBusiness
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur prepayé par l'entreprise ne peut pas dépasser 9999,99")
    @Column(name = "TLMB_COMPANY_AMOUNT")
    private BigDecimal companyAmount;
}
