package com.infotel.agence.domain.order;

import com.infotel.agence.domain.Resource;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Entité Article
 *
 * @author JUBA
 */
@Entity
@Data
@Table(name = "ARTICLE", uniqueConstraints = @UniqueConstraint(columnNames = { "ART_NAME" }, name = "UC_ART_NAME"))
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Builder
@Generated
public class Article implements Resource {

    /**
     * Id de l'article
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ART_ID")
    private Long id;

    /**
     * Nom de l'article
     */
    @NotNull
    @Size(max = 30, message = "Le nom ne doit pas dépasser 30 caractères")
    @Column(name = "ART_NAME", length = 30)
    private String name;

    /**
     * Description de l'article
     */
    @NotNull
    @Size(max = 100, message = "La description ne doit pas dépasser 100 caractères")
    @Column(name = "ART_DESCRIPTION", length = 100)
    private String description;

    /**
     * Quantité de l'article
     * TODO ALI vérifier comment amount est utilisé car cela me parait bizarre comme modélisation.
     */
    @Column(name = "ART_AMOUNT")
    private int amount;

}
