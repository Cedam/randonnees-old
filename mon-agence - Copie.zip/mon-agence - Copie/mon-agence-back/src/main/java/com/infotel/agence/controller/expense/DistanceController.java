package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.Distance;
import com.infotel.agence.domain.expense.dto.DistanceDTO;
import com.infotel.agence.service.expense.IDistanceService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.*;
import javax.validation.*;
import java.net.*;

import static com.infotel.agence.utils.URIUtils.buildCreatedResourceURI;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.ResponseEntity.created;
import static org.springframework.http.ResponseEntity.ok;

/**
 * Controleur pour la gestion des {@link Distance}
 *
 * @author arob
 */
@RestController
@RequestMapping(value = "/api/distances", produces = APPLICATION_JSON_VALUE)
public class DistanceController {

    private final IDistanceService distanceService;

    public DistanceController(IDistanceService distanceService) {
        this.distanceService = distanceService;
    }

    /**
     * Récupérer la distance entre deux places données
     *
     * @param idPlaceA l'id de la première place
     * @param idPlaceB l'id de la seconde place
     * @return la distance entre les deux places
     */
    @GetMapping(value = "/byPlacesId")
    public ResponseEntity<Distance> findDistanceByPlacesId(long idPlaceA, long idPlaceB) {
        return ok(distanceService.findByPlacesId(idPlaceA, idPlaceB));
    }

    /**
     * Récupérer la distance d'un id donné
     *
     * @param id l'id de la distance
     * @return une distance
     */
    @GetMapping(value = "/{id}")
    public ResponseEntity<Distance> findDistanceById(@PathVariable long id) {
        return ok(distanceService.findById(id));
    }

    /**
     * Sauvegarder la distance entre deux places données
     *
     * @param distanceDTO distance
     * @return la distance nouvellement créée
     */
    @PostMapping(value = "", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Distance> createDistance(@Valid @RequestBody DistanceDTO distanceDTO, HttpServletRequest httpServletRequest) {
        Distance newDistance = distanceService.create(distanceDTO);
        URI location = buildCreatedResourceURI(httpServletRequest, newDistance);
        return created(location).body(newDistance);
    }

    /**
     * Met à jour une distance existante
     *
     * @param id          id de la distance
     * @param distanceDTO distance
     * @return la distance mise à jour
     */
    @PutMapping(value = "/{id}", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Distance> updateDistance(@PathVariable long id, @Valid @RequestBody DistanceDTO distanceDTO) {
        return ok(distanceService.update(id, distanceDTO));
    }

    /**
     * Retourne l'ensemble des distances sous forme de page
     *
     * @return page des distances
     */
    @GetMapping("")
    public ResponseEntity<Page<Distance>> findAllDistances(Pageable pageable) {
        return ok(distanceService.findAll(pageable));
    }
}
