package com.infotel.agence.service.expense.impl.report.excel.writer;

import com.infotel.agence.domain.expense.export.line.SiteMealCostLine;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.lang.NonNull;

import java.util.Map;
import java.util.function.Function;

import static com.infotel.agence.service.expense.impl.report.excel.ExcelFileGenerator.SHEET_SITE_MEAL_COST;

/**
 * Implémentation spécifique à l'écriture des données liées au tableau "Frais de repas de chantier et réunion de travail" présent dans la feuille "Frais de repas chantier".
 *
 * @author arob
 */
public class SiteMealCostChartWriter extends AbstractChartWriter<SiteMealCostLine> {
    private static final Map<Integer, Function<SiteMealCostLine, ?>> BINDING = Map.of(
            1, SiteMealCostLine::getDate,
            2, SiteMealCostLine::getSiteOrMeeting,
            5, SiteMealCostLine::getEmployeeAmount,
            6, SiteMealCostLine::getCompanyAmount
    );

    public SiteMealCostChartWriter(XSSFWorkbook workbook) {
        super(workbook);
    }

    @Override
    protected Map<Integer, Function<SiteMealCostLine, ?>> getExtractorsByColumn() {
        return BINDING;
    }

    @Override
    protected XSSFSheet getTargetSheet() {
        return getSheet(SHEET_SITE_MEAL_COST);
    }

    @Override
    protected void fillFormula(@NonNull Row row, int startRow, int rowNb) {
        fillOneSumFormula(row.getCell(5), "F", startRow + 1, rowNb + 1);
        fillOneSumFormula(row.getCell(6), "G", startRow + 1, rowNb + 1);

    }
}
