package com.infotel.agence.service.order.impl;

import com.infotel.agence.domain.order.Request;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.order.RequestRepository;
import com.infotel.agence.service.order.IRequestService;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.*;

/**
 * Service qui gère les entités {@link Request}
 *
 * @author JUBA
 */
@Service
public class RequestService implements IRequestService {

    private static final String UNKNOWN_REQUEST = "Aucune demande n''est référencée par l''id {0}";

    private RequestRepository requestRepository;

    public RequestService(final RequestRepository requestRepository) {
        this.requestRepository = requestRepository;
    }

    @Override
    public Request findById(long id) {
        return requestRepository.findById(id)
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_REQUEST, id));
    }

    @Override
    public List<Request> findAll() {
        return requestRepository.findAll();
    }

    @Override
    public Request create(@NonNull Request request) {
        return requestRepository.save(request);
    }

    @Override
    public Request update(@NonNull Request request) {
        Assert.notNull(request.getId(), "L'id de la demande ne peut être null");

        if (requestRepository.existsById(request.getId())) {
            return requestRepository.save(request);
        }
        throw new UnknownEntityException(UNKNOWN_REQUEST, request.getId());
    }

    @Override
    public void deleteById(long id) {
        if (requestRepository.existsById(id)) {
            requestRepository.deleteById(id);
        } else {
            throw new UnknownEntityException(UNKNOWN_REQUEST, id);
        }
    }
}
