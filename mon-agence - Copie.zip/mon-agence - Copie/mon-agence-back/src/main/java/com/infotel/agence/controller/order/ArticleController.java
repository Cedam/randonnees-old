package com.infotel.agence.controller.order;

import com.infotel.agence.domain.order.Article;
import com.infotel.agence.service.order.IArticleService;

import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.*;
import java.net.*;
import java.util.*;

import static com.infotel.agence.utils.URIUtils.buildCreatedResourceURI;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.ResponseEntity.*;

/**
 * Controleur pour la gestion des articles
 *
 * @author JUBA
 */
@RestController
@RequestMapping(value = "/api/articles", produces = APPLICATION_JSON_VALUE)
@Log4j2
public class ArticleController {

    private final IArticleService articleService;

    public ArticleController(IArticleService articleService) {
        this.articleService = articleService;
    }

    /**
     * Retourne l'article référencé par l'id en paramètre
     *
     * @param id id
     * @return article
     */
    @GetMapping("/{id}")
    public ResponseEntity<Article> findArticleById(@PathVariable long id) {
        return ok(articleService.findById(id));
    }

    /**
     * Retourne l'ensemble des articles
     *
     * @return liste des articles
     */
    @GetMapping
    public ResponseEntity<List<Article>> findAllArticles() {
        return ok(articleService.findAll());
    }

    /**
     * Créer un nouvel article
     *
     * @param article article
     * @return le nouvel article
     */
    @PostMapping(value = "", consumes = APPLICATION_JSON_VALUE) // FIXME ALI restore @Valid
    public ResponseEntity<Article> createArticle(@RequestBody Article article, HttpServletRequest httpServletRequest) {
        Article newArticle = articleService.create(article);
        URI location = buildCreatedResourceURI(httpServletRequest, newArticle);
        return created(location).body(newArticle);
    }

    /**
     * Met à jour un article existant
     *
     * @param id      id de l'article
     * @param article article
     * @return article mis à jour
     */
    @PutMapping(value = "/{id}", consumes = APPLICATION_JSON_VALUE) // FIXME ALI restore @Valid
    public ResponseEntity<Article> updateArticle(@PathVariable long id, @RequestBody Article article) {
        return ok(articleService.update(article));
    }

    /**
     * Supprime l'article référencé par l'id en paramètre
     *
     * @param id id
     * @return void
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteArticle(@PathVariable long id) {
        articleService.deleteById(id);
        return noContent().build();
    }
}