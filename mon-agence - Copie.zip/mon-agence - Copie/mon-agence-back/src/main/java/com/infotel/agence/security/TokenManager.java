package com.infotel.agence.security;

import com.infotel.agence.config.security.JwtProperties;
import com.infotel.agence.service.user.IUserService;
import io.jsonwebtoken.*;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class TokenManager {

    private static final String AUTHORITIES = "auth";

    private final IUserService userService;

    private final JwtProperties jwtProperties;

    public TokenManager(IUserService userService, JwtProperties jwtProperties) {
        this.userService = userService;
        this.jwtProperties = jwtProperties;
    }

    /**
     * Construit un nouveau token JWT pour les authentifications futures
     *
     * @param auth authentification
     * @return token JWT
     */
    public String getAccessToken(Authentication auth) {
        return Jwts.builder()
                .setSubject(auth.getName())
                .claim(AUTHORITIES, auth.getAuthorities())
                .signWith(SignatureAlgorithm.HS512, jwtProperties.getSecretKey())
                .setExpiration(getExpirationDate(jwtProperties.getAccessTokenValiditySeconds()))
                .compact();
    }

    /**
     * Construit un nouveau token JWT pour le renouvellement du token d'authentification et l'associe à l'utilisateur authentifié.
     *
     * @param auth authentification
     * @return token JWT
     */
    public String getRefreshToken(Authentication auth) {
        String refreshToken = Jwts.builder()
                .setSubject(auth.getName())
                .signWith(SignatureAlgorithm.HS512, RandomStringUtils.randomAlphanumeric(64))
                .setExpiration(getExpirationDate(jwtProperties.getRefreshTokenValiditySeconds()))
                .compact();

        userService.setRefreshToken(auth.getName(), refreshToken);

        return refreshToken;
    }

    /**
     * Retourne le date d'expiration pour le nouveau token d'authentification
     *
     * @return date d'expiration
     */
    private Date getExpirationDate(int duration) {
        ZoneId utcZone = ZoneId.of("UTC");
        LocalDateTime now = LocalDateTime.now(utcZone);
        return Date.from(now.plusSeconds(duration).atZone(utcZone).toInstant());
    }

    /**
     * Récupère la "session" utilisateur depuis le token JWT
     *
     * @param token token JWT
     * @return authentication
     */
    public Authentication getAuthentication(String token) {
        try {
            Claims claims = Jwts.parser()
                    .setSigningKey(jwtProperties.getSecretKey())
                    .parseClaimsJws(token)
                    .getBody();

            UserDetails user = userService.loadUserByUsername(claims.getSubject());
            return new UsernamePasswordAuthenticationToken(user, token, user.getAuthorities());

        } catch (ExpiredJwtException e) {
            throw new CredentialsExpiredException("Token JWT expiré", e);

        } catch (JwtException ex) {
            throw new BadCredentialsException("Token JWT invalide", ex);
        }
    }
}
