package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.EmployeeIdentityRepository;
import com.infotel.agence.security.SecurityUtils;
import com.infotel.agence.service.expense.IEmployeeIdentityService;

import org.springframework.stereotype.Service;

/**
 * Service qui gère les entités {@link EmployeeIdentity}
 *
 * @author arob
 */
@Service
public class EmployeeIdentityService implements IEmployeeIdentityService {
    static final String UNKNOWN_EMPLOYEEIDENTITY = "Aucune identité d''employé n''est référencé par l''id {0}";
    static final String NO_USER_CONNECTED = "L''utilisateur n''est pas connecté !";

    private final EmployeeIdentityRepository employeeIdentityRepository;

    public EmployeeIdentityService(final EmployeeIdentityRepository employeeIdentityRepository) {
        this.employeeIdentityRepository = employeeIdentityRepository;
    }

    @Override
    public EmployeeIdentity findCurrent() {
        User user = SecurityUtils.getCurrentUser()
                .orElseThrow(() -> new BusinessException(NO_USER_CONNECTED));

        return employeeIdentityRepository.findById(user.getId())
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_EMPLOYEEIDENTITY, user.getId()));
    }

    @Override
    public void deleteById(long id) {
        if (employeeIdentityRepository.existsById(id)) {
            employeeIdentityRepository.deleteById(id);
        }
    }
}
