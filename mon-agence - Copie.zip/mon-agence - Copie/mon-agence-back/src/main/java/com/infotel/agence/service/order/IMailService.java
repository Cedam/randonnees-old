package com.infotel.agence.service.order;

import com.infotel.agence.domain.order.Mail;
import org.springframework.lang.NonNull;

import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_SUPPLY;

/**
 * Interface pour le service qui gère les entités {@link Mail}
 *
 * @author JUBA
 */
@RolesAllowed(ROLE_SUPPLY)
public interface IMailService {

    /**
     * Retourne le mail référencé par l'id en paramètre
     *
     * @param id id
     * @return mail
     */
    Mail findById(long id);

    /**
     * Retourne l'ensemble des mails
     *
     * @return liste des mails
     */
    List<Mail> findAll();

    /**
     * Créer un nouveau mail
     *
     * @param mail mail
     * @return nouveau mail
     */
    Mail create(@NonNull Mail mail);

    /**
     * Met à jour un mail existant
     *
     * @param mail mail
     * @return mail mis à jour
     */
    Mail update(@NonNull Mail mail);

    /**
     * Supprime le mail référencé par l'id en paramètre
     *
     * @param id id
     */
    void deleteById(long id);

}
