package com.infotel.agence.service.order;

import com.infotel.agence.domain.order.Request;
import org.springframework.lang.NonNull;

import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_SUPPLY;

/**
 * Interface pour le service qui gère les entités {@link Request}
 *
 * @author JUBA
 */
@RolesAllowed(ROLE_SUPPLY)
public interface IRequestService {

    /**
     * Retourne la demande référencée par l'id en paramètre
     *
     * @param id id
     * @return demande
     */
    Request findById(long id);

    /**
     * Retourne l'ensemble des demandes
     *
     * @return liste des demandes
     */
    List<Request> findAll();

    /**
     * Créer une nouvelle demande
     *
     * @param request demande
     * @return nouvelle demande
     */
    Request create(@NonNull Request request);

    /**
     * Met à jour une demande existante
     *
     * @param request demande
     * @return demande mise à jour
     */
    Request update(@NonNull Request request);

    /**
     * Supprime la demande référencée par l'id en paramètre
     *
     * @param id id
     */
    void deleteById(long id);

}