package com.infotel.agence.domain.expense;

import com.infotel.agence.domain.Resource;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.Size;

/**
 * Entité lié à l'emplacement d'un client / entreprise
 *
 * @author arob
 */
@Entity
@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Generated
@Table(name = "PLACE",
        indexes = { @Index(name = "IDX_PLA_NAME", columnList = "PLA_NAME"),
                @Index(name = "IDX_PLA_ID", columnList = "PLA_ID") })
public class Place implements Resource {

    /**
     * Id de la place
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PLA_ID")
    private Long id;

    /**
     * Nom de la place
     */
    @Size(max = 255, message = "Le nom d'une place ne doit pas dépasser 255 caractères")
    @Column(name = "PLA_NAME")
    private String name;
}
