package com.infotel.agence.repository.expense;

import com.infotel.agence.domain.expense.Compensation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

/**
 * {@link Compensation} repository
 *
 * @author arob
 */
@Repository
public interface CompensationRepository extends JpaRepository<Compensation, Long> {
    @Query("SELECT comp.mileageAllowance " +
            "FROM Compensation as comp " +
            "JOIN EmployeeIdentity as ei " +
            "ON comp.id = ei.compensation.id " +
            "WHERE ei.id = :userId")
    BigDecimal getCurrentUserMileageAllowance(@Param("userId") Long userId);
}
