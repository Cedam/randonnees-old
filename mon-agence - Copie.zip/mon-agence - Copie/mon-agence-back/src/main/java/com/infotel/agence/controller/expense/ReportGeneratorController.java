package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.dto.TicketStatisticsDTO;
import com.infotel.agence.domain.expense.ticket.TicketCode;
import com.infotel.agence.service.expense.IReportGeneratorService;
import com.infotel.agence.service.expense.ITicketService;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.*;
import java.io.*;
import java.time.*;
import java.util.*;

import static org.springframework.http.HttpHeaders.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.APPLICATION_OCTET_STREAM_VALUE;
import static org.springframework.http.ResponseEntity.ok;

/**
 * Controleur pour la gestion des comptes rendu
 *
 * @author arob
 */
@RestController
@RequestMapping(value = "/api/reports")
public class ReportGeneratorController {

    private final IReportGeneratorService reportGeneratorService;
    private final ITicketService ticketService;

    public ReportGeneratorController(IReportGeneratorService reportGeneratorService, ITicketService ticketService) {
        this.reportGeneratorService = reportGeneratorService;
        this.ticketService = ticketService;
    }

    @GetMapping(value = "/zip", headers = "accept=application/octet-stream")
    public void generate(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
                         @RequestParam int month,
                         HttpServletResponse httpServletResponse) throws IOException {

        // Add excel content type
        httpServletResponse.setContentType(APPLICATION_OCTET_STREAM_VALUE);

        // Define response headers to disable cache
        httpServletResponse.setHeader(CACHE_CONTROL, "no-cache, no-store, max-age=0, must-revalidate");
        httpServletResponse.setDateHeader(EXPIRES, 0L);

        // Définit l'en-tête "Content-Disposition" de la réponse afin d'inclure le nom du fichier zip
        String filename = reportGeneratorService.getFilename(month);
        httpServletResponse.setHeader(CONTENT_DISPOSITION, String.format("attachment; filename=\"%s.zip\"", filename));

        // Récupération du fichier excel dans l'output stream
        reportGeneratorService.export(startDate, endDate, filename, month, httpServletResponse.getOutputStream());
    }

    @GetMapping
    public ResponseEntity<Map<TicketCode, TicketStatisticsDTO>> statistics(@DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                                                                           @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return ok(ticketService.statistics(startDate, endDate));
    }

    /**
     * Permet de récuperer la date du ticket (non-archivé et validé) le plus ancien ainsi que la date du ticket (non-archivé et validé) du ticket le plus récent.
     *
     * @return une map de date : {"olderDate": LocalDate la plus ancienne, "youngerDate": LocalDate la plus récente}
     */
    @GetMapping(value = "/limits", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, LocalDate>> getLimits() {
        return ok(reportGeneratorService.getLimits());
    }
}
