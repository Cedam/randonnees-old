package com.infotel.agence.service.order.impl;

import com.infotel.agence.domain.order.Article;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.order.ArticleRepository;
import com.infotel.agence.service.order.IArticleService;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.*;

/**
 * Service qui gère les entités {@link Article}
 *
 * @author JUBA
 */
@Service
public class ArticleService implements IArticleService {

    private static final String UNKNOWN_ARTICLE = "Aucun article n''est référencé par l''id {0}";

    private final ArticleRepository articleRepository;

    public ArticleService(final ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    @Override
    public Article findById(long id) {
        return articleRepository.findById(id)
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_ARTICLE, id));
    }

    @Override
    public List<Article> findAll() {
        return articleRepository.findAll();
    }

    @Override
    public Article create(@NonNull Article article) {
        return articleRepository.save(article);
    }

    @Override
    public Article update(@NonNull Article article) {
        Assert.notNull(article.getId(), "L'id de l'article ne peut être null");

        if (articleRepository.existsById(article.getId())) {
            return articleRepository.save(article);
        }
        throw new UnknownEntityException(UNKNOWN_ARTICLE, article.getId());
    }

    @Override
    public void deleteById(long id) {
        if (articleRepository.existsById(id)) {
            articleRepository.deleteById(id);
        } else {
            throw new UnknownEntityException(UNKNOWN_ARTICLE, id);
        }
    }
}
