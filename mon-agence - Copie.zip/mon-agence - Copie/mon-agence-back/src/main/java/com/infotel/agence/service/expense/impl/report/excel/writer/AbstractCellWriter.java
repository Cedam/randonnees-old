package com.infotel.agence.service.expense.impl.report.excel.writer;

import com.infotel.agence.exception.TechnicalException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Optional;

/**
 * Regroupe les fonctions basiques pour l'écriture et le formatage des cellules excel.
 *
 * @author arob
 */
public class AbstractCellWriter {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final XSSFWorkbook workbook;

    public AbstractCellWriter(XSSFWorkbook workbook) {
        Objects.requireNonNull(workbook, "workbook n'est pas défini");
        this.workbook = workbook;
    }

    /**
     * Renvoi le style par défaut à appliquer (centré avec bordures)
     *
     * @return style
     */
    protected XSSFCellStyle getDefaultStyle() {
        final XSSFCellStyle style = workbook.createCellStyle();

        style.setAlignment(HorizontalAlignment.CENTER);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);

        return style;
    }

    /**
     * Renvoi la feuille de calcul qui porte le nom passé en paramètre.
     *
     * @param sheetName nom de la feuille de calcul
     * @return feuille de calcul
     * @throws TechnicalException si la feuille n'existe pas
     */
    protected XSSFSheet getSheet(final String sheetName) {
        return Optional.ofNullable(workbook.getSheet(sheetName))
                .orElseThrow(() -> new TechnicalException("L'onglet {0} n'existe pas", sheetName));
    }

    /**
     * Ecrit la valeur passé en paramètre dans la cellule cell en prenant en compte les spécificité liés à la classe
     * (BigDecimal, LocalDate, LocalDateTime, Integer, Long).
     *
     * @param cell  cellule
     * @param value valeur à écrire
     */
    protected void fillOneCell(final Cell cell, final Object value) {
        if (cell == null || value == null) {
            return;
        }

        if (value instanceof BigDecimal) {
            cell.setCellValue(((BigDecimal) value).doubleValue());
        } else if (value instanceof LocalDate) {
            cell.setCellValue(((LocalDate) value).format(DATE_FORMATTER));
        } else if (value instanceof LocalDateTime) {
            cell.setCellValue(((LocalDateTime) value).format(DATE_TIME_FORMATTER));
        } else if (value instanceof Integer) {
            cell.setCellValue((Integer) value);
        } else if (value instanceof Long) {
            cell.setCellValue((Long) value);
        } else {
            cell.setCellValue(value.toString());
        }
    }

}
