package com.infotel.agence.exception;

import org.springframework.lang.NonNull;

public class UnknownEntityException extends BusinessException {

    private static final long serialVersionUID = 950043463547469677L;

    /**
     * Constructeur
     *
     * @see BusinessException
     */
    public UnknownEntityException(@NonNull final String message) {
        super(message);
    }

    /**
     * Constructeur
     *
     * @see BusinessException
     */
    public UnknownEntityException(@NonNull final String message, final Object... params) {
        super(message, params);
    }
}
