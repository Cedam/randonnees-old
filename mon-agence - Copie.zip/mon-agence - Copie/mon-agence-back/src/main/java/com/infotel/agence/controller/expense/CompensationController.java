package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.Compensation;
import com.infotel.agence.domain.expense.dto.CompensationDTO;
import com.infotel.agence.service.expense.ICompensationService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.*;
import javax.validation.*;
import java.net.*;
import java.util.*;

import static com.infotel.agence.utils.URIUtils.buildCreatedResourceURI;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.ResponseEntity.created;
import static org.springframework.http.ResponseEntity.ok;

/**
 * Controleur pour la gestion des {@link Compensation}
 *
 * @author arob
 */
@RestController
@RequestMapping(value = "/api/compensations", produces = APPLICATION_JSON_VALUE)
public class CompensationController {
    private final ICompensationService compensationService;

    public CompensationController(ICompensationService compensationService) {
        this.compensationService = compensationService;
    }

    /**
     * Retourne la compensation référencée par l'id en paramètre
     *
     * @param id id
     * @return compensation
     */
    @GetMapping("/{id}")
    public ResponseEntity<Compensation> findCompensationById(@PathVariable long id) {
        return ok(compensationService.findById(id));
    }

    /**
     * Retourne une page contenant un sous-ensemble des compensations
     *
     * @param pageable les informations relatives à la page souhaitée
     * @return page des compensations
     */
    @GetMapping("")
    public ResponseEntity<Page<Compensation>> findAllCompensationsPage(Pageable pageable) {
        return ok(compensationService.findAllPage(pageable));
    }

    /**
     * Retourne une liste contenant l'ensemble des compensations
     *
     * @return liste des compensations
     */
    @GetMapping("/all")
    public ResponseEntity<List<Compensation>> findAllCompensationsList() {
        return ok(compensationService.findAllList());
    }

    /**
     * Créer une nouvelle compensation
     *
     * @param compensationDTO compensation
     * @return la nouvelle compensation
     */
    @PostMapping(value = "", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Compensation> createCompensation(@Valid @RequestBody CompensationDTO compensationDTO, HttpServletRequest httpServletRequest) {
        Compensation newCompensation = compensationService.create(compensationDTO);
        URI location = buildCreatedResourceURI(httpServletRequest, newCompensation);
        return created(location).body(newCompensation);
    }

    /**
     * Met à jour une compensation existante
     *
     * @param id              id de la compensation
     * @param compensationDTO compensation
     * @return la compensation mise à jour
     */
    @PutMapping(value = "/{id}", consumes = APPLICATION_JSON_VALUE)
    public ResponseEntity<Compensation> updateCompensation(@PathVariable long id, @Valid @RequestBody CompensationDTO compensationDTO) {
        return ok(compensationService.update(id, compensationDTO));
    }
}
