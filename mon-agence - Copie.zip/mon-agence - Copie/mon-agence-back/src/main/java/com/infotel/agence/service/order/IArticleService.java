package com.infotel.agence.service.order;

import com.infotel.agence.domain.order.Article;
import org.springframework.lang.NonNull;

import javax.annotation.security.RolesAllowed;
import java.util.List;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_SUPPLY;

/**
 * Interface pour le service qui gère les entités {@link Article}
 *
 * @author JUBA
 */
@RolesAllowed(ROLE_SUPPLY)
public interface IArticleService {

    /**
     * Retourne l'article référencé par l'id en paramètre
     *
     * @param id id
     * @return article
     */
    Article findById(long id);

    /**
     * Retourne l'ensemble des articles
     *
     * @return liste des articles
     */
    List<Article> findAll();

    /**
     * Créer un nouvel article
     *
     * @param article article
     * @return le nouvel article
     */
    Article create(@NonNull Article article);

    /**
     * Met à jour un article existant
     *
     * @param article article
     * @return article mis à jour
     */
    Article update(@NonNull Article article);

    /**
     * Supprime l'article référencé par l'id en paramètre
     *
     * @param id id
     */
    void deleteById(long id);

}
