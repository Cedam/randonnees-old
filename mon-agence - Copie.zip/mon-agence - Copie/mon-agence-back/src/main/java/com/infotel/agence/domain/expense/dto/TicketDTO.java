package com.infotel.agence.domain.expense.dto;

import com.infotel.agence.domain.expense.Place;
import com.infotel.agence.domain.expense.ReceiptPicture;
import com.infotel.agence.domain.expense.ticket.Ticket;
import com.infotel.agence.domain.expense.ticket.TicketCode;
import lombok.Builder;
import lombok.Data;
import lombok.Generated;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * DTO de la classe {@link Ticket}
 *
 * @author arob
 */
@Builder
@Data
@Generated
public class TicketDTO {

    // --------------- Champs TICKET --------------- //

    /**
     * Code correspondant au type du ticket
     */
    @NotNull
    private TicketCode code;

    /**
     * Date du Ticket (justificatif)
     */
    @NotNull
    private LocalDate date;

    /**
     * Le ticket a t il été vérifié par l'utilisateur ?
     */
    @NotNull
    private boolean isValid;

    /**
     * Le ticket a t il été archivé ?
     */
    private LocalDate isArchived;

    /**
     * Image justificative du ticket
     */
    @Valid
    private ReceiptPicture receiptPicture;

    // --------------- Champs propre à certains tickets --------------- //
    /**
     * Client lié au ticket
     * (TicketCustomerMealCost, TicketExceptionalBusinessTravel, TicketFuel,
     * TicketLodgingMealBusiness, TicketVariousBusinessTravel, TicketVariousCost)
     */
    @Size(max = 255, message = "Le nom du client ne doit pas dépasser 255 caractères")
    private String customer;

    /**
     * Valeur payé par l'employé
     * (TicketCustomerMealCost, TicketFuel, TicketSiteMealCost, TicketVariousBusinessTravel,
     * TicketVariousCost)
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée par l'employé ne peut pas dépasser 9999,99")
    private BigDecimal employeeAmount;

    /**
     * Valeur prépayé par la société
     * (TicketCustomerMealCost, TicketExceptionalBusinessTravel, TicketFuel,
     * TicketLodgingMealBusiness, TicketSiteMealCost, TicketVariousBusinessTravel,
     * TicketVariousCost)
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée par la société ne peut pas dépasser 9999,99")
    private BigDecimal companyAmount;

    /**
     * Place de départ
     * (TicketExceptionalBusinessTravel)
     */
    @Valid
    private Place startPlace;

    /**
     * Place d'arrivé
     * (TicketExceptionalBusinessTravel)
     */
    @Valid
    private Place endPlace;

    /**
     * Vehicule
     * (TicketExceptionalBusinessTravel)
     */
    @Size(max = 255, message = "Le nom du véhicule ne doit pas dépasser 255 caractères")
    private String vehicle;

    /**
     * Objet
     * (TicketFuel, TicketVariousBusinessTravel, TicketVariousCost)
     */
    @Size(max = 255, message = "L'objet de l'achat ne doit pas dépasser 255 caractères")
    private String purpose;

    /**
     * Somme payer par l'employe pour une chambre
     * (TicketLodgingMealBusiness)
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée pour la chambre ne peut pas dépasser 9999,99")
    private BigDecimal bedroomAmount;

    /**
     * Sommes payer par l'employe pour un petit dejeuner
     * (TicketLodgingMealBusiness)
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée pour un petit déjeuner ne peut pas dépasser 9999,99")
    private BigDecimal breakfastAmount;

    /**
     * Sommes payer par l'employe pour un dejeuner
     * (TicketLodgingMealBusiness)
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée pour un déjeuner ne peut pas dépasser 9999,99")
    private BigDecimal lunchAmount;

    /**
     * Sommes payer par l'employe pour un diner
     * (TicketLodgingMealBusiness)
     */
    @Digits(integer = 6, fraction = 2, message = "La valeur payée pour un diner ne peut pas dépasser 9999,99")
    private BigDecimal dinnerAmount;

    /**
     * Lieu du chantier ou de la réunion
     * (TicketSiteMealCost)
     */
    @Size(max = 255, message = "Le lieu du chantier ou de la réunion ne peut pas dépasser 255 caractères")
    private String siteOrMeeting;
}
