package com.infotel.agence.domain.expense.export.line;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Cette classe permet le stockage d'une ligne du tableau "Frais d'hébergement et de repas individuels" présent dans la
 * feuille "Frais de repas client".
 *
 * @author arob
 */
@Setter
@Getter
public class LodgingMealBusinessLine extends AbstractLine {
    private LocalDate date;
    private BigDecimal bedroomAmount;
    private BigDecimal breakfastAmount;
    private BigDecimal lunchAmount;
    private BigDecimal dinnerAmount;
    private String customer;
    private BigDecimal companyAmount;
}
