package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.Distance;
import com.infotel.agence.domain.expense.QDistance;
import com.infotel.agence.domain.expense.dto.DistanceDTO;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.DistanceRepository;
import com.infotel.agence.repository.expense.PlaceRepository;
import com.infotel.agence.repository.expense.TicketRepository;
import com.infotel.agence.service.expense.IDistanceService;

import com.querydsl.core.types.dsl.BooleanExpression;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.collections4.IterableUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Service qui gère les entités {@link Distance}
 *
 * @author arob
 */
@Service
public class DistanceService implements IDistanceService {

    public static final String UNKNOWN_DISTANCE = "Aucune distance n''est référencé par l''id {0}";
    public static final String UNKNOWN_PLACE_DISTANCE = "Aucune distance n''est référencé par l''id de place [{0}]";
    public static final String UNKNOWN_PLACES_DISTANCE = "Aucune distance n''est référencé par les ids de places [{0}, {1}]";
    public static final String NON_NULL_DISTANCE = "L''objet Distance, ses places associées et leurs id doivent être non-null";
    public static final String NON_NULL_PLACE_ID = "Les identifiants des places doivent être non-null";
    public static final String ALREADY_KNOWN_DISTANCE = "Le couple de distance {0}, {1} existe déjà. Ajout impossible";

    private final DistanceRepository distanceRepository;
    private final PlaceRepository placeRepository;
    private final TicketRepository ticketRepository;
    private final MapperFacade mapperFacade;

    public DistanceService(final DistanceRepository distanceRepository,
                           final PlaceRepository placeRepository,
                           final TicketRepository ticketRepository,
                           final MapperFacade mapperFacade) {
        this.distanceRepository = distanceRepository;
        this.placeRepository = placeRepository;
        this.ticketRepository = ticketRepository;
        this.mapperFacade = mapperFacade;
    }

    @Override
    public Distance create(DistanceDTO distanceDTO) {
        if (distanceDTO == null || distanceDTO.getPlaceStart() == null || distanceDTO.getPlaceEnd() == null) {
            throw new BusinessException(NON_NULL_DISTANCE);
        }

        if (distanceDTO.getPlaceStart().getId() == null || distanceDTO.getPlaceEnd().getId() == null) {
            throw new BusinessException(NON_NULL_PLACE_ID);
        }

        Optional<Distance> result = getByPlacesId(distanceDTO.getPlaceStart().getId(), distanceDTO.getPlaceEnd().getId());

        // Si la distance n'existe pas déjà
        if (result.isEmpty()) {
            Distance distance = mapperFacade.map(distanceDTO, Distance.class);
            return distanceRepository.save(distance);
        }

        throw new BusinessException(ALREADY_KNOWN_DISTANCE, distanceDTO.getPlaceStart().getId(), distanceDTO.getPlaceEnd().getId());
    }

    private Optional<Distance> getByPlacesId(long idPlaceA, long idPlaceB) {
        BooleanExpression predicateAintoB = QDistance.distance.placeStart.id.eq(idPlaceA);
        predicateAintoB = predicateAintoB.and(QDistance.distance.placeEnd.id.eq(idPlaceB));

        BooleanExpression predicateBintoA = QDistance.distance.placeStart.id.eq(idPlaceB);
        predicateBintoA = predicateBintoA.and(QDistance.distance.placeEnd.id.eq(idPlaceA));

        return distanceRepository.findOne(predicateAintoB.or(predicateBintoA));
    }

    @Override
    public Distance findByPlacesId(long idPlaceA, long idPlaceB) {
        Optional<Distance> result = getByPlacesId(idPlaceA, idPlaceB);

        if (result.isPresent()) {
            return result.get();
        }

        throw new UnknownEntityException(UNKNOWN_PLACES_DISTANCE, idPlaceA, idPlaceB);
    }

    private List<Distance> getByPlaceId(long idPlace) {
        BooleanExpression predicate = QDistance.distance.placeStart.id.eq(idPlace)
                .or(QDistance.distance.placeEnd.id.eq(idPlace));

        return IterableUtils.toList(distanceRepository.findAll(predicate));
    }

    @Override
    public List<Distance> findByPlaceId(long idPlace) {
        List<Distance> result = getByPlaceId(idPlace);

        if (!result.isEmpty()) {
            return result;
        }

        throw new UnknownEntityException(UNKNOWN_PLACE_DISTANCE, idPlace);
    }

    @Override
    public Distance findById(long distanceId) {
        return distanceRepository.findById(distanceId)
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_DISTANCE, distanceId));
    }

    @Override
    public Distance update(long id, DistanceDTO distanceDTO) {
        if (distanceDTO == null) {
            throw new BusinessException(NON_NULL_DISTANCE);
        }

        if (distanceDTO.getPlaceStart() == null || distanceDTO.getPlaceStart().getId() == null ||
                distanceDTO.getPlaceEnd() == null || distanceDTO.getPlaceEnd().getId() == null) {
            throw new BusinessException(NON_NULL_DISTANCE);
        }

        if (distanceRepository.existsById(id)
                && placeRepository.existsById(distanceDTO.getPlaceStart().getId())
                && placeRepository.existsById(distanceDTO.getPlaceEnd().getId())) {
            // Instansation d'une entité Distance
            Distance distance = mapperFacade.map(distanceDTO, Distance.class);
            distance.setId(id);

            // On dévalide les tickets concernées par la distance
            ticketRepository.updateValidIfIdDistance(id, false);

            return distanceRepository.save(distance);
        }
        throw new UnknownEntityException(UNKNOWN_PLACES_DISTANCE, distanceDTO.getPlaceStart().getId(), distanceDTO.getPlaceEnd().getId());
    }

    @Override
    public Page<Distance> findAll(Pageable pageable) {
        return distanceRepository.findAll(pageable);
    }

    @Override
    public void deleteById(long idDistance) {
        distanceRepository.deleteById(idDistance);
    }
}
