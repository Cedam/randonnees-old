package com.infotel.agence.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

public class JWTAuthorizationFilter extends GenericFilterBean {

    private static final String BEARER = "Bearer ";

    private final CustomAccessDeniedHandler customAccessDeniedHandler;

    private final TokenManager tokenManager;

    public JWTAuthorizationFilter(final CustomAccessDeniedHandler customAccessDeniedHandler, final TokenManager tokenManager) {
        this.customAccessDeniedHandler = customAccessDeniedHandler;
        this.tokenManager = tokenManager;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;

        try {
            Optional<String> optionalToken = getToken(httpServletRequest);
            optionalToken.ifPresent(token -> {
                Authentication authentication = tokenManager.getAuthentication(token);

                SecurityContext context = SecurityContextHolder.createEmptyContext();
                context.setAuthentication(authentication);
                SecurityContextHolder.setContext(context);
            });

            chain.doFilter(request, response);

        } catch (AuthenticationException e) {
            SecurityContextHolder.clearContext();
            // FIXME ALI test this part
            customAccessDeniedHandler.commence(httpServletRequest, (HttpServletResponse) response, e);
        }
    }

    private Optional<String> getToken(HttpServletRequest request) {
        return Optional.ofNullable(request.getHeader(AUTHORIZATION))
                .filter(s -> s.startsWith(BEARER))
                .map(s -> s.substring(BEARER.length()));
    }

}
