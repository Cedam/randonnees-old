package com.infotel.agence.repository.expense;

import com.infotel.agence.domain.expense.dto.TicketStatisticsDTO;
import com.infotel.agence.domain.expense.ticket.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * {@link Ticket} repository
 *
 * @author arob
 */
@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long>, QuerydslPredicateExecutor<Ticket> {

    /**
     * Retourne la date du ticket le plus récent non archivé de l'utilisateur
     *
     * @param userId
     * @return
     */
    @Query("SELECT distinct tik.date " +
            "FROM Ticket as tik " +
            "WHERE tik.employeeIdentity.id = :userId " +
            "AND tik.archived IS NULL " +
            "AND tik.date = (SELECT MAX(tik2.date) " +
            "FROM Ticket as tik2 " +
            "WHERE tik2.employeeIdentity.id = :userId " +
            "AND tik2.archived IS NULL)")
    LocalDate findYoungerDate(@Param("userId") Long userId);

    /**
     * Retourne la date du ticket le plus ancien non archivé de l'utilisateur
     *
     * @param userId
     * @return
     */
    @Query("SELECT distinct tik.date " +
            "FROM Ticket as tik " +
            "WHERE tik.employeeIdentity.id = :userId " +
            "AND tik.archived IS NULL " +
            "AND tik.date = (SELECT MIN(tik2.date) " +
            "FROM Ticket as tik2 " +
            "WHERE tik2.employeeIdentity.id = :userId " +
            "AND tik2.archived IS NULL)")
    LocalDate findOlderDate(@Param("userId") Long userId);

    /**
     * Retourne la date du ticket le plus récent non archivé et validé de l'utilisateur
     *
     * @param userId
     * @return
     */
    @Query("SELECT distinct tik.date " +
            "FROM Ticket as tik " +
            "WHERE tik.employeeIdentity.id = :userId " +
            "AND tik.archived IS NULL " +
            "AND tik.date = (SELECT MAX(tik2.date) " +
            "FROM Ticket as tik2 " +
            "WHERE tik2.employeeIdentity.id = :userId " +
            "AND tik2.archived IS NULL " +
            "AND tik2.valid = true)")
    LocalDate findYoungerDateToGenerate(@Param("userId") Long userId);

    /**
     * Retourne la date du ticket le plus ancien non archivé et validé de l'utilisateur
     *
     * @param userId
     * @return
     */
    @Query("SELECT distinct tik.date " +
            "FROM Ticket as tik " +
            "WHERE tik.employeeIdentity.id = :userId " +
            "AND tik.archived IS NULL " +
            "AND tik.date = (SELECT MIN(tik2.date) " +
            "FROM Ticket as tik2 " +
            "WHERE tik2.employeeIdentity.id = :userId " +
            "AND tik2.archived IS NULL " +
            "AND tik2.valid = true)")
    LocalDate findOlderDateToGenerate(@Param("userId") Long userId);

    /**
     * Retourne la somme de la valeur des tickets de type "CustomerMealCost", non archivés et validés, pour un utilisateur donné.
     *
     * @param userId
     * @param startDate
     * @param endDate
     * @return
     */
    @Query("SELECT NEW com.infotel.agence.domain.expense.dto.TicketStatisticsDTO(COUNT(typedTik), SUM(typedTik.employeeAmount)) " +
            "FROM Ticket as tik " +
            "JOIN CustomerMealCostTicket as typedTik " +
            "ON tik.id = typedTik.id " +
            "WHERE tik.archived IS NULL " +
            "AND tik.valid = true " +
            "AND tik.employeeIdentity.id = :userId " +
            "AND tik.date BETWEEN :startDate AND :endDate " +
            "GROUP BY tik.code")
    TicketStatisticsDTO statsValueTicketCustomerMealCost(@Param("userId") Long userId,
                                                         @Param("startDate") LocalDate startDate,
                                                         @Param("endDate") LocalDate endDate);

    /**
     * Retourne la somme de la valeur des tickets de type "ExceptionalBusinessTravel", non archivés et validés, pour un utilisateur donné.
     *
     * @param userId
     * @param mileageAllowance
     * @param startDate
     * @param endDate
     * @return
     */
    @Query("SELECT NEW com.infotel.agence.domain.expense.dto.TicketStatisticsDTO(COUNT(typedTik), SUM(dist.value)*:mileageAllowance) " +
            "FROM Ticket as tik " +
            "JOIN ExceptionalBusinessTravelTicket as typedTik " +
            "ON tik.id = typedTik.id " +
            "JOIN Distance as dist " +
            "ON dist.placeStart.id = typedTik.startPlace.id and dist.placeEnd.id = typedTik.endPlace.id " +
            "OR dist.placeEnd.id = typedTik.startPlace.id and dist.placeStart.id = typedTik.endPlace.id " +
            "WHERE tik.valid = true " +
            "AND tik.archived IS NULL " +
            "AND tik.employeeIdentity.id = :userId " +
            "AND tik.date BETWEEN :startDate AND :endDate " +
            "GROUP BY tik.code")
    TicketStatisticsDTO statsValueTicketExceptionalBusinessTravel(@Param("userId") Long userId,
                                                                  @Param("mileageAllowance") BigDecimal mileageAllowance,
                                                                  @Param("startDate") LocalDate startDate,
                                                                  @Param("endDate") LocalDate endDate);

    /**
     * Retourne la somme de la valeur des tickets de type "Fuel", non archivés et validés, pour un utilisateur donné.
     *
     * @param userId
     * @param startDate
     * @param endDate
     * @return
     */
    @Query("SELECT NEW com.infotel.agence.domain.expense.dto.TicketStatisticsDTO(COUNT(typedTik), SUM(typedTik.employeeAmount)) " +
            "FROM Ticket as tik " +
            "JOIN FuelTicket as typedTik " +
            "ON tik.id = typedTik.id " +
            "WHERE tik.archived IS NULL " +
            "AND tik.valid = true " +
            "AND tik.employeeIdentity.id = :userId " +
            "AND tik.date BETWEEN :startDate AND :endDate " +
            "GROUP BY tik.code")
    TicketStatisticsDTO statsValueTicketFuel(@Param("userId") Long userId,
                                             @Param("startDate") LocalDate startDate,
                                             @Param("endDate") LocalDate endDate);

    /**
     * Retourne la somme de la valeur des tickets de type "LodgingMealBusiness", non archivés et validés, pour un utilisateur donné.
     *
     * @param userId
     * @param startDate
     * @param endDate
     * @return
     */
    @Query("SELECT NEW com.infotel.agence.domain.expense.dto.TicketStatisticsDTO(COUNT(typedTik), SUM(typedTik.bedroomAmount + typedTik.breakfastAmount + typedTik.lunchAmount + typedTik.dinnerAmount)) " +
            "FROM Ticket as tik " +
            "JOIN LodgingMealBusinessTicket as typedTik " +
            "ON tik.id = typedTik.id " +
            "WHERE tik.archived IS NULL " +
            "AND tik.valid = true " +
            "AND tik.employeeIdentity.id = :userId " +
            "AND tik.date BETWEEN :startDate AND :endDate " +
            "GROUP BY tik.code")
    TicketStatisticsDTO statsValueTicketLodgingMealBusiness(@Param("userId") Long userId,
                                                            @Param("startDate") LocalDate startDate,
                                                            @Param("endDate") LocalDate endDate);

    /**
     * Retourne la somme de la valeur des tickets de type "SiteMealCost", non archivés et validés, pour un utilisateur donné.
     *
     * @param userId
     * @param startDate
     * @param endDate
     * @return
     */
    @Query("SELECT NEW com.infotel.agence.domain.expense.dto.TicketStatisticsDTO(COUNT(typedTik), SUM(typedTik.employeeAmount)) " +
            "FROM Ticket as tik " +
            "JOIN SiteMealCostTicket as typedTik " +
            "ON tik.id = typedTik.id " +
            "WHERE tik.archived IS NULL " +
            "AND tik.valid = true " +
            "AND tik.employeeIdentity.id = :userId " +
            "AND tik.date BETWEEN :startDate AND :endDate " +
            "GROUP BY tik.code")
    TicketStatisticsDTO statsValueTicketSiteMealCost(@Param("userId") Long userId,
                                                     @Param("startDate") LocalDate startDate,
                                                     @Param("endDate") LocalDate endDate);

    /**
     * Retourne la somme de la valeur des tickets de type "VariousBusinessTravel", non archivés et validés, pour un utilisateur donné.
     *
     * @param userId
     * @param startDate
     * @param endDate
     * @return
     */
    @Query("SELECT NEW com.infotel.agence.domain.expense.dto.TicketStatisticsDTO(COUNT(typedTik), SUM(typedTik.employeeAmount)) " +
            "FROM Ticket as tik " +
            "JOIN VariousBusinessTravelTicket as typedTik " +
            "ON tik.id = typedTik.id " +
            "WHERE tik.archived IS NULL " +
            "AND tik.valid = true " +
            "AND tik.employeeIdentity.id = :userId " +
            "AND tik.date BETWEEN :startDate AND :endDate " +
            "GROUP BY tik.code")
    TicketStatisticsDTO statsValueTicketVariousBusinessTravel(@Param("userId") Long userId,
                                                              @Param("startDate") LocalDate startDate,
                                                              @Param("endDate") LocalDate endDate);

    /**
     * Retourne la somme de la valeur des tickets de type "VariousCost", non archivés et validés, pour un utilisateur donné.
     *
     * @param userId
     * @param startDate
     * @param endDate
     * @return
     */
    @Query("SELECT NEW com.infotel.agence.domain.expense.dto.TicketStatisticsDTO(COUNT(typedTik), SUM(typedTik.employeeAmount)) " +
            "FROM Ticket as tik " +
            "JOIN VariousCostTicket as typedTik " +
            "ON tik.id = typedTik.id " +
            "WHERE tik.archived IS NULL " +
            "AND tik.valid = true " +
            "AND tik.employeeIdentity.id = :userId " +
            "AND tik.date BETWEEN :startDate AND :endDate " +
            "GROUP BY tik.code")
    TicketStatisticsDTO statsValueTicketVariousCost(@Param("userId") Long userId,
                                                    @Param("startDate") LocalDate startDate,
                                                    @Param("endDate") LocalDate endDate);

    /**
     * Archive les tickets de l'utilisateur si ils sont validés et présent dans la période de temps données
     *
     * @param userId
     * @param startDate
     * @param endDate
     */
    @Transactional
    @Modifying
    @Query(value = "UPDATE TICKET " +
            "SET TIK_DATE_ARCHIVED = :todayDate " +
            "WHERE TIK_IS_VALID = true " +
            "AND EMPI_ID = :userId " +
            "AND TIK_CREATION_DATE BETWEEN :startDate AND :endDate"
            , nativeQuery = true)
    void archiveTicketBetween(@Param("userId") Long userId,
                              @Param("startDate") LocalDate startDate,
                              @Param("endDate") LocalDate endDate,
                              @Param("todayDate") LocalDate todayDate);

    /**
     * Permets de valider ou dévalider les tickets ayant une distance dont une des places a l'id passé en paramètre.
     *
     * @param placeId id de la place à vérifier
     * @param valid   état voulut pour le paramètre valid des tickets concernés
     */
    @Transactional
    @Modifying
    @Query("UPDATE ExceptionalBusinessTravelTicket as tik " +
            "SET tik.valid = :ticketValid " +
            "WHERE tik.startPlace.id = :placeId " +
            "OR tik.endPlace.id = :placeId")
    void updateValidIfIdPlace(@Param("placeId") Long placeId, @Param("ticketValid") boolean valid);

    /**
     * Permets de valider ou dévalider les tickets ayant une distance dont l'id est passé en paramètre.
     *
     * @param distanceId id de la distance à vérifier
     * @param valid      état voulut pour le paramètre valid des tickets concernés
     */
    @Transactional
    @Modifying
    @Query("UPDATE ExceptionalBusinessTravelTicket as tik " +
            "SET tik.valid = :ticketValid " +
            "WHERE tik.id IN (" +
            "SELECT subTik.id " +
            "FROM ExceptionalBusinessTravelTicket as subTik " +
            "JOIN Distance as dist " +
            "ON (subTik.startPlace = dist.placeStart AND subTik.endPlace = dist.placeEnd) " +
            "OR (subTik.startPlace = dist.placeEnd AND subTik.endPlace = dist.placeStart) " +
            "WHERE dist.id = :distanceId)")
    void updateValidIfIdDistance(@Param("distanceId") Long distanceId, @Param("ticketValid") boolean valid);

    @Transactional
    @Modifying
    @Query("DELETE FROM Ticket WHERE archived < :date")
    int deleteTicketsOlderThan(@Param("date") LocalDate date);

    @Transactional
    @Modifying
    @Query("DELETE FROM Ticket WHERE employeeIdentity.id = :userId")
    int deleteTicketsOfUser(@Param("userId") long userId);
}
