package com.infotel.agence.service.expense.impl.report.excel;

import com.infotel.agence.domain.expense.Distance;
import com.infotel.agence.domain.expense.export.ExcelEmployeeIdentity;
import com.infotel.agence.domain.expense.export.line.*;
import com.infotel.agence.domain.expense.ticket.ExceptionalBusinessTravelTicket;
import com.infotel.agence.domain.expense.ticket.Ticket;
import com.infotel.agence.domain.expense.ticket.TicketCode;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.service.expense.IDistanceService;
import com.infotel.agence.service.expense.impl.report.excel.writer.*;
import lombok.extern.log4j.Log4j2;
import ma.glasnost.orika.MapperFacade;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toList;

/**
 * Gère l'initialisation, le remplissage et la sauvegarde d'un fichier excel "Note de Frais"
 *
 * @author arob
 */
@Log4j2
public class ExcelFileGenerator {
    public static final String SHEET_CUSTOMER_MEAL_COST = "Frais de repas client";
    public static final String SHEET_SITE_MEAL_COST = "Frais de repas chantier";
    public static final String SHEET_VARIOUS_COST = "Frais divers";
    public static final String SHEET_EXCEPTIONAL_BUSINESS_TRAVEL = "Déplacement Commerciaux Ouest";

    // Numéro de ligne où commence les premiers tableaux de chaque feuille
    private static final int CHART_CUSTOMER_MEAL_COST_INITIAL_ROW = 10;
    private static final int CHART_SITE_MEAL_COST_INITIAL_ROW = 10;
    private static final int CHART_VARIOUS_COST_INITIAL_ROW = 10;
    private static final int CHART_EXCEPTIONAL_BUSINESS_TRAVEL_INITIAL_ROW = 11;

    // Dernières lignes des tableaux possédant des successeurs
    private int chartExceptionalBusinessTravelFinalRow = 11;
    private int chartLodgingMealBusinessFinalRow = 17;
    private int chartVariousBusinessTravelFinalRow = 22;

    // Instance du workbook excel
    private XSSFWorkbook workbook;

    private final MapperFacade mapperFacade;
    private final IDistanceService distanceService;

    public ExcelFileGenerator(MapperFacade mapperFacade, IDistanceService distanceService) {
        this.mapperFacade = mapperFacade;
        this.distanceService = distanceService;
    }

    /**
     * Initialise le workbook avec le template excel définie en paramètre
     *
     * @throws TechnicalException si le template n'est pas trouvable
     * @throws IOException        si le template n'est pas lisible
     */
    public void load(String excelName) throws IOException {

        ClassLoader classLoader = this.getClass().getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream(excelName);

        if (inputStream == null) {
            throw new TechnicalException("Le fichier {0} est introuvable. Impossible de continuer la génération.", excelName);
        }

        this.workbook = new XSSFWorkbook(inputStream);
    }

    /**
     * Remplit toutes les entêtes concernant les informations liées à l'employé.
     *
     * @param identity identité de l'employé
     */
    public void writeIdentity(final ExcelEmployeeIdentity identity) {
        IdentityWriter identityWriter = new IdentityWriter(workbook);
        identityWriter.write(identity);
    }

    /**
     * Remplit tous les tableaux du fichier excel avec les données des tickets.
     *
     * @param data dictionnaire contenant pour chaque type de {@link TicketCode}, le liste des tickets concernés.
     */
    public void writeTickets(Map<TicketCode, List<Ticket>> data) {
        data.forEach((code, tickets) -> {
            switch (code) {
                case CUSTOMER_MEAL_COST:
                    writeChartCustomerMealCost(tickets);
                    break;
                case SITE_MEAL_COST:
                    writeChartSiteMealCost(tickets);
                    break;
                case VARIOUS_COST:
                    writeChartVariousCost(tickets);
                    break;
                case EXCEPTIONAL_BUSINESS_TRAVEL:
                    writeChartExceptionalBusinessTravel(tickets);
                    break;
                case LODGING_MEAL_BUSINESS:
                    writeChartLodgingMealBusiness(tickets);
                    break;
                case FUEL:
                    writeChartFuel(tickets);
                    break;
                case VARIOUS_BUSINESS_TRAVEL:
                    writeChartVariousBusinessTravel(tickets);
                    break;
                default:
                    log.warn("Type de ticket non pris en charge : {}", code);
                    break;
            }
        });
    }

    /**
     * Mapping générique des tickets en lignes
     *
     * @param tickets   tickets
     * @param lineClass classe cible pour les lignes
     * @param <T>       classe des tickets
     * @param <U>       classe des lignes
     * @return lignes
     */
    private <T, U> List<U> mapTicketsToLines(List<T> tickets, Class<U> lineClass) {
        return tickets.stream().map(ticket -> mapperFacade.map(ticket, lineClass)).collect(toList());
    }

    /**
     * Mapping des tickets {@link ExceptionalBusinessTravelTicket} en lignes {@link ExceptionalBusinessTravelLine}
     *
     * @param tickets tickets
     * @return lignes
     */
    private List<ExceptionalBusinessTravelLine> mapExceptionalBusinessTravelTicketsToLines(List<Ticket> tickets) {
        return tickets.stream().map(ticket -> {
            ExceptionalBusinessTravelLine line = mapperFacade.map(ticket, ExceptionalBusinessTravelLine.class);

            if (ticket instanceof ExceptionalBusinessTravelTicket) {
                // FIXME ALI : NullPointerException possible ici ?
                Distance distance = distanceService.findByPlacesId(
                        ((ExceptionalBusinessTravelTicket) ticket).getStartPlace().getId(),
                        ((ExceptionalBusinessTravelTicket) ticket).getEndPlace().getId()
                );
                line.setMileage(distance.getValue());
            }
            return line;
        }).collect(toList());
    }

    /**
     * Remplit le tableau "Frais de repas client" présent dans la feuille "Frais de repas client".
     *
     * @param tickets tickets
     */
    public void writeChartCustomerMealCost(List<Ticket> tickets) {
        List<CustomerMealCostLine> lines = mapTicketsToLines(tickets, CustomerMealCostLine.class);

        CustomerMealCostChartWriter chartWriter = new CustomerMealCostChartWriter(workbook);
        chartWriter.writeChart(lines, CHART_CUSTOMER_MEAL_COST_INITIAL_ROW);
    }

    /**
     * Remplit le tableau "Frais de repas chantier et réunion de travail" présent dans la feuille "Frais de repas chantier".
     *
     * @param tickets tickets
     */
    public void writeChartSiteMealCost(List<Ticket> tickets) {
        List<SiteMealCostLine> lines = mapTicketsToLines(tickets, SiteMealCostLine.class);

        SiteMealCostChartWriter chartWriter = new SiteMealCostChartWriter(workbook);
        chartWriter.writeChart(lines, CHART_SITE_MEAL_COST_INITIAL_ROW);
    }

    /**
     * Remplit le tableau "Frais divers non lie à un deplacement" présent dans la feuille "Frais divers".
     *
     * @param tickets tickets
     */
    public void writeChartVariousCost(List<Ticket> tickets) {
        List<VariousCostLine> lines = mapTicketsToLines(tickets, VariousCostLine.class);

        VariousCostChartWriter chartWriter = new VariousCostChartWriter(workbook);
        chartWriter.writeChart(lines, CHART_VARIOUS_COST_INITIAL_ROW);
    }

    /**
     * Remplit le tableau "Frais de deplacement exceptionnel" présent dans la feuille "Déplacement Commerciaux Ouest".
     *
     * @param tickets tickets
     */
    public void writeChartExceptionalBusinessTravel(List<Ticket> tickets) {
        final List<ExceptionalBusinessTravelLine> lines = mapExceptionalBusinessTravelTicketsToLines(tickets);

        ExceptionalBusinessTravelChartWriter chartWriter = new ExceptionalBusinessTravelChartWriter(workbook);
        int finalRow = chartWriter.writeChart(lines, CHART_EXCEPTIONAL_BUSINESS_TRAVEL_INITIAL_ROW);

        chartVariousBusinessTravelFinalRow += finalRow - chartExceptionalBusinessTravelFinalRow;
        chartLodgingMealBusinessFinalRow += finalRow - chartExceptionalBusinessTravelFinalRow;
        chartExceptionalBusinessTravelFinalRow = finalRow;
    }

    /**
     * Remplit le tableau "Frais d'hebergement et de repas individuels" présent dans la feuille "Deplacement Commerciaux Ouest".
     *
     * @param tickets tickets
     */
    public void writeChartLodgingMealBusiness(List<Ticket> tickets) {
        List<LodgingMealBusinessLine> lines = mapTicketsToLines(tickets, LodgingMealBusinessLine.class);

        LodgingMealBusinessChartWriter chartWriter = new LodgingMealBusinessChartWriter(workbook);
        int finalRow = chartWriter.writeChart(lines, chartExceptionalBusinessTravelFinalRow);

        chartVariousBusinessTravelFinalRow += finalRow - chartLodgingMealBusinessFinalRow;
        chartLodgingMealBusinessFinalRow = finalRow;
    }

    /**
     * Remplit le tableau "Frais divers liés au déplacement" présent dans la feuille "Déplacement Commerciaux Ouest".
     *
     * @param tickets tickets
     */
    public void writeChartVariousBusinessTravel(List<Ticket> tickets) {
        List<VariousBusinessTravelLine> lines = mapTicketsToLines(tickets, VariousBusinessTravelLine.class);

        VariousBusinessTravelChartWriter chartWriter = new VariousBusinessTravelChartWriter(workbook);
        chartVariousBusinessTravelFinalRow = chartWriter.writeChart(lines, chartLodgingMealBusinessFinalRow);
    }

    /**
     * Remplit le tableau "Frais de carburant" présent dans la feuille "Déplacement Commerciaux Ouest".
     *
     * @param tickets tickets
     */
    public void writeChartFuel(List<Ticket> tickets) {
        List<FuelLine> lines = mapTicketsToLines(tickets, FuelLine.class);

        FuelChartWriter chartWriter = new FuelChartWriter(workbook);
        chartWriter.writeChart(lines, chartVariousBusinessTravelFinalRow);
    }

    /**
     * Persiste le workbook dans le {@link OutputStream} passé en paramètre.
     *
     * @param outputStream outputStream
     */
    public void save(OutputStream outputStream) {
        // Tout d'abord, on force les formules à calculer les résultats
        workbook.getCreationHelper().createFormulaEvaluator().evaluateAll();

        // Ensuite, on écrit le fichier excel résultant dans l'outputStream donnée en paramètre
        try {
            workbook.write(outputStream);
            workbook.close();
        } catch (Exception e) {
            final String errorMessage = "Erreur rencontrée lors de l'écriture du fichier excel dans l'OutputStream";
            log.error(errorMessage, e);
            throw new TechnicalException(errorMessage, e);
        }
    }
}