package com.infotel.agence.exception;

import org.springframework.lang.NonNull;

import java.text.MessageFormat;
import java.util.Formatter;

/**
 * Runtime exception par défaut pour lever des exceptions fonctionnelles.
 *
 * @author ARLI
 */
public class BusinessException extends RuntimeException {

    private static final long serialVersionUID = -4650567748718841516L;

    /**
     * Constructeur
     *
     * @param message message
     */
    public BusinessException(@NonNull final String message) {
        super(message);
    }

    /**
     * Constructeur qui permet de customiser son message à l'aide d'un pattern
     *
     * @param message message pattern
     * @param params  paramètres utilisés par le pattern
     * @see MessageFormat
     */
    public BusinessException(@NonNull final String message, final Object... params) {
        this(MessageFormat.format(message, params));
    }

    /**
     * Constructeur
     *
     * @param message   message
     * @param throwable exception
     */
    public BusinessException(@NonNull final String message, final Throwable throwable) {
        super(message, throwable);
    }

    /**
     * Constructeur qui permet de customiser son message à l'aide d'un pattern
     *
     * @param message   message pattern
     * @param throwable exception
     * @param params    paramètres utilisés par le pattern
     * @see Formatter
     */
    public BusinessException(@NonNull final String message, final Throwable throwable, final Object... params) {
        this(MessageFormat.format(message, params), throwable);
    }
}
