package com.infotel.agence.domain.expense.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Generated
@NoArgsConstructor
@AllArgsConstructor
public class TicketStatisticsDTO {
    long qte;
    BigDecimal value;
}
