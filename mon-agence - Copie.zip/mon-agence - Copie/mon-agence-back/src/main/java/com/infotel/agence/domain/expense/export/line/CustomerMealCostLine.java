package com.infotel.agence.domain.expense.export.line;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Cette classe permet le stockage d'une ligne du tableau "Frais de repas client" présent dans la feuille "Frais de
 * repas client".
 *
 * @author arob
 */
@Setter
@Getter
public class CustomerMealCostLine extends AbstractLine {
    private LocalDate date;
    private String customer;
    private BigDecimal employeeAmount;
    private BigDecimal companyAmount;

    public CustomerMealCostLine() {
        super(2, 4);
    }
}