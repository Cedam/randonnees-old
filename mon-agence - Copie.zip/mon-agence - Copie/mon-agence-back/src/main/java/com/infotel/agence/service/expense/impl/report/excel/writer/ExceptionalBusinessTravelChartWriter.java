package com.infotel.agence.service.expense.impl.report.excel.writer;

import com.infotel.agence.domain.expense.export.line.ExceptionalBusinessTravelLine;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.lang.NonNull;

import java.util.Map;
import java.util.function.Function;

import static com.infotel.agence.service.expense.impl.report.excel.ExcelFileGenerator.SHEET_EXCEPTIONAL_BUSINESS_TRAVEL;

/**
 * Implémentation spécifique à l'écriture des données liées au tableau "Frais de déplacement exceptionnel" présent dans la feuille "Déplacement Commerciaux Ouest".
 *
 * @author arob
 */
public class ExceptionalBusinessTravelChartWriter extends AbstractChartWriter<ExceptionalBusinessTravelLine> {
    private static final Map<Integer, Function<ExceptionalBusinessTravelLine, ?>> BINDING = Map.of(
            1, ExceptionalBusinessTravelLine::getDate,
            2, ExceptionalBusinessTravelLine::getStartPlace,
            3, ExceptionalBusinessTravelLine::getEndPlace,
            4, ExceptionalBusinessTravelLine::getVehicle,
            5, ExceptionalBusinessTravelLine::getMileage,
            6, ExceptionalBusinessTravelLine::getCustomer,
            8, ExceptionalBusinessTravelLine::getCompanyAmount
    );

    public ExceptionalBusinessTravelChartWriter(XSSFWorkbook workbook) {
        super(workbook);
    }

    @Override
    protected Map<Integer, Function<ExceptionalBusinessTravelLine, ?>> getExtractorsByColumn() {
        return BINDING;
    }

    @Override
    protected void postFill(@NonNull final Row row) {
        // ajout d'une formule pour les sommes intermédiaires
        final int rowNb = row.getRowNum() + 1;
        String formula = String.format("IF(%s%d*%s=0,\" \", %s%d*%s)", "F", rowNb, "$I$5", "F", rowNb, "$I$5");
        row.getCell(7).setCellFormula(formula);
    }

    @Override
    protected XSSFSheet getTargetSheet() {
        return getSheet(SHEET_EXCEPTIONAL_BUSINESS_TRAVEL);
    }

    @Override
    protected void fillFormula(@NonNull final Row row, final int startRow, final int rowNb) {
        fillOneSumFormula(row.getCell(7), "H", startRow + 1, rowNb + 1);
        fillOneSumFormula(row.getCell(8), "I", startRow + 1, rowNb + 1);
    }
}
