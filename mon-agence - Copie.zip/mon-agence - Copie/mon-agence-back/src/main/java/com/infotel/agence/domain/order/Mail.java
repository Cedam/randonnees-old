package com.infotel.agence.domain.order;

import com.infotel.agence.domain.Resource;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * Entité Mail
 *
 * @author JUBA
 */
@Entity
@Data
@Table(name = "MAIL")
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Builder
@Generated
public class Mail implements Resource {

    /**
     * Id du mail
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MAIL_ID")
    private Long id;

    /**
     * Destinataire du mail
     */
    @Email(message = "Le mail du destinataire est invalide")
    @Size(max = 255, message = "Le mail du destinataire ne doit pas dépasser 255 caractères")
    @Column(name = "MAIL_RECIPIENT")
    private String recipient;

    /**
     * Objet du mail
     */
    @NotNull
    @Size(max = 255, message = "L'objet du mail ne doit pas dépasser 255 caractères")
    @Column(name = "MAIL_OBJECT")
    private String object;

    /**
     * Contenu du mail
     */
    @NotNull
    @Size(max = 4000, message = "Le contenu du mail ne doit pas dépasser 4000 caractères")
    @Column(name = "MAIL_BODY", length = 4000)
    private String body;

    /**
     * Vrai si le mail a été envoyé
     */
    @Column(name = "MAIL_IS_SENT")
    private boolean sent;

    /**
     * Liste des articles liés
     * TODO ALI vérifier la pertinence du lien direct avec les articles et du CascadeType.ALL
     */
    // @formatter:off
    @ManyToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
    @JoinTable(
        name = "MAIL2ARTICLE",
        joinColumns = { @JoinColumn(name = "MAIL_ID") },
        inverseJoinColumns = { @JoinColumn(name = "ART_ID") },
        foreignKey = @ForeignKey(name = "FK_MAIL2ARTICLE_MAIL"),
        inverseForeignKey = @ForeignKey(name = "FK_MAIL2ARTICLE_ARTICLE"),
        indexes = {
            @Index(name = "IDX_MAIL2ARTICLE_MAILID", columnList = "MAIL_ID"),
            @Index(name = "IDX_MAIL2ARTICLE_ARTID", columnList = "ART_ID")
        })
    // @formatter:on
    private List<Article> articles;

}
