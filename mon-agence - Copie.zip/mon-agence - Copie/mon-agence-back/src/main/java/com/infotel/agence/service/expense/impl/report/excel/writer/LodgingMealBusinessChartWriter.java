package com.infotel.agence.service.expense.impl.report.excel.writer;

import com.infotel.agence.domain.expense.export.line.LodgingMealBusinessLine;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.lang.NonNull;

import java.util.Map;
import java.util.function.Function;

import static com.infotel.agence.service.expense.impl.report.excel.ExcelFileGenerator.SHEET_EXCEPTIONAL_BUSINESS_TRAVEL;

/**
 * Implémentation spécifique à l'écriture des données liées au tableau "Frais d'hebergement et de repas individuels" présent dans la feuille "Déplacement Commerciaux Ouest".
 *
 * @author arob
 */
public class LodgingMealBusinessChartWriter extends AbstractChartWriter<LodgingMealBusinessLine> {
    private static final Map<Integer, Function<LodgingMealBusinessLine, ?>> BINDING = Map.of(
            1, LodgingMealBusinessLine::getDate,
            2, LodgingMealBusinessLine::getBedroomAmount,
            3, LodgingMealBusinessLine::getBreakfastAmount,
            4, LodgingMealBusinessLine::getLunchAmount,
            5, LodgingMealBusinessLine::getDinnerAmount,
            6, LodgingMealBusinessLine::getCustomer,
            8, LodgingMealBusinessLine::getCompanyAmount
    );

    public LodgingMealBusinessChartWriter(XSSFWorkbook workbook) {
        super(workbook);
    }

    @Override
    protected int getLineOffset() {
        return 6;
    }

    @Override
    protected Map<Integer, Function<LodgingMealBusinessLine, ?>> getExtractorsByColumn() {
        return BINDING;
    }

    @Override
    protected void postFill(@NonNull Row row) {
        // ajout d'une formule pour les sommes intermédiaires
        final int rowNb = row.getRowNum() + 1;
        String formula = String.format("IF(SUM(%s%d:%s%d)-%s%d=0,\" \", SUM(%s%d:%s%d)-%s%d)",
                "C", rowNb, "F", rowNb, "I", rowNb, "C", rowNb, "F", rowNb, "I", rowNb);
        row.getCell(7).setCellFormula(formula);
    }

    @Override
    protected XSSFSheet getTargetSheet() {
        return getSheet(SHEET_EXCEPTIONAL_BUSINESS_TRAVEL);
    }

    @Override
    protected void fillFormula(@NonNull Row row, int startRow, int rowNb) {
        fillOneSumFormula(row.getCell(7), "H", startRow + 1, rowNb + 1);
        fillOneSumFormula(row.getCell(8), "I", startRow + 1, rowNb + 1);

    }
}
