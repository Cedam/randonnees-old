package com.infotel.agence.config.property;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration pour charger les propriétés
 */
@Configuration
@EnableConfigurationProperties({ ExpenseProperties.class })
public class PropertyConfig {
}
