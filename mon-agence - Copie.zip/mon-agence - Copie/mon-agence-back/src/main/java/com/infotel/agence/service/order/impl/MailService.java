package com.infotel.agence.service.order.impl;

import com.infotel.agence.domain.order.Mail;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.order.MailRepository;
import com.infotel.agence.service.order.IMailService;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.*;

/**
 * Service qui gère les entités {@link Mail}
 *
 * @author JUBA
 */
@Service
public class MailService implements IMailService {

    private static final String UNKNOWN_MAIL = "Aucun mail n''est référencé par l''id {0}";

    private final MailRepository mailRepository;

    public MailService(final MailRepository mailRepository) {
        this.mailRepository = mailRepository;
    }

    @Override
    public Mail findById(long id) {
        return mailRepository.findById(id)
                .orElseThrow(() -> new UnknownEntityException(UNKNOWN_MAIL, id));
    }

    @Override
    public List<Mail> findAll() {
        return mailRepository.findAll();
    }

    @Override
    public Mail create(@NonNull Mail mail) {
        return mailRepository.save(mail);
    }

    @Override
    public Mail update(@NonNull Mail mail) {
        Assert.notNull(mail.getId(), "L'id du mail ne peut être null");

        if (mailRepository.existsById(mail.getId())) {
            return mailRepository.save(mail);
        }
        throw new UnknownEntityException(UNKNOWN_MAIL, mail.getId());
    }

    @Override
    public void deleteById(long id) {
        if (mailRepository.existsById(id)) {
            mailRepository.deleteById(id);
        } else {
            throw new UnknownEntityException(UNKNOWN_MAIL, id);
        }
    }
}
