package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.GeneratedReport;
import com.infotel.agence.domain.expense.dto.GeneratedReportDTO;
import com.infotel.agence.service.expense.IGeneratedReportService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import static org.springframework.http.HttpHeaders.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.ResponseEntity.ok;

/**
 * Controleur pour la gestion des {@link GeneratedReport}
 *
 * @author arob
 */
@RestController
@RequestMapping(value = "/api/generatedReports", produces = APPLICATION_JSON_VALUE)
public class GeneratedReportController {

    private static final String NO_CACHE = "no-cache, no-store, max-age=0, must-revalidate";

    private final IGeneratedReportService generatedReportService;

    public GeneratedReportController(IGeneratedReportService generatedReportService) {
        this.generatedReportService = generatedReportService;
    }

    /**
     * Retourne une liste contenant l'ensemble des archives de comptes rendus
     *
     * @return liste des comptes rendus
     */
    @GetMapping("/all")
    public ResponseEntity<List<GeneratedReportDTO>> findAllGeneratedReportList() {
        return ok(generatedReportService.findAllList());
    }

    /**
     * Retourne le pdf de l'archive référencée par l'id en paramètre
     *
     * @param id                  id
     * @param httpServletResponse
     */
    @GetMapping(value = "/{id}", headers = { "accept=application/pdf" })
    public void findPdfById(@PathVariable long id, HttpServletResponse httpServletResponse) throws IOException {
        // Add content type
        httpServletResponse.setContentType("application/pdf");

        // Define response headers to disable cache
        httpServletResponse.setHeader(CACHE_CONTROL, NO_CACHE);
        httpServletResponse.setDateHeader(EXPIRES, 0L);

        // Définit l'en-tête "Content-Disposition" de la réponse afin d'inclure le nom du fichier
        String filename = generatedReportService.getFilename(id);
        httpServletResponse.setHeader(CONTENT_DISPOSITION, String.format("attachment; filename=\"%s.pdf\"", filename));

        generatedReportService.findPdfFileOfId(id, httpServletResponse.getOutputStream());
    }

    /**
     * Retourne l'excel de l'archive référencée par l'id en paramètre
     *
     * @param id                  id
     * @param httpServletResponse
     */
    @GetMapping(value = "/{id}", headers = { "accept=application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" })
    public void findExcelById(@PathVariable long id, HttpServletResponse httpServletResponse) throws IOException {
        // Add content typeEMPI_ID
        httpServletResponse.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

        // Define response headers to disable cache
        httpServletResponse.setHeader(CACHE_CONTROL, NO_CACHE);
        httpServletResponse.setDateHeader(EXPIRES, 0L);

        // Définit l'en-tête "Content-Disposition" de la réponse afin d'inclure le nom du fichier
        String filename = generatedReportService.getFilename(id);
        httpServletResponse.setHeader(CONTENT_DISPOSITION, String.format("attachment; filename=\"%s.xlsx\"", filename));

        generatedReportService.findXlsxFileOfId(id, httpServletResponse.getOutputStream());
    }

    /**
     * Retourne le zip de l'archive référencée par l'id en paramètre
     *
     * @param id                  id
     * @param httpServletResponse
     */
    @GetMapping(value = "/{id}", headers = { "accept=application/zip" })
    public void findZipById(@PathVariable long id, HttpServletResponse httpServletResponse) throws IOException {
        // Add content typeEMPI_ID
        httpServletResponse.setContentType("application/zip");

        // Define response headers to disable cache
        httpServletResponse.setHeader(CACHE_CONTROL, NO_CACHE);
        httpServletResponse.setDateHeader(EXPIRES, 0L);

        // Définit l'en-tête "Content-Disposition" de la réponse afin d'inclure le nom du fichier
        String filename = generatedReportService.getFilename(id);
        httpServletResponse.setHeader(CONTENT_DISPOSITION, String.format("attachment; filename=\"%s.zip\"", filename));

        generatedReportService.findZipFileOfId(id, httpServletResponse.getOutputStream());
    }

}
