package com.infotel.agence.service.expense;

import com.infotel.agence.domain.expense.Compensation;
import com.infotel.agence.domain.expense.dto.CompensationDTO;
import com.infotel.agence.service.expense.impl.CompensationService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import javax.annotation.security.RolesAllowed;
import java.math.BigDecimal;
import java.util.List;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_EXPENSE;

/**
 * Interface pour le service qui gère les entités {@link CompensationService}
 *
 * @author arob
 */
public interface ICompensationService {
    /**
     * Retourne la compensation référencée par l'id en paramètre
     *
     * @param id id
     * @return une compensation
     */
    @RolesAllowed(ROLE_EXPENSE)
    Compensation findById(long id);

    /**
     * Retourne une page contenant un sous-ensemble des compensations
     *
     * @param pageable les informations relatives à la page demandée
     * @return l'ensemble des compensations
     */
    @RolesAllowed(ROLE_EXPENSE)
    Page<Compensation> findAllPage(Pageable pageable);

    /**
     * Retourne une liste contenant l'ensemble des compensations
     *
     * @return l'ensemble des compensations
     */
    @RolesAllowed(ROLE_EXPENSE)
    List<Compensation> findAllList();

    /**
     * Crée une nouvelle compensation
     *
     * @param compensationDTO compensation
     * @return la nouvelle compensation
     */
    @RolesAllowed(ROLE_EXPENSE)
    Compensation create(CompensationDTO compensationDTO);

    /**
     * Met à jour une compensation existante
     *
     * @param id              id de la compnsation exeistante
     * @param compensationDTO compensation mise à jour
     * @return compensation mise à jour
     */
    @RolesAllowed(ROLE_EXPENSE)
    Compensation update(long id, CompensationDTO compensationDTO);

    /**
     * Renvoie l'indemnité kilométrique de l'utilisateur actuellement connecté
     *
     * @return une indemnité kilométrique
     */
    @RolesAllowed(ROLE_EXPENSE)
    BigDecimal getCurrentUserMileageAllowance();
}
