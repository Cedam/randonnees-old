package com.infotel.agence.service.expense.impl.report.excel.writer;

import com.infotel.agence.domain.expense.export.line.AbstractLine;
import com.infotel.agence.domain.expense.export.line.MergeCellRegion;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.lang.NonNull;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * Ecriture des données liées à n'importe quel type de tableau du fichier excel "NotesDeFrais".
 *
 * @author arob
 */
public abstract class AbstractChartWriter<T extends AbstractLine> extends AbstractCellWriter {
    // Style à appliquer aux cellules que l'on va créer
    private final XSSFCellStyle style;

    public AbstractChartWriter(XSSFWorkbook workbook) {
        super(workbook);
        style = getDefaultStyle();
    }

    /**
     * Ecriture complête d'un tableau du fichier excel.
     *
     * @param lines      contenu des lignes
     * @param currentRow ligne excel
     * @return position de la dernière ligne du tableau
     */
    public int writeChart(@NonNull final List<T> lines, final int currentRow) {
        // Récupération de la bonne feuille de calcul
        XSSFSheet sheet = getTargetSheet();

        // Mise à jour de la position de départ
        int startRow = currentRow + getLineOffset();
        int rowNb = startRow;

        // Parcours des lignes
        for (T lineData : lines) {
            final Row row = sheet.getRow(rowNb);

            // récupération du binding colonne/fonction d'extraction
            final Map<Integer, Function<T, ?>> extractorsByColumn = getExtractorsByColumn();

            // Récupération et remplissage de la valeur à partir du binding colonne/fonction d'extraction
            extractorsByColumn.forEach((col, fn) -> fillOneCell(row.getCell(col), fn.apply(lineData)));

            // Application de la formule particulière si nécessaire
            postFill(row);
            rowNb++;

            // Création d'une ligne supplémentaire après celle nouvellement remplie
            insertRowAfter(sheet, rowNb, Collections.max(extractorsByColumn.keySet()), lineData.getMerges());
        }

        // Mise à jour des deux formules présentes au pied du tableau
        fillFormula(sheet.getRow(rowNb + 1), startRow, rowNb);

        return rowNb;
    }

    /**
     * Récupère la feuille de calcul à utiliser pour écrire le tableau.
     *
     * @return feuille de calcul.
     */
    protected abstract XSSFSheet getTargetSheet();

    /**
     * Récupère la premiere ligne excel en fonction de la dernère ligne utilisée (dépendant du tableau précedent).
     *
     * @return indice de la ligne de départ du tableau à compléter.
     */
    protected int getLineOffset() {
        return NumberUtils.INTEGER_ZERO;
    }

    /**
     * Récupère le binding colonne/fonction d'extraction qui permet de déterminer les valeurs à ajouter dans le tableau.
     *
     * @return Un binding colonne/fonction d'extraction.
     */
    protected abstract Map<Integer, Function<T, ?>> getExtractorsByColumn();

    /**
     * Ajoute un comportement supplémentaire sur une ligne donnée après le remplissage "standard"
     *
     * @param row ligne excel
     */
    protected void postFill(final Row row) {
    }

    /**
     * Génère une nouvelle ligne du tableur, les cellules associées, le style par defaut ainsi
     * que les merges des cellules demandés.
     *
     * @param sheet     feuille de calcul
     * @param row       ligne excel
     * @param nbColumns nombre de colonnes
     * @param merges    zone des cellules à merger
     */
    private void insertRowAfter(@NonNull final XSSFSheet sheet, final int row, final int nbColumns, final List<MergeCellRegion> merges) {
        sheet.shiftRows(row, sheet.getLastRowNum(), 1);
        Row newRow = sheet.createRow(row);

        for (int cellId = 1; cellId <= nbColumns; cellId++) {
            newRow.createCell(cellId).setCellStyle(style);
        }

        for (MergeCellRegion merge : merges) {
            sheet.addMergedRegion(new CellRangeAddress(row, row, merge.getFirst(), merge.getSecond()));
        }
    }

    /**
     * Permet le remplissage des cellules aynt pour rôle de faire la somme des montants.
     *
     * @param row      ligne excel
     * @param startRow position de la première ligne du tableau
     * @param rowNb    nombre de ligne dans le tableau
     * @see #fillOneSumFormula(Cell, String, int, int)
     */
    protected abstract void fillFormula(@NonNull final Row row, final int startRow, final int rowNb);

    /**
     * Ecrit la formule de la somme dans la cellule donnée.
     *
     * @param cell      cellule
     * @param colLetter la lettre representant la colonne à sommer
     * @param startRow  le numéro de la première ligne de la colonne à sommer (INCLUS).
     * @param endRow    le numéro de la dernière ligne de la colonne à sommer (INCLUS).
     */
    protected void fillOneSumFormula(@NonNull final Cell cell, final String colLetter, final int startRow, final int endRow) {
        String formula = String.format("IF(SUM(%s%d:%s%d)=0,\" \",SUM(%s%d:%s%d))",
                colLetter, startRow, colLetter, endRow, colLetter, startRow, colLetter, endRow);
        cell.setCellFormula(formula);
    }
}
