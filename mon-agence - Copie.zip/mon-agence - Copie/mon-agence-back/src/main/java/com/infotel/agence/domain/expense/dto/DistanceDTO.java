package com.infotel.agence.domain.expense.dto;

import com.infotel.agence.domain.expense.Distance;
import com.infotel.agence.domain.expense.Place;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import java.math.BigDecimal;

/**
 * DTO de la classe {@link Distance}
 *
 * @author arob
 */
@Data
@Generated
@NoArgsConstructor
public class DistanceDTO {

    /**
     * Valeur de la distance
     */
    @Digits(integer = 7, fraction = 3, message = "La distance entre deux places ne peut pas dépasser 9999,99")
    private BigDecimal value;

    /**
     * Place de départ
     */
    @Valid
    private Place placeStart;

    /**
     * Place d'arrivé
     */
    @Valid
    private Place placeEnd;
}
