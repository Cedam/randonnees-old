package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.ReceiptPicture;
import com.infotel.agence.service.expense.IReceiptPictureService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.ResponseEntity.ok;

/**
 * Controleur pour la gestion des {@link ReceiptPicture}
 *
 * @author arob
 */
@RestController
@RequestMapping(value = "/api/receiptPictures", produces = APPLICATION_JSON_VALUE)
public class ReceiptPictureController {

    private final IReceiptPictureService receiptPictureService;

    public ReceiptPictureController(IReceiptPictureService receiptPictureService) {
        this.receiptPictureService = receiptPictureService;
    }

    /**
     * Retourne l'image du ticket référencé par l'id en paramètre
     *
     * @param ticketId id du ticket
     * @return la receiptPicture liée au ticket
     */
    @GetMapping("/{ticketId}")
    public ResponseEntity<ReceiptPicture> findReceiptPictureByTicketId(@PathVariable long ticketId) {
        return ok(receiptPictureService.findByTicketId(ticketId));
    }
}
