package com.infotel.agence.domain.expense;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.infotel.agence.domain.Resource;
import com.infotel.agence.domain.user.User;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import javax.validation.constraints.Size;

/**
 * Identité lié à un {@link User} afin de stocker les informations propre à la
 * partie Expense.
 *
 * @author arob
 */
@Entity
@Data
@NoArgsConstructor
@SuperBuilder
@Generated
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Table(name = "EMPLOYEE_IDENTITY")
public class EmployeeIdentity implements Resource {

    /**
     * Id de l'identité de l'employé
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EMPI_ID")
    private Long id;

    /**
     * Matricule lié à l'identité de l'employé
     */
    @Size(max = 255, message = "Le matricule de l'identité employé ne doit pas dépasser 255 caractères")
    @Column(name = "EMPI_SERIAL_NUMBER")
    private String serialNumber;

    /**
     * L'agence lié à l'identité de l'employé
     */
    @Size(max = 255, message = "L'agence de l'identité employé ne doit pas dépasser 255 caractères")
    @Column(name = "EMPI_AGENCY")
    private String agency;

    /**
     * Le client principal lié à l'identité de l'employé
     */
    @Size(max = 255, message = "Le client principal de l'identité employé ne doit pas dépasser 255 caractères")
    @Column(name = "EMPI_CUSTOMER")
    private String customer;

    /**
     * Le code opération lié à l'identité de l'employé
     */
    @Size(max = 255, message = "Le code opération de l'identité employé ne doit pas dépasser 255 caractères")
    @Column(name = "EMPI_OPERATION_CODE")
    private String operationCode;

    /**
     * La plaque d'immatriculation lié à l'identité de l'employé
     */
    @Size(max = 255, message = "La plaque d'immatriculation de l'identité employé ne doit pas dépasser 255 caractères")
    @Column(name = "EMPI_LICENCE_PLATE")
    private String licencePlate;

    /**
     * La compensation kilométrique lié à l'identité de l'employé
     */
    @ManyToOne(optional = false)
    @JoinColumn(name = "EMPI_COMPENSATION", foreignKey = @ForeignKey(name = "FK_EMPLOYEEIDENTITY_COMPENSATION"))
    private Compensation compensation;

    /**
     * User lié à l'identité de l'employé
     */
    @OneToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "EMPI_ID", referencedColumnName = "USR_ID", foreignKey = @ForeignKey(name = "FK_EMPLOYEEIDENTITY_USER"))
    @JsonIgnore
    private User user;
}
