package com.infotel.agence.domain.expense;

import com.infotel.agence.domain.Resource;
import com.infotel.agence.domain.user.User;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.Digits;
import java.math.BigDecimal;

/**
 * Compensation lié à un {@link User} afin de stocker les informations concernant le lien entre
 * les chevaux fiscaux et l'indemnité kilométrique.
 *
 * @author arob
 */
@Entity
@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Generated
@Table(name = "COMPENSATION", uniqueConstraints = { @UniqueConstraint(columnNames = { "COMP_CV" }, name = "UC_COMPENSATION_CV") })
public class Compensation implements Resource {

    /**
     * Id de la compensation
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "COMP_ID")
    private Long id;

    /**
     * Chevaux fiscaux de la compensation
     */
    @Column(name = "COMP_CV")
    private int cv;

    /**
     * Indemnité kilométrique de la compensation
     */
    @Digits(integer = 4, fraction = 3, message = "L'indémnité kilométrique ne peut pas dépasser 9,999")
    @Column(name = "COMP_MILEAGE_ALLOWANCE")
    private BigDecimal mileageAllowance;
}
