package com.infotel.agence.controller.handler;

import com.infotel.agence.controller.handler.GlobalExceptionHandler.ErrorResponse;
import com.infotel.agence.exception.BusinessException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Tests for {@link GlobalExceptionHandler} class
 *
 * @author ARLI
 */
@ExtendWith(MockitoExtension.class)
class GlobalExceptionHandlerTest {

    @Mock
    private MessageSource messageSource;

    private GlobalExceptionHandler exceptionHandler;

    @BeforeEach
    public void setUp() {
        exceptionHandler = new GlobalExceptionHandler(messageSource);
    }

    @Test
    void testHandleAppException() {
        // given
        String expectedPath = "/test";
        String expectedMessage = "MESSAGE";
        HttpStatus expectedStatus = HttpStatus.INTERNAL_SERVER_ERROR;

        // when
        ResponseEntity<ErrorResponse> result = exceptionHandler.handleAppException( //
                new BusinessException(expectedMessage), new MockHttpServletRequest("GET", expectedPath));

        // then
        assertThat(result.getStatusCode()).isEqualTo(expectedStatus);
        assertThat(result.getBody()) //
                .isNotNull() //
                .extracting(ErrorResponse::getStatus, ErrorResponse::getMessage, ErrorResponse::getPath)
                .containsExactly(expectedStatus.value(), expectedMessage, expectedPath);
    }

    @Test
    void testHandleAccessDeniedException() {
        // given
        String expectedPath = "/test";
        String expectedMessage = "TRANSLATED MESSAGE";
        HttpStatus expectedStatus = HttpStatus.FORBIDDEN;
        given(messageSource.getMessage(AccessDeniedException.class.getName(), null, LocaleContextHolder.getLocale())).willReturn(expectedMessage);

        // when
        ResponseEntity<ErrorResponse> result = exceptionHandler.handleAccessDeniedException( //
                new AccessDeniedException("MESSAGE"), new MockHttpServletRequest("GET", expectedPath));

        // then
        assertThat(result.getStatusCode()).isEqualTo(expectedStatus);
        assertThat(result.getBody()) //
                .isNotNull() //
                .extracting(ErrorResponse::getStatus, ErrorResponse::getMessage, ErrorResponse::getPath)
                .containsExactly(expectedStatus.value(), expectedMessage, expectedPath);
    }

    @Test
    void testHandleAuthenticationException() {
        // given
        String expectedPath = "/test";
        String expectedMessage = "TRANSLATED MESSAGE";
        HttpStatus expectedStatus = HttpStatus.UNAUTHORIZED;
        given(messageSource.getMessage(AuthenticationException.class.getName(), null, LocaleContextHolder.getLocale())).willReturn(expectedMessage);

        // when
        ResponseEntity<ErrorResponse> result = exceptionHandler.handleAuthenticationException( //
                new BadCredentialsException("MESSAGE"), new MockHttpServletRequest("GET", expectedPath));

        // then
        assertThat(result.getStatusCode()).isEqualTo(expectedStatus);
        assertThat(result.getBody()) //
                .isNotNull() //
                .extracting(ErrorResponse::getStatus, ErrorResponse::getMessage, ErrorResponse::getPath)
                .containsExactly(expectedStatus.value(), expectedMessage, expectedPath);
    }

}
