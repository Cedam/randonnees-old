package com.infotel.agence.utils;

import org.hibernate.boot.model.naming.Identifier;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests unitaires de la classe {@link PhysicalNamingStrategyImpl}
 *
 * @author ARLI
 */
class PhysicalNamingStrategyImplTest {

    private PhysicalNamingStrategyImpl physicalNamingStrategy = new PhysicalNamingStrategyImpl();

    @Test
    void testToPhysicalTableNameIdentifierJdbcEnvironment() {
        Identifier name = new Identifier("TableName", false);

        Identifier modifiedName = physicalNamingStrategy.toPhysicalTableName(name, null);

        assertThat(modifiedName.getText()).isEqualTo("TABLE_NAME");
    }

    @Test
    void testToPhysicalColumnNameIdentifierJdbcEnvironment() {
        Identifier name = new Identifier("fieldName", false);

        Identifier modifiedName = physicalNamingStrategy.toPhysicalColumnName(name, null);

        assertThat(modifiedName.getText()).isEqualTo("FIELD_NAME");
    }

}
