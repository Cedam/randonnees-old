package com.infotel.agence.security;

public class BasicAuthorizationFilterTest {
    // TODO add tests
}