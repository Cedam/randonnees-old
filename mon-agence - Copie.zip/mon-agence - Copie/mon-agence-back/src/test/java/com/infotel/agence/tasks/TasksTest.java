package com.infotel.agence.tasks;

import com.infotel.agence.config.property.ExpenseProperties;
import com.infotel.agence.service.expense.IGeneratedReportService;
import com.infotel.agence.service.expense.ITicketService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link Tasks}
 *
 * @author arob
 */
@ExtendWith(MockitoExtension.class)
class TasksTest {

    @Mock
    private ITicketService ticketService;

    @Mock
    private IGeneratedReportService generatedReportService;

    @Mock
    private ExpenseProperties expenseProperties;

    private Tasks tasks;

    @BeforeEach
    public void setUp() {
        tasks = new Tasks(ticketService, generatedReportService, expenseProperties);
    }

    @Test
    void testDeleteArchivedTickets() {
        // given
        int minusMonthDeleteArchivedTickets = 6;
        LocalDate date = LocalDate.now().minusMonths(minusMonthDeleteArchivedTickets);
        given(expenseProperties.getTicketsExpirationDelayMonths()).willReturn(minusMonthDeleteArchivedTickets);

        // when
        tasks.deleteArchivedTickets();

        // then
        then(ticketService).should().deleteTicketsOlderThan(date);
    }

    @Test
    void testDeleteGeneratedReports() {
        // given
        int minusMonthDeleteGeneratedReports = 12;
        LocalDate date = LocalDate.now().minusMonths(minusMonthDeleteGeneratedReports);
        given(expenseProperties.getReportsExpirationDelayMonths()).willReturn(minusMonthDeleteGeneratedReports);

        // when
        tasks.deleteGeneratedReports();

        // then
        then(generatedReportService).should().deleteGeneratedReportsOlderThan(date);
    }
}
