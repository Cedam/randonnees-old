package com.infotel.agence.service.user.impl;

import com.infotel.agence.domain.user.Authority;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.user.UserRepository;
import com.infotel.agence.service.expense.IEmployeeIdentityService;
import com.infotel.agence.service.expense.ITicketService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link UserService}
 *
 * @author ARLI / AROB
 */
@ExtendWith(MockitoExtension.class)
class UserServiceTest {
    // --------------------------------------------------------- TESTS POUR deleteById(long id) -----------------------------------------------------------
    long userId = 1;
    @Mock
    private UserRepository userRepository;
    @Mock
    private ITicketService ticketService;
    @Mock
    private IEmployeeIdentityService employeeIdentityService;
    private UserService userService;
    @Mock
    private Authentication authentication;

    @BeforeEach
    public void setup() {
        userService = new UserService(userRepository, ticketService, employeeIdentityService);
    }

    @Test
    void testLoadUserByUsername_should_return_user() {
        // given
        String username = "USERNAME";
        User expectedUser = new User();
        expectedUser.setUsername(username);
        given(userRepository.findByUsername(username)).willReturn(expectedUser);

        // when
        UserDetails result = userService.loadUserByUsername(username);

        // then
        assertThat(result).isEqualTo(expectedUser);
    }

    @Test
    void testSetRefreshToken_should_refresh() {
        // Given
        String username = "username";
        String refreshToken = "token";

        // When
        userService.setRefreshToken(username, refreshToken);

        // Then
        then(userRepository).should().setRefreshToken(username, refreshToken);
        then(userRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findAllPage() -----------------------------------------------------------
    @Test
    void testFindAllPageUsers() {
        // given
        PageRequest pageable = PageRequest.of(0, 10);
        User user = new User();
        given(userRepository.findAll(pageable)).willReturn(new PageImpl<>(List.of(user), pageable, 1));

        // when
        Page<User> result = userService.findAllPage(pageable);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(user);
        assertThat(result.getPageable()).isEqualTo(pageable);
        then(userRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findAllList() -----------------------------------------------------------
    @Test
    void testFindAllListUsers() {
        // given
        User user = new User();
        given(userRepository.findAll()).willReturn(List.of(user));

        // when
        List<User> result = userService.findAllList();

        // then
        assertThat(result)
                .hasSize(1)
                .contains(user);
        then(userRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findById(long id) -----------------------------------------------------------
    @Test
    void testFindById_with_existing_user() {
        // given
        long userId = 1;
        User user = User.builder().id(userId).build();
        given(userRepository.findById(userId)).willReturn(Optional.of(user));

        // when
        User result = userService.findById(userId);

        // then
        assertThat(result).isEqualTo(user);
        then(userRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindById_without_existing_user() {
        // given
        long userId = -1;
        given(userRepository.findById(userId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> userService.findById(userId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(UserService.UNKNOWN_USER, userId));
        then(userRepository).shouldHaveNoMoreInteractions();
    }

    void setUpAuthentication() {
        // Contexte de sécurité
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);

        given(securityContext.getAuthentication()).willReturn(authentication);

        // Connexion de l'utilisateur
        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        user.setId(userId);

        given(authentication.getPrincipal()).willReturn(user);
    }

    @Test
    void deleteById_with_existing_user() {
        setUpAuthentication();

        // given
        long deleteUserId = 2;
        given(userRepository.existsById(deleteUserId)).willReturn(true);

        // when
        userService.deleteById(deleteUserId);

        // then
        then(ticketService).should().deleteAllOfUser(deleteUserId);
        then(employeeIdentityService).should().deleteById(deleteUserId);
        then(userRepository).should().deleteById(deleteUserId);
    }

    @Test
    void deleteById_with_current_user() {
        setUpAuthentication();

        // given
        long deleteUserId = 1;

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> userService.deleteById(deleteUserId),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(UserService.NOT_AUTHORIZED);
        then(ticketService).shouldHaveNoMoreInteractions();
        then(employeeIdentityService).shouldHaveNoMoreInteractions();
        then(userRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void deleteById_with_unknown_user() {
        setUpAuthentication();

        // given
        long deleteUserId = -1;
        given(userRepository.existsById(deleteUserId)).willReturn(false);

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> userService.deleteById(deleteUserId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(UserService.UNKNOWN_USER, deleteUserId));
        then(ticketService).shouldHaveNoMoreInteractions();
        then(employeeIdentityService).shouldHaveNoMoreInteractions();
        then(userRepository).shouldHaveNoMoreInteractions();
    }
}