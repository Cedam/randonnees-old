package com.infotel.agence.service.order.impl;

import com.infotel.agence.domain.order.Mail;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.order.MailRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.AdditionalAnswers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowableOfType;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link MailService}
 *
 * @author JUBA
 */
@ExtendWith(MockitoExtension.class)
class MailServiceTest {

    @Mock
    private MailRepository mailRepository;

    private MailService mailService;

    @BeforeEach
    public void setUp() {
        mailService = new MailService(mailRepository);
    }

    @Test
    void testFindMailById_with_existing_mail() {
        // given
        long mailId = 1;
        Mail mail = Mail.builder().id(mailId).build();
        given(mailRepository.findById(mailId)).willReturn(Optional.of(mail));

        // when
        Mail result = mailService.findById(mailId);

        // then
        assertThat(result).isEqualTo(mail);
    }

    @Test
    void testFindMailById_with_unknown_mail() {
        // given
        long mailId = -1;
        given(mailRepository.findById(mailId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = catchThrowableOfType(
                () -> mailService.findById(mailId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage("Aucun mail n'est référencé par l'id -1");
    }

    @Test
    void testFindAllMails() {
        // given
        Mail mail = new Mail();
        given(mailRepository.findAll()).willReturn(List.of(mail));

        // when
        List<Mail> result = mailService.findAll();

        // then
        assertThat(result)
                .hasSize(1)
                .contains(mail);
    }

    @Test
    void testCreateMailById() {
        // given
        Mail mail = new Mail();
        given(mailRepository.save(any(Mail.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Mail result = mailService.create(mail);

        // then
        assertThat(result).isEqualTo(mail);
    }

    @Test
    void testUpdateMail_with_existing_mail() {
        // given
        long mailId = 1;
        Mail mail = Mail.builder().id(mailId).build();
        given(mailRepository.existsById(mailId)).willReturn(true);
        given(mailRepository.save(any(Mail.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Mail result = mailService.update(mail);

        // then
        assertThat(result).isEqualTo(mail);
    }

    @Test
    void testUpdateMail_with_unknown_mail() {
        // given
        long mailId = -1;
        Mail mail = Mail.builder().id(mailId).build();
        given(mailRepository.existsById(mailId)).willReturn(false);

        // when
        UnknownEntityException result = catchThrowableOfType(
                () -> mailService.update(mail),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage("Aucun mail n'est référencé par l'id -1");
        then(mailRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteMailById_with_existing_mail() {
        // given
        long mailId = 1;
        given(mailRepository.existsById(mailId)).willReturn(true);

        // when
        mailService.deleteById(mailId);

        // then
        then(mailRepository).should().deleteById(mailId);
    }

    @Test
    void testDeleteMailById_with_unknown_mail() {
        // given
        long mailId = -1;
        given(mailRepository.existsById(mailId)).willReturn(false);

        // when
        UnknownEntityException result = catchThrowableOfType(
                () -> mailService.deleteById(mailId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage("Aucun mail n'est référencé par l'id -1");
        then(mailRepository).shouldHaveNoMoreInteractions();
    }

}
