package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.Distance;
import com.infotel.agence.domain.expense.Place;
import com.infotel.agence.domain.expense.dto.DistanceDTO;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.DistanceRepository;
import com.infotel.agence.repository.expense.PlaceRepository;
import com.infotel.agence.repository.expense.TicketRepository;
import com.querydsl.core.types.dsl.BooleanExpression;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.AdditionalAnswers;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link DistanceService}
 *
 * @author arob
 */
@ExtendWith(MockitoExtension.class)
class DistanceServiceTest {

    @Mock
    private DistanceRepository distanceRepository;

    @Mock
    private PlaceRepository placeRepository;

    @Mock
    private TicketRepository ticketRepository;

    private DistanceService distanceService;

    @BeforeEach
    public void setUp() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        distanceService = new DistanceService(distanceRepository, placeRepository, ticketRepository, mapperFactory.getMapperFacade());
    }

    // ----------------------------------------------------------- TESTS POUR findAll() -------------------------------------------------------------
    @Test
    void testFindAllDistances() {
        // given
        PageRequest pageable = PageRequest.of(0, 10);
        Distance distance = new Distance();
        given(distanceRepository.findAll(pageable)).willReturn(new PageImpl(List.of(distance), pageable, 1));

        // when
        Page<Distance> result = distanceService.findAll(pageable);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(distance);
        assertThat(result.getPageable()).isEqualTo(pageable);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    // ---------------------------------------------------- TESTS POUR create(Distance distance) ----------------------------------------------------
    @Test
    void testCreateDistance_with_unknown_distance() {
        // given
        long idPlaceA = 1;
        long idPlaceB = 2;
        Place placeA = Place.builder().id(idPlaceA).build();
        Place placeB = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeA);
        distanceDTO.setPlaceEnd(placeB);
        ArgumentCaptor<Distance> argument = ArgumentCaptor.forClass(Distance.class);
        ArgumentCaptor<BooleanExpression> argumentBooleanExpression = ArgumentCaptor.forClass(BooleanExpression.class);
        given(distanceRepository.findOne(argumentBooleanExpression.capture())).willReturn(Optional.empty());
        given(distanceRepository.save(any(Distance.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Distance result = distanceService.create(distanceDTO);

        // then
        assertThat(result.getValue()).isEqualTo(distanceDTO.getValue());
        assertThat(result.getPlaceStart()).isEqualTo(distanceDTO.getPlaceStart());
        assertThat(result.getPlaceEnd()).isEqualTo(distanceDTO.getPlaceEnd());
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreateDistance_with_known_distance() {
        // given
        long idPlaceA = 1;
        long idPlaceB = 2;
        Place placeA = Place.builder().id(idPlaceA).build();
        Place placeB = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeA);
        distanceDTO.setPlaceEnd(placeB);
        ArgumentCaptor<BooleanExpression> argumentBooleanExpression = ArgumentCaptor.forClass(BooleanExpression.class);
        given(distanceRepository.findOne(argumentBooleanExpression.capture())).willReturn(Optional.of(Distance.builder().build()));

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.create(distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(DistanceService.ALREADY_KNOWN_DISTANCE, idPlaceA, idPlaceB));
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreateDistance_with_null_distance() {
        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.create(null),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_DISTANCE);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreateDistance_with_null_placeStart() {
        long idPlaceB = 2;
        Place placeB = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceEnd(placeB);

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.create(distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_DISTANCE);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreateDistance_with_null_placeEnd() {
        long idPlaceA = 1;
        Place placeA = Place.builder().id(idPlaceA).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeA);

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.create(distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_DISTANCE);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreateDistance_with_null_placeStart_id() {
        long idPlaceB = 2;
        Place placeA = Place.builder().build();
        Place placeB = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeA);
        distanceDTO.setPlaceEnd(placeB);

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.create(distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_PLACE_ID);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreateDistance_with_null_placeEnd_id() {
        long idPlaceA = 1;
        Place placeA = Place.builder().id(idPlaceA).build();
        Place placeB = Place.builder().build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeA);
        distanceDTO.setPlaceEnd(placeB);

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.create(distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_PLACE_ID);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    // ------------------------------------------- TESTS POUR findByPlacesId(long idPlaceA, long idPlaceB) ------------------------------------------
    @Test
    void testFindDistanceByPlacesId_with_known_ids() {
        // given
        long idPlaceA = 1;
        long idPlaceB = 2;
        Place placeStart = Place.builder().id(idPlaceA).build();
        Place placeEnd = Place.builder().id(idPlaceB).build();
        Distance distance = Distance.builder().placeStart(placeStart).placeEnd(placeEnd).build();
        ArgumentCaptor<BooleanExpression> argumentBooleanExpression = ArgumentCaptor.forClass(BooleanExpression.class);
        given(distanceRepository.findOne(argumentBooleanExpression.capture())).willReturn(Optional.of(distance));

        // when
        Distance result = distanceService.findByPlacesId(idPlaceA, idPlaceB);

        // then
        assertThat(idPlaceA).isEqualTo(result.getPlaceStart().getId());
        assertThat(idPlaceB).isEqualTo(result.getPlaceEnd().getId());
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindDistanceByPlacesId_with_unknown_ids() {
        // given
        long idPlaceA = -1;
        long idPlaceB = -2;
        ArgumentCaptor<BooleanExpression> argumentBooleanExpression = ArgumentCaptor.forClass(BooleanExpression.class);
        given(distanceRepository.findOne(argumentBooleanExpression.capture())).willReturn(Optional.empty());

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.findByPlacesId(idPlaceA, idPlaceB),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(DistanceService.UNKNOWN_PLACES_DISTANCE, idPlaceA, idPlaceB));
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    // ------------------------------------------- TESTS POUR findByPlaceId(long idPlace) ------------------------------------------
    @Test
    void testFindDistanceByPlaceId_with_known_id() {
        // given
        long idPlace = 1;
        Place place = Place.builder().id(idPlace).build();
        Distance distance = Distance.builder().placeStart(place).build();
        ArgumentCaptor<BooleanExpression> argumentBooleanExpression = ArgumentCaptor.forClass(BooleanExpression.class);
        given(distanceRepository.findAll(argumentBooleanExpression.capture())).willReturn(List.of(distance));

        // when
        List<Distance> result = distanceService.findByPlaceId(idPlace);

        // then
        assertThat(result).isNotEmpty();
        assertThat(result.size()).isEqualTo(1);
        assertThat(result.get(0).getPlaceStart().getId()).isEqualTo(idPlace);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindDistanceByPlaceId_with_unknown_id() {
        // given
        long idPlace = -1;
        ArgumentCaptor<BooleanExpression> argumentBooleanExpression = ArgumentCaptor.forClass(BooleanExpression.class);
        given(distanceRepository.findAll(argumentBooleanExpression.capture())).willReturn(new ArrayList<>());

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.findByPlaceId(idPlace),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(DistanceService.UNKNOWN_PLACE_DISTANCE, idPlace));
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    // ---------------------------------------------------- TESTS POUR update(Distance distance) ----------------------------------------------------
    @Test
    void testUpdateDistance_with_known_ids() {
        // given
        long idPlaceA = 1;
        long idPlaceB = 2;
        long idDistance = 1;
        Place placeStart = Place.builder().id(idPlaceA).build();
        Place placeEnd = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeStart);
        distanceDTO.setPlaceEnd(placeEnd);
        given(distanceRepository.existsById(idDistance)).willReturn(true);
        given(placeRepository.existsById(idPlaceA)).willReturn(true);
        given(placeRepository.existsById(idPlaceB)).willReturn(true);
        given(distanceRepository.save(any(Distance.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Distance result = distanceService.update(idDistance, distanceDTO);

        // then
        assertThat(idPlaceA).isEqualTo(result.getPlaceStart().getId());
        assertThat(idPlaceB).isEqualTo(result.getPlaceEnd().getId());
        assertThat(idDistance).isEqualTo(result.getId());
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateDistance_with_unknown_idPlaceA() {
        // given
        long idPlaceA = -1;
        long idPlaceB = 2;
        long idDistance = 1;
        Place placeStart = Place.builder().id(idPlaceA).build();
        Place placeEnd = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeStart);
        distanceDTO.setPlaceEnd(placeEnd);
        given(distanceRepository.existsById(idDistance)).willReturn(true);
        given(placeRepository.existsById(idPlaceA)).willReturn(false);

        /// when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.update(idDistance, distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(DistanceService.UNKNOWN_PLACES_DISTANCE, idPlaceA, idPlaceB));
        then(distanceRepository).shouldHaveNoMoreInteractions();
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateDistance_with_unknown_idPlaceB() {
        // given
        long idPlaceA = 1;
        long idPlaceB = -1;
        long idDistance = 1;
        Place placeStart = Place.builder().id(idPlaceA).build();
        Place placeEnd = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeStart);
        distanceDTO.setPlaceEnd(placeEnd);
        given(distanceRepository.existsById(idDistance)).willReturn(true);
        given(placeRepository.existsById(idPlaceA)).willReturn(true);
        given(placeRepository.existsById(idPlaceB)).willReturn(false);

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.update(idDistance, distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(DistanceService.UNKNOWN_PLACES_DISTANCE, idPlaceA, idPlaceB));
        then(distanceRepository).shouldHaveNoMoreInteractions();
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateDistance_with_null_distance() {
        /// when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.update(1, null),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_DISTANCE);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateDistance_with_null_placeA() {
        // given
        long idPlaceB = 2;
        long idDistance = 1;
        Place placeEnd = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceEnd(placeEnd);

        /// when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.update(idDistance, distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_DISTANCE);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateDistance_with_null_placeB() {
        // given
        long idPlaceA = 1;
        long idDistance = 1;
        Place placeStart = Place.builder().id(idPlaceA).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeStart);

        /// when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.update(idDistance, distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_DISTANCE);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateDistance_with_null_idPlaceA() {
        // given
        long idPlaceB = 2;
        long idDistance = 1;
        Place placeStart = Place.builder().build();
        Place placeEnd = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeStart);
        distanceDTO.setPlaceEnd(placeEnd);

        /// when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.update(idDistance, distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_DISTANCE);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateDistance_with_null_idPlaceB() {
        // given
        long idPlaceA = 1;
        long idDistance = 1;
        Place placeStart = Place.builder().id(idPlaceA).build();
        Place placeEnd = Place.builder().build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeStart);
        distanceDTO.setPlaceEnd(placeEnd);

        /// when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.update(idDistance, distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(DistanceService.NON_NULL_DISTANCE);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateDistance_with_known_ids_but_undefined_distance() {
        // given
        long idPlaceA = 1;
        long idPlaceB = 2;
        long idDistance = 1;
        Place placeStart = Place.builder().id(idPlaceA).build();
        Place placeEnd = Place.builder().id(idPlaceB).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        distanceDTO.setPlaceStart(placeStart);
        distanceDTO.setPlaceEnd(placeEnd);
        given(distanceRepository.existsById(idDistance)).willReturn(false);
//        given(placeRepository.existsById(idPlaceA)).willReturn(true);
//        given(placeRepository.existsById(idPlaceB)).willReturn(true);
//        given(distanceRepository.save(any(Distance.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> distanceService.update(idDistance, distanceDTO),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(DistanceService.UNKNOWN_PLACES_DISTANCE, idPlaceA, idPlaceB));
        then(distanceRepository).shouldHaveNoMoreInteractions();
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    // -------------------------------------------------------- TESTS POUR findById(long id) --------------------------------------------------------
    @Test
    void testFindDistanceById_with_existing_distance() {
        // given
        long distanceId = 1;
        Distance distance = Distance.builder().id(distanceId).build();
        given(distanceRepository.findById(distanceId)).willReturn(Optional.of(distance));

        // when
        Distance result = distanceService.findById(distanceId);

        // then
        assertThat(result).isEqualTo(distance);
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindDistanceById_with_unknown_distance() {
        // given
        long distanceId = -1;
        given(distanceRepository.findById(distanceId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> distanceService.findById(distanceId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(DistanceService.UNKNOWN_DISTANCE, distanceId));
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    // -------------------------------------------------------- TESTS POUR deleteById(long idDistance) --------------------------------------------------------
    @Test
    void testDeleteById() {
        // given
        long distanceId = 1;

        // when
        distanceService.deleteById(distanceId);

        // then
        then(distanceRepository).should().deleteById(distanceId);
        then(distanceRepository).shouldHaveNoMoreInteractions();
    }
}
