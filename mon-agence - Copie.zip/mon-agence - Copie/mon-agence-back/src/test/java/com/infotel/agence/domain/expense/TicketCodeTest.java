package com.infotel.agence.domain.expense;

import com.infotel.agence.domain.expense.ticket.TicketCode;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class TicketCodeTest {

    @Test
    void toMap() {
        Map<String, String> result = TicketCode.toMap();

        for (TicketCode code : TicketCode.values()) {
            assertThat(result).containsEntry(code.name(), code.getLabel());
        }
    }
}