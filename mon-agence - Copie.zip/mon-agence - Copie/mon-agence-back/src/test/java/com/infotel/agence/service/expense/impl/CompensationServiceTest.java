package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.Compensation;
import com.infotel.agence.domain.expense.dto.CompensationDTO;
import com.infotel.agence.domain.user.Authority;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.CompensationRepository;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.AdditionalAnswers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link CompensationService}
 *
 * @author arob
 */
@ExtendWith(MockitoExtension.class)
class CompensationServiceTest {
    @Mock
    private CompensationRepository compensationRepository;

    private CompensationService compensationService;

    @Mock
    private Authentication authentication;

    @BeforeEach
    public void setUp() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        compensationService = new CompensationService(compensationRepository, mapperFactory.getMapperFacade());
    }

    // -------------------------------------------------------- TESTS POUR findById(long id) --------------------------------------------------------
    @Test
    void testFindCompensationById_with_existing_compensation() {
        // given
        long compensationId = 1;
        Compensation compensation = Compensation.builder().id(compensationId).build();
        given(compensationRepository.findById(compensationId)).willReturn(Optional.of(compensation));

        // when
        Compensation result = compensationService.findById(compensationId);

        // then
        assertThat(result).isEqualTo(compensation);
        then(compensationRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindCompensationById_with_unknown_compensation() {
        // given
        long compensationId = -1;
        given(compensationRepository.findById(compensationId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> compensationService.findById(compensationId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(CompensationService.UNKNOWN_COMP, compensationId));
        then(compensationRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findAllPage() -----------------------------------------------------------
    @Test
    void testFindAllPageCompensations() {
        // given
        PageRequest pageable = PageRequest.of(0, 10);
        Compensation compensation = new Compensation();
        given(compensationRepository.findAll(pageable)).willReturn(new PageImpl(List.of(compensation), pageable, 1));

        // when
        Page<Compensation> result = compensationService.findAllPage(pageable);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(compensation);
        assertThat(result.getPageable()).isEqualTo(pageable);
        then(compensationRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findAllList() -----------------------------------------------------------
    @Test
    void testFindAllListCompensations() {
        // given
        Compensation compensation = new Compensation();
        given(compensationRepository.findAll()).willReturn(List.of(compensation));

        // when
        List<Compensation> result = compensationService.findAllList();

        // then
        assertThat(result)
                .hasSize(1)
                .contains(compensation);
        then(compensationRepository).shouldHaveNoMoreInteractions();
    }

    // ----------------------------------------------- TESTS POUR create(Compensation compensation) -------------------------------------------------
    @Test
    void testCreateCompensation_with_correct_compensation() {
        // given
        CompensationDTO compensationDTO = new CompensationDTO();
        compensationDTO.setCv(1);
        given(compensationRepository.save(any(Compensation.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Compensation result = compensationService.create(compensationDTO);

        // then
        assertThat(result.getCv()).isEqualTo(compensationDTO.getCv());
        then(compensationRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreateCompensation_with_null_compensation() {
        // when
        TechnicalException result = Assertions.catchThrowableOfType(
                () -> compensationService.create(null),
                TechnicalException.class
        );

        // then
        assertThat(result).hasMessage(CompensationService.NON_NULL_COMP);
        then(compensationRepository).shouldHaveNoMoreInteractions();
    }

    // ----------------------------------------------- TESTS POUR update(Compensation compensation) -------------------------------------------------
    @Test
    void testUpdateCompensation_with_existing_compensation() {
        // given
        long compensationId = 1;
        CompensationDTO compensationDTO = new CompensationDTO();
        compensationDTO.setCv(2);
        Compensation compensation = Compensation.builder().cv(1).id(compensationId).build();
        given(compensationRepository.existsById(compensationId)).willReturn(true);
        given(compensationRepository.save(any(Compensation.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Compensation result = compensationService.update(compensationId, compensationDTO);

        // then
        assertThat(result.getCv()).isEqualTo(compensationDTO.getCv());
        assertThat(result.getId()).isEqualTo(compensationId);
        then(compensationRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateCompensation_with_unknown_compensation() {
        // given
        long compensationId = -1;
        CompensationDTO compensationDTO = new CompensationDTO();
        given(compensationRepository.existsById(compensationId)).willReturn(false);

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> compensationService.update(compensationId, compensationDTO),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(CompensationService.UNKNOWN_COMP, compensationId));
        then(compensationRepository).shouldHaveNoMoreInteractions();
    }

    // ----------------------------------------------- TESTS POUR getCurrentUserMileageAllowance() -------------------------------------------------
    @Test
    void testGetCurrentUserMileageAllowance() {
        // given
        // Contexte de sécurité
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);

        given(securityContext.getAuthentication()).willReturn(authentication);

        // Connexion de l'utilisateur
        long userId = 1L;
        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        user.setId(userId);

        given(authentication.getPrincipal()).willReturn(user);

        given(compensationRepository.getCurrentUserMileageAllowance(userId)).willReturn(BigDecimal.TEN);

        // when
        BigDecimal result = compensationService.getCurrentUserMileageAllowance();

        // then
        assertThat(result).isEqualTo(BigDecimal.TEN);
        then(compensationRepository).shouldHaveNoMoreInteractions();
    }
}
