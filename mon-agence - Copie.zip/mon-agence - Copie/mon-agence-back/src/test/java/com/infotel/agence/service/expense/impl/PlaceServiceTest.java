package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.Distance;
import com.infotel.agence.domain.expense.Place;
import com.infotel.agence.domain.expense.dto.DistanceDTO;
import com.infotel.agence.domain.expense.dto.PlaceDTO;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.PlaceRepository;
import com.infotel.agence.repository.expense.TicketRepository;
import com.infotel.agence.service.expense.IDistanceService;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.AdditionalAnswers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link PlaceService}
 *
 * @author arob
 */
@ExtendWith(MockitoExtension.class)
class PlaceServiceTest {

    @Mock
    private PlaceRepository placeRepository;
    @Mock
    private TicketRepository ticketRepository;
    @Mock
    private IDistanceService distanceService;

    private PlaceService placeService;

    @BeforeEach
    public void setUp() {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        placeService = new PlaceService(placeRepository, ticketRepository, distanceService, mapperFactory.getMapperFacade());
    }

    // -------------------------------------------------------- TESTS POUR findById(long id) --------------------------------------------------------
    @Test
    void testFindPlaceById_with_existing_place() {
        // given
        long placeId = 1;
        Place place = Place.builder().id(placeId).build();
        given(placeRepository.findById(placeId)).willReturn(Optional.of(place));

        // when
        Place result = placeService.findById(placeId);

        // then
        assertThat(result).isEqualTo(place);
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindPlaceById_with_unknown_place() {
        // given
        long placeId = -1;
        given(placeRepository.findById(placeId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> placeService.findById(placeId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(PlaceService.UNKNOWN_PLACE, placeId));
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findAllList() -----------------------------------------------------------
    @Test
    void testFindAllListPlaces() {
        // given
        Place place = new Place();
        given(placeRepository.findAll()).willReturn(List.of(place));

        // when
        List<Place> result = placeService.findAllList();

        // then
        assertThat(result)
                .hasSize(1)
                .contains(place);
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findAllPage() -----------------------------------------------------------
    @Test
    void testFindAllPagePlaces() {
        // given
        PageRequest pageable = PageRequest.of(0, 10);
        Place place = new Place();
        given(placeRepository.findAll(pageable)).willReturn(new PageImpl(List.of(place), pageable, 1));

        // when
        Page<Place> result = placeService.findAllPage(pageable);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(place);
        assertThat(result.getPageable()).isEqualTo(pageable);
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    // ------------------------------------------------------ TESTS POUR create(Place place) --------------------------------------------------------
    @Test
    void testCreatePlace_with_correct_place() {
        // given
        PlaceDTO placeDTO = new PlaceDTO();
        placeDTO.setName("Test");
        given(placeRepository.save(any(Place.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Place result = placeService.create(placeDTO);

        // then
        assertThat(result.getName()).isEqualTo(placeDTO.getName());
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreatePlace_with_null_place() {
        // when
        TechnicalException result = Assertions.catchThrowableOfType(
                () -> placeService.create(null),
                TechnicalException.class
        );

        // then
        assertThat(result).hasMessage(PlaceService.NON_NULL_PLACE);
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    // ------------------------------------------------------ TESTS POUR update(Place place) --------------------------------------------------------
    @Test
    void testUpdatePlace_with_existing_place() {
        // given
        long placeId = 1;
        PlaceDTO placeDTO = new PlaceDTO();
        placeDTO.setName("apres");
        given(placeRepository.existsById(placeId)).willReturn(true);
        given(placeRepository.save(any(Place.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Place result = placeService.update(placeId, placeDTO);

        // then
        assertThat(result.getName()).isEqualTo(placeDTO.getName());
        assertThat(result.getId()).isEqualTo(placeId);
        then(ticketRepository).should().updateValidIfIdPlace(placeId, false);
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdatePlace_with_unknown_place() {
        // given
        long placeId = -1;
        PlaceDTO placeDTO = new PlaceDTO();
        given(placeRepository.existsById(placeId)).willReturn(false);

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> placeService.update(placeId, placeDTO),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(PlaceService.UNKNOWN_PLACE, placeId));
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    // ------------------------------------------------------ TESTS POUR merge(long placeIdDelete, long placeIdRecipient) --------------------------------------------------------
    @Test
    void testMergePlace_with_existing_place_should_merge_without_distance() {
        // given
        long placeIdDelete = 1;
        long placeIdRecipient = 2;

        given(placeRepository.existsById(placeIdDelete)).willReturn(true);
        given(placeRepository.existsById(placeIdRecipient)).willReturn(true);
        given(distanceService.findByPlaceId(placeIdDelete)).willThrow(new UnknownEntityException(""));

        // when
        placeService.merge(placeIdDelete, placeIdRecipient);

        // then
        then(ticketRepository).should().updateValidIfIdPlace(placeIdDelete, false);
        then(ticketRepository).should().updateValidIfIdPlace(placeIdRecipient, false);
        then(placeRepository).should().deleteById(placeIdDelete);
    }

    @Test
    void testMergePlace_without_existing_delete_place_should_throw() {
        // given
        long placeIdDelete = -1;
        long placeIdRecipient = 2;

        given(placeRepository.existsById(placeIdDelete)).willReturn(false);

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> placeService.merge(placeIdDelete, placeIdRecipient),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(PlaceService.UNKNOWN_PLACES, placeIdDelete, placeIdRecipient));
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testMergePlace_without_existing_recipient_place_should_throw() {
        // given
        long placeIdDelete = 1;
        long placeIdRecipient = -1;

        given(placeRepository.existsById(placeIdDelete)).willReturn(true);
        given(placeRepository.existsById(placeIdRecipient)).willReturn(false);

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> placeService.merge(placeIdDelete, placeIdRecipient),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(PlaceService.UNKNOWN_PLACES, placeIdDelete, placeIdRecipient));
        then(placeRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testMergePlace_with_existing_place_should_merge_with_non_concurrent_start_distance() {
        // given
        long placeIdDelete = 1;
        long placeIdRecipient = 2;
        long placeIdBetween = 3;
        long distanceIdToDelete = 1;

        Place placeDelete = new Place();
        placeDelete.setId(placeIdDelete);
        Place placeRecipient = new Place();
        placeRecipient.setId(placeIdRecipient);
        Place placeBetween = new Place();
        placeBetween.setId(placeIdBetween);

        Distance distanceToDelete = new Distance();
        distanceToDelete.setId(distanceIdToDelete);
        distanceToDelete.setPlaceStart(placeDelete);
        distanceToDelete.setPlaceEnd(placeBetween);
        distanceToDelete.setValue(BigDecimal.valueOf(15));

        DistanceDTO newDistanceDTO = new DistanceDTO();
        newDistanceDTO.setPlaceStart(placeRecipient);
        newDistanceDTO.setPlaceEnd(placeBetween);
        newDistanceDTO.setValue(BigDecimal.valueOf(15));

        Distance newDistance = new Distance();
        newDistance.setPlaceStart(placeBetween);
        newDistance.setPlaceEnd(placeRecipient);
        newDistance.setValue(BigDecimal.valueOf(15));

        given(placeRepository.existsById(placeIdDelete)).willReturn(true);
        given(placeRepository.existsById(placeIdRecipient)).willReturn(true);
        given(distanceService.findByPlaceId(placeIdDelete)).willReturn(List.of(distanceToDelete));
        given(distanceService.findByPlacesId(placeIdBetween, placeIdRecipient)).willThrow(new UnknownEntityException(""));
        given(placeRepository.findById(placeIdRecipient)).willReturn(Optional.of(placeRecipient));
        given(distanceService.create(newDistanceDTO)).willReturn(newDistance);

        // when
        placeService.merge(placeIdDelete, placeIdRecipient);

        // then
        then(ticketRepository).should().updateValidIfIdPlace(placeIdDelete, false);
        then(ticketRepository).should().updateValidIfIdPlace(placeIdRecipient, false);
        then(distanceService).should().deleteById(distanceIdToDelete);
        then(placeRepository).should().deleteById(placeIdDelete);
    }

    @Test
    void testMergePlace_with_existing_place_should_merge_with_non_concurrent_end_distance() {
        // given
        long placeIdDelete = 1;
        long placeIdRecipient = 2;
        long placeIdBetween = 3;
        long distanceIdToDelete = 1;

        Place placeDelete = new Place();
        placeDelete.setId(placeIdDelete);
        Place placeRecipient = new Place();
        placeRecipient.setId(placeIdRecipient);
        Place placeBetween = new Place();
        placeBetween.setId(placeIdBetween);

        Distance distanceToDelete = new Distance();
        distanceToDelete.setId(distanceIdToDelete);
        distanceToDelete.setPlaceStart(placeBetween);
        distanceToDelete.setPlaceEnd(placeDelete);
        distanceToDelete.setValue(BigDecimal.valueOf(15));

        DistanceDTO newDistanceDTO = new DistanceDTO();
        newDistanceDTO.setPlaceStart(placeRecipient);
        newDistanceDTO.setPlaceEnd(placeBetween);
        newDistanceDTO.setValue(BigDecimal.valueOf(15));

        Distance newDistance = new Distance();
        newDistance.setPlaceStart(placeBetween);
        newDistance.setPlaceEnd(placeRecipient);
        newDistance.setValue(BigDecimal.valueOf(15));

        given(placeRepository.existsById(placeIdDelete)).willReturn(true);
        given(placeRepository.existsById(placeIdRecipient)).willReturn(true);
        given(distanceService.findByPlaceId(placeIdDelete)).willReturn(List.of(distanceToDelete));
        given(distanceService.findByPlacesId(placeIdBetween, placeIdRecipient)).willThrow(new UnknownEntityException(""));
        given(placeRepository.findById(placeIdRecipient)).willReturn(Optional.of(placeRecipient));
        given(distanceService.create(newDistanceDTO)).willReturn(newDistance);

        // when
        placeService.merge(placeIdDelete, placeIdRecipient);

        // then
        then(ticketRepository).should().updateValidIfIdPlace(placeIdDelete, false);
        then(ticketRepository).should().updateValidIfIdPlace(placeIdRecipient, false);
        then(distanceService).should().deleteById(distanceIdToDelete);
        then(placeRepository).should().deleteById(placeIdDelete);
    }

    @Test
    void testMergePlace_with_existing_place_should_merge_with_concurrent_start_distance() {
        // given
        long placeIdDelete = 1;
        long placeIdRecipient = 2;
        long placeIdBetween = 3;
        long distanceIdToDelete = 1;
        long distanceIdConcurrent = 2;

        Place placeDelete = new Place();
        placeDelete.setId(placeIdDelete);
        Place placeRecipient = new Place();
        placeRecipient.setId(placeIdRecipient);
        Place placeBetween = new Place();
        placeBetween.setId(placeIdBetween);

        Distance distanceToDelete = new Distance();
        distanceToDelete.setId(distanceIdToDelete);
        distanceToDelete.setPlaceStart(placeDelete);
        distanceToDelete.setPlaceEnd(placeBetween);
        distanceToDelete.setValue(BigDecimal.valueOf(15));

        Distance distanceConcurrent = new Distance();
        distanceConcurrent.setId(distanceIdConcurrent);
        distanceConcurrent.setPlaceStart(placeBetween);
        distanceConcurrent.setPlaceEnd(placeRecipient);
        distanceToDelete.setValue(BigDecimal.valueOf(15));

        DistanceDTO newDistanceDTO = new DistanceDTO();
        newDistanceDTO.setPlaceStart(placeRecipient);
        newDistanceDTO.setPlaceEnd(placeBetween);
        newDistanceDTO.setValue(BigDecimal.valueOf(15));

        Distance newDistance = new Distance();
        newDistance.setPlaceStart(placeBetween);
        newDistance.setPlaceEnd(placeRecipient);
        newDistance.setValue(BigDecimal.valueOf(15));

        given(placeRepository.existsById(placeIdDelete)).willReturn(true);
        given(placeRepository.existsById(placeIdRecipient)).willReturn(true);
        given(distanceService.findByPlaceId(placeIdDelete)).willReturn(List.of(distanceToDelete));
        given(distanceService.findByPlacesId(placeIdBetween, placeIdRecipient)).willReturn(distanceConcurrent);

        // when
        placeService.merge(placeIdDelete, placeIdRecipient);

        // then
        then(ticketRepository).should().updateValidIfIdPlace(placeIdDelete, false);
        then(ticketRepository).should().updateValidIfIdPlace(placeIdRecipient, false);
        then(distanceService).should().deleteById(distanceIdToDelete);
        then(placeRepository).should().deleteById(placeIdDelete);
    }

    @Test
    void testMergePlace_with_existing_place_should_merge_with_concurrent_end_distance() {
        // given
        long placeIdDelete = 1;
        long placeIdRecipient = 2;
        long placeIdBetween = 3;
        long distanceIdToDelete = 1;
        long distanceIdConcurrent = 2;

        Place placeDelete = new Place();
        placeDelete.setId(placeIdDelete);
        Place placeRecipient = new Place();
        placeRecipient.setId(placeIdRecipient);
        Place placeBetween = new Place();
        placeBetween.setId(placeIdBetween);

        Distance distanceToDelete = new Distance();
        distanceToDelete.setId(distanceIdToDelete);
        distanceToDelete.setPlaceStart(placeBetween);
        distanceToDelete.setPlaceEnd(placeDelete);
        distanceToDelete.setValue(BigDecimal.valueOf(15));

        Distance distanceConcurrent = new Distance();
        distanceConcurrent.setId(distanceIdConcurrent);
        distanceConcurrent.setPlaceStart(placeBetween);
        distanceConcurrent.setPlaceEnd(placeRecipient);
        distanceToDelete.setValue(BigDecimal.valueOf(15));

        DistanceDTO newDistanceDTO = new DistanceDTO();
        newDistanceDTO.setPlaceStart(placeRecipient);
        newDistanceDTO.setPlaceEnd(placeBetween);
        newDistanceDTO.setValue(BigDecimal.valueOf(15));

        Distance newDistance = new Distance();
        newDistance.setPlaceStart(placeBetween);
        newDistance.setPlaceEnd(placeRecipient);
        newDistance.setValue(BigDecimal.valueOf(15));

        given(placeRepository.existsById(placeIdDelete)).willReturn(true);
        given(placeRepository.existsById(placeIdRecipient)).willReturn(true);
        given(distanceService.findByPlaceId(placeIdDelete)).willReturn(List.of(distanceToDelete));
        given(distanceService.findByPlacesId(placeIdBetween, placeIdRecipient)).willReturn(distanceConcurrent);

        // when
        placeService.merge(placeIdDelete, placeIdRecipient);

        // then
        then(ticketRepository).should().updateValidIfIdPlace(placeIdDelete, false);
        then(ticketRepository).should().updateValidIfIdPlace(placeIdRecipient, false);
        then(distanceService).should().deleteById(distanceIdToDelete);
        then(placeRepository).should().deleteById(placeIdDelete);
    }
}
