package com.infotel.agence.service.order.impl;

import com.infotel.agence.domain.order.Request;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.order.RequestRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.AdditionalAnswers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowableOfType;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link RequestService}
 *
 * @author JUBA
 */
@ExtendWith(MockitoExtension.class)
class RequestServiceTest {

    @Mock
    private RequestRepository requestRepository;

    private RequestService requestService;

    @BeforeEach
    public void setUp() {
        requestService = new RequestService(requestRepository);
    }

    @Test
    void testFindRequestById_with_existing_request() {
        // given
        long requestId = 1;
        Request request = Request.builder().id(requestId).build();
        given(requestRepository.findById(requestId)).willReturn(Optional.of(request));

        // when
        Request result = requestService.findById(requestId);

        // then
        assertThat(result).isEqualTo(request);
    }

    @Test
    void testFindRequestById_with_unknown_request() {
        // given
        long requestId = -1;
        given(requestRepository.findById(requestId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = catchThrowableOfType(
                () -> requestService.findById(requestId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage("Aucune demande n'est référencée par l'id -1");
    }

    @Test
    void testFindAllRequests() {
        // given
        Request request = new Request();
        given(requestRepository.findAll()).willReturn(List.of(request));

        // when
        List<Request> result = requestService.findAll();

        // then
        assertThat(result)
                .hasSize(1)
                .contains(request);
    }

    @Test
    void testCreateRequest() {
        // given
        Request request = new Request();
        given(requestRepository.save(any(Request.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Request result = requestService.create(request);

        // then
        assertThat(result).isEqualTo(request);
    }

    @Test
    void testUpdateRequest_with_existing_request() {
        // given
        long requestId = 1;
        Request request = Request.builder().id(requestId).build();
        given(requestRepository.existsById(requestId)).willReturn(true);
        given(requestRepository.save(any(Request.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Request result = requestService.update(request);

        // then
        assertThat(result).isEqualTo(request);
    }

    @Test
    void testUpdateRequest_with_unknown_request() {
        // given
        long requestId = -1;
        Request request = Request.builder().id(requestId).build();
        given(requestRepository.existsById(requestId)).willReturn(false);

        // when
        UnknownEntityException result = catchThrowableOfType(
                () -> requestService.update(request),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage("Aucune demande n'est référencée par l'id -1");
        then(requestRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteRequestById_with_existing_request() {
        // given
        long requestId = 1;
        given(requestRepository.existsById(requestId)).willReturn(true);

        // when
        requestService.deleteById(requestId);

        // then
        then(requestRepository).should().deleteById(requestId);
    }

    @Test
    void testDeleteRequestById_with_unknown_request() {
        // given
        long requestId = -1;
        given(requestRepository.existsById(requestId)).willReturn(false);

        // when
        UnknownEntityException result = catchThrowableOfType(
                () -> requestService.deleteById(requestId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage("Aucune demande n'est référencée par l'id -1");
        then(requestRepository).shouldHaveNoMoreInteractions();
    }
}
