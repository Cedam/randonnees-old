package com.infotel.agence.security;

import com.infotel.agence.domain.user.Authority;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.TechnicalException;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

import static com.infotel.agence.security.SecurityRole.ADMIN;
import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;
import static com.infotel.agence.security.SecurityRole.Constant.ROLE_SUPPLY;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link SecurityUtils}
 *
 * @author ARLI
 */
@ExtendWith(MockitoExtension.class)
class SecurityUtilsTest {

    @Mock
    private SecurityContext securityContext;

    /**
     * Initialisation du contexte spring au lancement
     */
    @BeforeEach
    public void setUp() {
        SecurityContextHolder.setContext(securityContext);
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void testGetCurrentUser_with_authenticated_user_should_return_this_user() {
        // given
        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        given(securityContext.getAuthentication()).willReturn(new TestingAuthenticationToken(user, null, ROLE_ADMIN));

        // when
        Optional<User> result = SecurityUtils.getCurrentUser();

        // then
        assertThat(result)
                .isNotEmpty()
                .get()
                .isEqualTo(user);
    }

    @Test
    void testGetCurrentUser_with_anonymous_user_should_return_empty_optional() {
        // given
        given(securityContext.getAuthentication()).willReturn(new TestingAuthenticationToken("ANONYMOUS", null));

        // when
        Optional<User> result = SecurityUtils.getCurrentUser();

        // then
        assertThat(result).isEmpty();
    }

    @Test
    void testGetCurrentUser_with_no_user_should_return_empty_optional() {
        // given
        // when
        Optional<User> result = SecurityUtils.getCurrentUser();

        // then
        then(securityContext).should().getAuthentication();

        assertThat(result).isEmpty();
    }

    @Test
    void testHasCurrentUserAnyRole_with_admin_user_should_have_admin_role() {
        // given
        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        given(securityContext.getAuthentication()).willReturn(new TestingAuthenticationToken(user, null, ROLE_ADMIN));

        // when
        boolean result = SecurityUtils.hasCurrentUserAnyRole(ADMIN);

        // then
        assertThat(result).isTrue();
    }

    @Test
    void testHasCurrentUserAnyRole_with_read_user_should_not_have_admin_role() {
        // given
        User user = new User("read", "read", "Read", "User", new Authority(ROLE_SUPPLY));
        given(securityContext.getAuthentication()).willReturn(new TestingAuthenticationToken(user, null, ROLE_SUPPLY));

        // when
        boolean result = SecurityUtils.hasCurrentUserAnyRole(ADMIN);

        // then
        assertThat(result).isFalse();
    }

    @Test
    void testHasCurrentUserAnyRole_with_no_user_should_return_false() {
        // given
        // when
        boolean result = SecurityUtils.hasCurrentUserAnyRole(ADMIN);

        // then
        then(securityContext).should().getAuthentication();

        assertThat(result).isFalse();
    }

    @Test
    void testGetCurrentUserId_should_return_id() {
        // given
        Long userId = 1L;

        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        user.setId(userId);

        given(securityContext.getAuthentication()).willReturn(new TestingAuthenticationToken(user, null, ROLE_ADMIN));

        // when
        Long resId = SecurityUtils.getCurrentUserId();

        // then
        assertThat(resId).isNotNull()
                .isEqualTo(userId);
    }

    @Test
    void testGetCurrentUserId_should_throw() {
        // given
        // when
        TechnicalException result = Assertions.catchThrowableOfType(
                SecurityUtils::getCurrentUserId,
                TechnicalException.class
        );

        // then
        assertThat(result).isNotNull()
                .hasMessage("Aucun utilisateur connecté");
    }
}
