package com.infotel.agence.security;

public class TokenProviderTest {
    // TODO add tests
}