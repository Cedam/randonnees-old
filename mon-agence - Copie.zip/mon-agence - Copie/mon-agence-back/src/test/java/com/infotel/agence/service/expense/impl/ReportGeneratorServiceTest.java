package com.infotel.agence.service.expense.impl;

import com.infotel.agence.config.property.ExpenseProperties;
import com.infotel.agence.domain.expense.*;
import com.infotel.agence.domain.expense.export.line.ExceptionalBusinessTravelLine;
import com.infotel.agence.domain.expense.ticket.*;
import com.infotel.agence.domain.user.Authority;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.repository.expense.TicketRepository;
import com.infotel.agence.service.expense.*;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link ReportGeneratorService}
 *
 * @author arob
 */
@ExtendWith(MockitoExtension.class)
class ReportGeneratorServiceTest {
    // Cette variable est nécessaire afin d'initialiser l'user dans le setUp() et de pouvoir dans les tests initialiser
    // l'employeeIdentity de cet user.
    private static final long userId = 1;

    private IReportGeneratorService reportGeneratorService;

    @Mock
    private IEmployeeIdentityService employeeIdentityService;

    @Mock
    private ITicketService ticketService;

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private IDistanceService distanceService;

    @Mock
    private IGeneratedReportService generatedReportService;

    @Mock
    private ExpenseProperties expenseProperties;

    @Mock
    private Authentication authentication;

    public void setUpService() {
        // Services à tester
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(ExceptionalBusinessTravelTicket.class, ExceptionalBusinessTravelLine.class)
                .field("startPlace.name", "startPlace")
                .field("endPlace.name", "endPlace")
                .byDefault()
                .register();

        reportGeneratorService = new ReportGeneratorService(employeeIdentityService,
                ticketService,
                ticketRepository,
                distanceService,
                generatedReportService,
                mapperFactory.getMapperFacade(),
                expenseProperties
        );
    }

    public void setUpAuthentication() {
        setUpService();

        // Contexte de sécurité
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);

        given(securityContext.getAuthentication()).willReturn(authentication);

        // Connexion de l'utilisateur
        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        user.setId(userId);

        given(authentication.getPrincipal()).willReturn(user);
    }

    // ----------------------------------------------------------- TESTS POUR getFilename(int month) -----------------------------------------------------------
    @Test
    void getFilename() {
        setUpService();

        // given
        String serialNumber = "8495";
        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().serialNumber(serialNumber).build();
        given(employeeIdentityService.findCurrent()).willReturn(employeeIdentity);

        // when
        String result = reportGeneratorService.getFilename(1);

        // then
        assertNotNull(result);
        assertThat(result).isEqualTo("8495_noteFrais_janvier");
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // ----------------------------------------------------------- TESTS POUR getLimits() -----------------------------------------------------------
    @Test
    void testGetLimits_with_tickets() {
        setUpAuthentication();

        // given
        LocalDate olderDate = LocalDate.of(2020, 6, 30);
        LocalDate youngerDate = LocalDate.of(2020, 7, 24);

        given(ticketRepository.findOlderDateToGenerate(userId)).willReturn(olderDate);
        given(ticketRepository.findYoungerDateToGenerate(userId)).willReturn(youngerDate);

        // when
        Map<String, LocalDate> result = reportGeneratorService.getLimits();

        // then
        assertNotNull(result);
        assertThat(result.keySet()).contains("olderDate");
        assertThat(result.keySet()).contains("youngerDate");
        assertThat(result).containsEntry("olderDate", olderDate)
                .containsEntry("youngerDate", youngerDate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testGetLimits_without_tickets() {
        setUpAuthentication();

        // given
        given(ticketRepository.findOlderDateToGenerate(userId)).willReturn(null);
        given(ticketRepository.findYoungerDateToGenerate(userId)).willReturn(null);

        // when
        Map<String, LocalDate> result = reportGeneratorService.getLimits();

        // then
        assertNotNull(result);
        assertThat(result.keySet()).contains("olderDate");
        assertThat(result.keySet()).contains("youngerDate");
        assertThat(result).containsEntry("olderDate", LocalDate.now())
                .containsEntry("youngerDate", LocalDate.now());
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // ----------------------------------------------------------- TESTS POUR export() -----------------------------------------------------------
    @Test
    void testExport_with_dates() {
        setUpAuthentication();

        //given
        LocalDate startDate = LocalDate.of(2020, 6, 30);
        LocalDate endDate = LocalDate.of(2020, 7, 24);
        int month = 1;
        String filename = "9452_noteFrais_janvier";

        // Utile pour la partie writeIdentities
        Compensation compensation = Compensation.builder().build();
        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder()
                .id(1L)
                .compensation(compensation)
                .serialNumber("9452")
                .build();
        given(employeeIdentityService.findCurrent()).willReturn(employeeIdentity);

        // Utile pour la partie writeTickets
        Place placeStart = Place.builder().id(1L).build();
        Place placeEnd = Place.builder().id(2L).build();
        Map<TicketCode, List<Ticket>> data = Map.of(
                TicketCode.CUSTOMER_MEAL_COST, List.of(new CustomerMealCostTicket()),
                TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL, List.of(
                        ExceptionalBusinessTravelTicket
                                .builder()
                                .startPlace(placeStart)
                                .endPlace(placeEnd)
                                .build()),
                TicketCode.FUEL, List.of(new FuelTicket()),
                TicketCode.LODGING_MEAL_BUSINESS, List.of(new LodgingMealBusinessTicket()),
                TicketCode.SITE_MEAL_COST, List.of(new SiteMealCostTicket()),
                TicketCode.VARIOUS_BUSINESS_TRAVEL, List.of(new VariousBusinessTravelTicket()),
                TicketCode.VARIOUS_COST, List.of(new VariousCostTicket())
        );
        given(distanceService.findByPlacesId(placeStart.getId(), placeEnd.getId()))
                .willReturn(Distance.builder().value(BigDecimal.TEN).build());
        given(ticketService.findAllToGenerate(startDate, endDate)).willReturn(data);

        // Utile pour la partie d'enregistrement des fichiers générés comme archives
        GeneratedReport generatedReport = new GeneratedReport();
        generatedReport.setZipFile(new byte[0]);
        given(generatedReportService.create(any(GeneratedReport.class))).willReturn(generatedReport);

        given(expenseProperties.getExcelTemplatePath()).willReturn("template/expense/noteFrais.xlsx");
        given(expenseProperties.getPdfSeparatorFolderPath()).willReturn("img/expense/");

        // when
        reportGeneratorService.export(startDate, endDate, filename, month, OutputStream.nullOutputStream());

        // then
        then(ticketService).should().archiveTicketBetween(startDate, endDate);
        then(employeeIdentityService).shouldHaveNoMoreInteractions();
    }

    @Test
    void testExport_without_start_dates() {
        setUpService();

        //given
        LocalDate endDate = LocalDate.of(2020, 7, 24);
        int month = 1;
        String filename = "9452_noteFrais_janvier";

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> reportGeneratorService.export(null, endDate, filename, month, null),
                BusinessException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(ReportGeneratorService.NOT_NULL_DATES);
        then(ticketService).shouldHaveNoMoreInteractions();
    }

    @Test
    void testExport_without_end_dates() {
        setUpService();

        //given
        LocalDate startDate = LocalDate.of(2020, 6, 30);
        int month = 1;
        String filename = "9452_noteFrais_janvier";

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> reportGeneratorService.export(startDate, null, filename, month, null),
                BusinessException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(ReportGeneratorService.NOT_NULL_DATES);
        then(ticketService).shouldHaveNoMoreInteractions();
    }
}
