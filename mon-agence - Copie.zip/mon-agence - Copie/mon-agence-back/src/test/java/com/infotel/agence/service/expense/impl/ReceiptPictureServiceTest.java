package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.domain.expense.ReceiptPicture;
import com.infotel.agence.domain.expense.ticket.Ticket;
import com.infotel.agence.domain.user.Authority;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.ReceiptPictureRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.AdditionalAnswers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.text.MessageFormat;
import java.util.Optional;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link ReceiptPictureService}
 *
 * @author arob
 */
@ExtendWith(MockitoExtension.class)
class ReceiptPictureServiceTest {

    @Mock
    private ReceiptPictureRepository receiptPictureRepository;

    private ReceiptPictureService receiptPictureService;

    @Mock
    private Authentication authentication;

    private long userId;

    public void setUpService() {
        receiptPictureService = new ReceiptPictureService(receiptPictureRepository);
    }

    private void setUpAuthentication() {
        setUpService();

        // Contexte de sécurité
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);

        given(securityContext.getAuthentication()).willReturn(authentication);

        // Connexion de l'utilisateur
        userId = 1L;
        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        user.setId(userId);

        given(authentication.getPrincipal()).willReturn(user);
    }

    // -------------------------------------------------------- TESTS POUR findByTicketId(long idTicket) --------------------------------------------------------
    @Test
    void testFindByTicketId_with_existing_ticket() {
        setUpService();

        // given
        long ticketId = 1;
        long receiptPictureId = 1;
        ReceiptPicture receiptPicture = ReceiptPicture.builder().id(receiptPictureId).build();
        given(receiptPictureRepository.findByTicketId(ticketId)).willReturn(Optional.of(receiptPicture));

        // when
        ReceiptPicture result = receiptPictureService.findByTicketId(ticketId);

        // then
        assertThat(result).isEqualTo(receiptPicture);
        then(receiptPictureRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindByTicketId_with_unknown_ticket() {
        setUpService();

        // given
        long ticketId = -1;
        given(receiptPictureRepository.findByTicketId(ticketId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> receiptPictureService.findByTicketId(ticketId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(ReceiptPictureService.UNKNOWN_RPIC, ticketId));
        then(receiptPictureRepository).shouldHaveNoMoreInteractions();
    }

    // ------------------------------------------------------ TESTS POUR create(ReceiptPicture receiptPicture) --------------------------------------------------------
    @Test
    void testCreate_with_correct_receiptPicture() {
        setUpService();

        // given
        ReceiptPicture receiptPicture = ReceiptPicture.builder().name("Test").build();
        given(receiptPictureRepository.save(any(ReceiptPicture.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        ReceiptPicture result = receiptPictureService.create(receiptPicture);

        // then
        assertThat(result.getName()).isEqualTo(receiptPicture.getName());
        then(receiptPictureRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreate_with_null_receiptPicture() {
        setUpService();

        // when
        TechnicalException result = Assertions.catchThrowableOfType(
                () -> receiptPictureService.create(null),
                TechnicalException.class
        );

        // then
        assertThat(result).hasMessage(ReceiptPictureService.NON_NULL_RPIC);
        then(receiptPictureRepository).shouldHaveNoMoreInteractions();
    }

    // ------------------------------------------------------ TESTS POUR deleteByTicketId(long idTicket) --------------------------------------------------------
    @Test
    void testDeleteByTicketId_with_existing_ticket() {
        setUpAuthentication();

        // given
        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();

        long ticketId = 1;
        Ticket ticket = Ticket.builder().id(ticketId).employeeIdentity(employeeIdentity).build();

        long receiptPictureId = 1;
        ReceiptPicture receiptPicture = ReceiptPicture.builder().id(receiptPictureId).ticket(ticket).build();

        given(receiptPictureRepository.findByTicketId(ticketId)).willReturn(Optional.of(receiptPicture));

        // when
        receiptPictureService.deleteByTicketId(ticketId);

        // then
        then(receiptPictureRepository).should().deleteByTicketId(ticketId);
        then(receiptPictureRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteByTicketId_without_existing_ticket() {
        setUpAuthentication();

        // given
        long ticketId = 1;

        given(receiptPictureRepository.findByTicketId(ticketId)).willReturn(Optional.empty());

        // when
        receiptPictureService.deleteByTicketId(ticketId);

        // then
        then(receiptPictureRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteByTicketId_with_wrong_user() {
        setUpAuthentication();

        // given
        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId + 1).build();

        long ticketId = 1;
        Ticket ticket = Ticket.builder().id(ticketId).employeeIdentity(employeeIdentity).build();

        long receiptPictureId = 1;
        ReceiptPicture receiptPicture = ReceiptPicture.builder().id(receiptPictureId).ticket(ticket).build();

        given(receiptPictureRepository.findByTicketId(ticketId)).willReturn(Optional.of(receiptPicture));

        // when
        receiptPictureService.deleteByTicketId(ticketId);

        // then
        then(receiptPictureRepository).shouldHaveNoMoreInteractions();
    }
}
