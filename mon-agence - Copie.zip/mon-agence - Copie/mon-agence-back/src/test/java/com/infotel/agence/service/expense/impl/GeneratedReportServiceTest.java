package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.domain.expense.GeneratedReport;
import com.infotel.agence.domain.expense.dto.GeneratedReportDTO;
import com.infotel.agence.domain.user.Authority;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.repository.expense.GeneratedReportRepository;
import com.infotel.agence.service.expense.IEmployeeIdentityService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.IOException;
import java.io.OutputStream;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.List;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link GeneratedReportService}
 *
 * @author arob
 */
@ExtendWith(MockitoExtension.class)
class GeneratedReportServiceTest {

    @Mock
    private GeneratedReportRepository generatedReportRepository;

    @Mock
    private IEmployeeIdentityService employeeIdentityService;

    @Mock
    private Authentication authentication;

    private GeneratedReportService generatedReportService;

    private OutputStream nullOutputStream;

    private long userId;

    void setUpService() {
        generatedReportService = new GeneratedReportService(generatedReportRepository, employeeIdentityService);
        nullOutputStream = OutputStream.nullOutputStream();
    }

    private void setUpAuthentication() {
        setUpService();

        // Contexte de sécurité
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);

        given(securityContext.getAuthentication()).willReturn(authentication);

        // Connexion de l'utilisateur
        userId = 1L;
        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        user.setId(userId);

        given(authentication.getPrincipal()).willReturn(user);
    }

    // -------------------------------------------------------- TESTS POUR create(GeneratedReport generatedReport) --------------------------------------------------------
    @Test
    void create_with_not_null_generated_report() {
        setUpService();

        // given
        GeneratedReport generatedReport = new GeneratedReport();
        given(generatedReportRepository.save(generatedReport)).willReturn(generatedReport);

        // when
        GeneratedReport result = generatedReportService.create(generatedReport);

        // then
        assertThat(result).isEqualTo(generatedReport);
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void create_with_null_generated_report() {
        setUpService();

        // given

        // when
        TechnicalException result = Assertions.catchThrowableOfType(
                () -> generatedReportService.create(null),
                TechnicalException.class
        );

        // then
        assertThat(result).hasMessage(GeneratedReportService.NON_NULL_REPORT);
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findAllList() -----------------------------------------------------------
    @Test
    void testFindAllListGeneratedReports() {
        setUpAuthentication();

        // given
        GeneratedReportDTO generatedReportDTO = new GeneratedReportDTO();
        given(generatedReportRepository.findAllGeneratedReportDTO(userId)).willReturn(List.of(generatedReportDTO));

        // when
        List<GeneratedReportDTO> result = generatedReportService.findAllList();

        // then
        assertThat(result)
                .hasSize(1)
                .contains(generatedReportDTO);
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findPdfFileOfId() -----------------------------------------------------------
    @Test
    void testFindPdfFileOfId_with_existing_id_for_current_user() throws IOException {
        setUpAuthentication();

        // given
        long reportId = 1;
        given(generatedReportRepository.existsByIdForUserId(reportId, userId)).willReturn(1L);
        given(generatedReportRepository.findPdfFileOfId(reportId)).willReturn(new byte[0]);

        // when
        generatedReportService.findPdfFileOfId(reportId, nullOutputStream);

        // then
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindPdfFileOfId_without_existing_id_for_current_user() {
        setUpAuthentication();

        // given
        long reportId = -1L;
        given(generatedReportRepository.existsByIdForUserId(reportId, userId)).willReturn(0L);

        // when
        TechnicalException result = Assertions.catchThrowableOfType(
                () -> generatedReportService.findPdfFileOfId(reportId, nullOutputStream),
                TechnicalException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(GeneratedReportService.UNKNOWN_REPORT, reportId));
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findXlsxFileOfId() -----------------------------------------------------------
    @Test
    void testFindXlsxFileOfId_with_existing_id_for_current_user() throws IOException {
        setUpAuthentication();

        // given
        long reportId = 1;
        given(generatedReportRepository.existsByIdForUserId(reportId, userId)).willReturn(1L);
        given(generatedReportRepository.findXlsxFileOfId(reportId)).willReturn(new byte[0]);

        // when
        generatedReportService.findXlsxFileOfId(reportId, nullOutputStream);

        // then
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindXlsxFileOfId_without_existing_id_for_current_user() {
        setUpAuthentication();

        // given
        long reportId = -1L;
        given(generatedReportRepository.existsByIdForUserId(reportId, userId)).willReturn(0L);


        // when
        TechnicalException result = Assertions.catchThrowableOfType(
                () -> generatedReportService.findXlsxFileOfId(reportId, nullOutputStream),
                TechnicalException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(GeneratedReportService.UNKNOWN_REPORT, reportId));
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR findZipFileOfId() -----------------------------------------------------------
    @Test
    void testFindZipFileOfId_with_existing_id_for_current_user() throws IOException {
        setUpAuthentication();

        // given
        long reportId = 1;
        given(generatedReportRepository.existsByIdForUserId(reportId, userId)).willReturn(1L);
        given(generatedReportRepository.findZipFileOfId(reportId)).willReturn(new byte[0]);

        // when
        generatedReportService.findZipFileOfId(reportId, nullOutputStream);

        // then
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindZipFileOfId_without_existing_id_for_current_user() {
        setUpAuthentication();

        // given
        long reportId = -1L;
        given(generatedReportRepository.existsByIdForUserId(reportId, userId)).willReturn(0L);

        // when
        TechnicalException result = Assertions.catchThrowableOfType(
                () -> generatedReportService.findZipFileOfId(reportId, nullOutputStream),
                TechnicalException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(GeneratedReportService.UNKNOWN_REPORT, reportId));
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- TESTS POUR getFilename(long id) -----------------------------------------------------------
    @Test
    void testGetFilename_should_return_filename() {
        setUpService();

        // given
        long reportId = 1L;

        EmployeeIdentity employeeIdentity = new EmployeeIdentity();
        employeeIdentity.setSerialNumber("1234");
        given(employeeIdentityService.findCurrent()).willReturn(employeeIdentity);

        GeneratedReport generatedReport = new GeneratedReport();
        generatedReport.setMonth(1);
        given(generatedReportRepository.findOneById(reportId)).willReturn(generatedReport);

        // when
        String result = generatedReportService.getFilename(reportId);

        // then
        assertThat(result).isEqualTo("1234_noteFrais_janvier");
        then(employeeIdentityService).shouldHaveNoMoreInteractions();
        then(generatedReportRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------------- deleteGeneratedReportsOlderThan(LocalDate date) -----------------------------------------------------------
    @Test
    void deleteGeneratedReportsOlderThan_with_not_null_date() {
        setUpService();

        // given
        LocalDate localDate = LocalDate.now();

        // when
        generatedReportService.deleteGeneratedReportsOlderThan(localDate);

        // then
        then(generatedReportRepository).should().deleteGeneratedReportsOlderThan(localDate);
    }

    @Test
    void deleteGeneratedReportsOlderThan_with_null_date() {
        setUpService();

        // given

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> generatedReportService.deleteGeneratedReportsOlderThan(null),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(GeneratedReportService.NULL_DATE_DELETE_OLDER);
        then(generatedReportRepository).shouldHaveNoMoreInteractions();

    }
}
