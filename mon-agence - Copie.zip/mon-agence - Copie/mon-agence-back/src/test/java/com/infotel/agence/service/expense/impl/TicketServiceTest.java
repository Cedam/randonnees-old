package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.domain.expense.dto.TicketDTO;
import com.infotel.agence.domain.expense.dto.TicketStatisticsDTO;
import com.infotel.agence.domain.expense.ticket.*;
import com.infotel.agence.domain.user.Authority;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.TechnicalException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.TicketRepository;
import com.infotel.agence.repository.user.UserRepository;
import com.infotel.agence.service.expense.ICompensationService;
import com.infotel.agence.service.expense.IReceiptPictureService;
import com.querydsl.core.types.dsl.BooleanExpression;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link TicketService}
 *
 * @author arob
 */
@ExtendWith(MockitoExtension.class)
class TicketServiceTest {
    // Cette variable est nécessaire afin d'initialiser l'user dans le setUp() et de pouvoir dans les tests initialiser
    // l'employeeIdentity de cet user.
    private static final long userId = 1;

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private ICompensationService compensationService;

    @Mock
    private IReceiptPictureService receiptPictureService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private Authentication authentication;

    private TicketService ticketService;

    private void setUpService() {
        // Service à tester
        ticketService = new TicketService(ticketRepository,
                compensationService,
                receiptPictureService,
                userRepository);
    }

    private void setUpAuthentication() {
        setUpService();

        // Contexte de sécurité
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);

        given(securityContext.getAuthentication()).willReturn(authentication);

        // Connexion de l'utilisateur
        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        user.setId(userId);

        given(authentication.getPrincipal()).willReturn(user);
    }

    // -------------------------------------------------------- TESTS POUR findById(long id) --------------------------------------------------------
    @Test
    void testFindTicketById_with_existing_ticket_and_good_user() {
        setUpAuthentication();

        // given
        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();

        long ticketId = 1;

        Ticket ticket = Ticket.builder().id(ticketId).employeeIdentity(employeeIdentity).build();

        given(ticketRepository.findById(ticketId)).willReturn(Optional.of(ticket));

        // when
        Ticket result = ticketService.findById(ticketId);

        // then
        assertNotNull(result);
        assertThat(result).isEqualTo(ticket);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindTicketById_with_unknown_ticket_and_good_user() {
        setUpAuthentication();

        // given
        long ticketId = -1;

        given(ticketRepository.findById(ticketId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> ticketService.findById(ticketId),
                UnknownEntityException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(MessageFormat.format(TicketService.UNKNOWN_TICKET, ticketId));
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindTicketById_with_existing_ticket_and_bad_user() {
        setUpAuthentication();

        // given
        long ticketId = 1;

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId + 1).build();
        Ticket ticket = Ticket.builder().id(ticketId).employeeIdentity(employeeIdentity).build();

        given(ticketRepository.findById(ticketId)).willReturn(Optional.of(ticket));

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> ticketService.findById(ticketId),
                UnknownEntityException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(MessageFormat.format(TicketService.UNKNOWN_TICKET, ticketId));
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // ---------- TESTS POUR findAll(Pageable pageable, TicketCode ticketCode, LocalDate startDate, LocalDate endDate, Boolean isArchived) ----------
    @Test
    void testFindAll_with_all_predicates_and_isArchived_true() {
        setUpAuthentication();

        // given
        long ticketId = 1;
        TicketCode ticketCode = TicketCode.CUSTOMER_MEAL_COST;
        LocalDate startDate = LocalDate.of(2020, 6, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 1);
        PageRequest pageable = PageRequest.of(0, 10);

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        Ticket ticket = Ticket.builder().id(ticketId).code(ticketCode).employeeIdentity(employeeIdentity).build();

        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId);
        predicate = predicate.and(QTicket.ticket.code.eq(ticketCode));
        predicate = predicate.and(QTicket.ticket.date.between(startDate, endDate));

        ArgumentCaptor<BooleanExpression> argument = ArgumentCaptor.forClass(BooleanExpression.class);

        given(ticketRepository.findAll(argument.capture(), eq(pageable))).willReturn(new PageImpl<>(List.of(ticket), pageable, 1));

        // when
        Page<Ticket> result = ticketService.findAll(pageable, ticketCode, startDate, endDate, true);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(ticket);
        assertThat(result.getPageable()).isEqualTo(pageable);
        assertThat(argument.getValue()).isEqualTo(predicate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindAll_with_all_predicates_and_isArchived_false() {
        setUpAuthentication();

        // given
        long ticketId = 1;
        TicketCode ticketCode = TicketCode.CUSTOMER_MEAL_COST;
        LocalDate startDate = LocalDate.of(2020, 6, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 1);
        PageRequest pageable = PageRequest.of(0, 10);

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        Ticket ticket = Ticket.builder().id(ticketId).code(ticketCode).employeeIdentity(employeeIdentity).build();

        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId);
        predicate = predicate.and(QTicket.ticket.code.eq(ticketCode));
        predicate = predicate.and(QTicket.ticket.date.between(startDate, endDate));
        predicate = predicate.and(QTicket.ticket.archived.isNull());

        ArgumentCaptor<BooleanExpression> argument = ArgumentCaptor.forClass(BooleanExpression.class);

        given(ticketRepository.findAll(argument.capture(), eq(pageable))).willReturn(new PageImpl<>(List.of(ticket), pageable, 1));

        // when
        Page<Ticket> result = ticketService.findAll(pageable, ticketCode, startDate, endDate, false);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(ticket);
        assertThat(result.getPageable()).isEqualTo(pageable);
        assertThat(argument.getValue()).isEqualTo(predicate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindAll_without_ticketCode() {
        setUpAuthentication();

        // given
        long ticketId = 1;
        TicketCode ticketCode = TicketCode.CUSTOMER_MEAL_COST;
        LocalDate startDate = LocalDate.of(2020, 6, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 1);
        PageRequest pageable = PageRequest.of(0, 10);

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        Ticket ticket = Ticket.builder().id(ticketId).code(ticketCode).employeeIdentity(employeeIdentity).build();

        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId);
        predicate = predicate.and(QTicket.ticket.date.between(startDate, endDate));
        predicate = predicate.and(QTicket.ticket.archived.isNull());

        ArgumentCaptor<BooleanExpression> argument = ArgumentCaptor.forClass(BooleanExpression.class);

        given(ticketRepository.findAll(argument.capture(), eq(pageable))).willReturn(new PageImpl<>(List.of(ticket), pageable, 1));

        // when
        Page<Ticket> result = ticketService.findAll(pageable, null, startDate, endDate, false);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(ticket);
        assertThat(result.getPageable()).isEqualTo(pageable);
        assertThat(argument.getValue()).isEqualTo(predicate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindAll_without_dates() {
        setUpAuthentication();

        // given
        long ticketId = 1;
        TicketCode ticketCode = TicketCode.CUSTOMER_MEAL_COST;
        PageRequest pageable = PageRequest.of(0, 10);

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        Ticket ticket = Ticket.builder().id(ticketId).code(ticketCode).employeeIdentity(employeeIdentity).build();

        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId);
        predicate = predicate.and(QTicket.ticket.code.eq(ticketCode));
        predicate = predicate.and(QTicket.ticket.archived.isNull());

        ArgumentCaptor<BooleanExpression> argument = ArgumentCaptor.forClass(BooleanExpression.class);

        given(ticketRepository.findAll(argument.capture(), eq(pageable))).willReturn(new PageImpl<>(List.of(ticket), pageable, 1));

        // when
        Page<Ticket> result = ticketService.findAll(pageable, ticketCode, null, null, false);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(ticket);
        assertThat(result.getPageable()).isEqualTo(pageable);
        assertThat(argument.getValue()).isEqualTo(predicate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindAll_without_start_date() {
        setUpAuthentication();

        // given
        long ticketId = 1;
        TicketCode ticketCode = TicketCode.CUSTOMER_MEAL_COST;
        LocalDate endDate = LocalDate.of(2020, 7, 1);
        PageRequest pageable = PageRequest.of(0, 10);

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        Ticket ticket = Ticket.builder().id(ticketId).code(ticketCode).employeeIdentity(employeeIdentity).build();

        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId);
        predicate = predicate.and(QTicket.ticket.code.eq(ticketCode));
        predicate = predicate.and(QTicket.ticket.archived.isNull());

        ArgumentCaptor<BooleanExpression> argument = ArgumentCaptor.forClass(BooleanExpression.class);

        given(ticketRepository.findAll(argument.capture(), eq(pageable))).willReturn(new PageImpl<>(List.of(ticket), pageable, 1));

        // when
        Page<Ticket> result = ticketService.findAll(pageable, ticketCode, null, endDate, false);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(ticket);
        assertThat(result.getPageable()).isEqualTo(pageable);
        assertThat(argument.getValue()).isEqualTo(predicate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindAll_without_end_date() {
        setUpAuthentication();

        // given
        long ticketId = 1;
        TicketCode ticketCode = TicketCode.CUSTOMER_MEAL_COST;
        LocalDate startDate = LocalDate.of(2020, 6, 1);
        PageRequest pageable = PageRequest.of(0, 10);

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        Ticket ticket = Ticket.builder().id(ticketId).code(ticketCode).employeeIdentity(employeeIdentity).build();

        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId);
        predicate = predicate.and(QTicket.ticket.code.eq(ticketCode));
        predicate = predicate.and(QTicket.ticket.archived.isNull());

        ArgumentCaptor<BooleanExpression> argument = ArgumentCaptor.forClass(BooleanExpression.class);

        given(ticketRepository.findAll(argument.capture(), eq(pageable))).willReturn(new PageImpl<>(List.of(ticket), pageable, 1));

        // when
        Page<Ticket> result = ticketService.findAll(pageable, ticketCode, startDate, null, false);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(ticket);
        assertThat(result.getPageable()).isEqualTo(pageable);
        assertThat(argument.getValue()).isEqualTo(predicate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindAll_without_isArchived() {
        setUpAuthentication();

        // given
        long ticketId = 1;
        TicketCode ticketCode = TicketCode.CUSTOMER_MEAL_COST;
        LocalDate startDate = LocalDate.of(2020, 6, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 1);
        PageRequest pageable = PageRequest.of(0, 10);

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        Ticket ticket = Ticket.builder().id(ticketId).code(ticketCode).employeeIdentity(employeeIdentity).build();

        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId);
        predicate = predicate.and(QTicket.ticket.code.eq(ticketCode));
        predicate = predicate.and(QTicket.ticket.date.between(startDate, endDate));

        ArgumentCaptor<BooleanExpression> argument = ArgumentCaptor.forClass(BooleanExpression.class);

        given(ticketRepository.findAll(argument.capture(), eq(pageable))).willReturn(new PageImpl<>(List.of(ticket), pageable, 1));

        // when
        Page<Ticket> result = ticketService.findAll(pageable, ticketCode, startDate, endDate, null);

        // then
        assertNotNull(result);
        assertThat(result.hasContent()).isTrue();
        assertThat(result.getContent().size()).isEqualTo(1);
        assertThat(result.getContent()).contains(ticket);
        assertThat(result.getPageable()).isEqualTo(pageable);
        assertThat(argument.getValue()).isEqualTo(predicate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // -------------------------------------------------------- TESTS POUR findAllToVerify() --------------------------------------------------------
    @Test
    void testFindAllToVerify() {
        setUpAuthentication();

        // given
        long ticketId = 1;
        Boolean isValid = false;

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        Ticket ticket = Ticket.builder().id(ticketId).employeeIdentity(employeeIdentity).build();

        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId);
        predicate = predicate.and(QTicket.ticket.valid.eq(isValid));

        Sort sort = Sort.by(Sort.Order.asc("code"), Sort.Order.asc("date"));

        ArgumentCaptor<BooleanExpression> argument = ArgumentCaptor.forClass(BooleanExpression.class);

        given(ticketRepository.findAll(argument.capture(), eq(sort))).willReturn(List.of(ticket));

        // when
        List<Ticket> result = ticketService.findAllToVerify();

        // then
        assertNotNull(result);
        assertThat(result.size()).isEqualTo(1);
        assertThat(result).contains(ticket);
        assertThat(argument.getValue()).isEqualTo(predicate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // -------------------------------------------------------- TESTS POUR findAllToGenerate(LocalDate startDate, LocalDate endDate) --------------------------------------------------------
    @Test
    void testFindAllToGenerate() {
        setUpAuthentication();

        // given
        LocalDate startDate = LocalDate.of(2020, 7, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 30);

        BooleanExpression predicate = QTicket.ticket.employeeIdentity.id.eq(userId)
                .and(QTicket.ticket.valid.eq(true))
                .and(QTicket.ticket.archived.isNull())
                .and(QTicket.ticket.date.between(startDate, endDate));

        Map<TicketCode, List<Ticket>> expectedResults = new HashMap<>();

        long cptTicketId = 0;
        for (TicketCode ticketCode : TicketCode.values()) {
            // Création de la liste de ticket pour le TicketCode actuel
            List<Ticket> codeResult = List.of(Ticket.builder().id(++cptTicketId).build());

            // On ajoute cette liste dans les resultats attendus afin de tester plus tard la sortie
            expectedResults.put(ticketCode, codeResult);

            // On mock la fonction findAll pour le TicketCode actuel
            given(ticketRepository.findAll(predicate.and(QTicket.ticket.code.eq(ticketCode)))).willReturn(codeResult);
        }

        // when
        Map<TicketCode, List<Ticket>> result = ticketService.findAllToGenerate(startDate, endDate);

        // then
        assertNotNull(result);
        assertThat(result.keySet()).contains(TicketCode.values());
        for (TicketCode ticketCode : TicketCode.values()) {
            assertThat(result.get(ticketCode)).containsAll(expectedResults.get(ticketCode));
        }
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // ------------------------------------------------------- TESTS POUR deleteById(long id) -------------------------------------------------------
    @Test
    void testDeleteTicketById_with_existing_ticket_and_good_user() {
        setUpAuthentication();

        // given
        long ticketId = 1;

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        Ticket ticket = Ticket.builder().id(ticketId).employeeIdentity(employeeIdentity).build();

        given(ticketRepository.findById(ticketId)).willReturn(Optional.of(ticket));

        // when
        ticketService.deleteById(ticketId);

        // then
        then(ticketRepository).should().deleteById(ticketId);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteTicketById_with_existing_ticket_and_bad_user() {
        setUpAuthentication();

        // given
        long ticketId = 1;

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId + 1).build();
        Ticket ticket = Ticket.builder().id(ticketId).employeeIdentity(employeeIdentity).build();

        given(ticketRepository.findById(ticketId)).willReturn(Optional.of(ticket));

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> ticketService.deleteById(ticketId),
                UnknownEntityException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(MessageFormat.format(TicketService.UNKNOWN_TICKET, ticketId));
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteTicketById_with_unknow_ticket_and_connected_user() {
        setUpAuthentication();

        // given
        long ticketId = -1;

        given(ticketRepository.findById(ticketId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> ticketService.deleteById(ticketId),
                UnknownEntityException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(MessageFormat.format(TicketService.UNKNOWN_TICKET, ticketId));
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // ------------------------------------------------------- TESTS POUR deleteAllOfUser(long userId) -------------------------------------------------------
    @Test
    void testDeleteAllOfUser_with_existing_id() {
        setUpService();

        // given
        long userId = 1;

        given(userRepository.existsById(userId)).willReturn(true);

        // when
        ticketService.deleteAllOfUser(userId);

        // then
        then(ticketRepository).should().deleteTicketsOfUser(userId);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteAllOfuser_with_unknown_id() {
        setUpService();

        // given
        long userId = -1;

        given(userRepository.existsById(userId)).willReturn(false);

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> ticketService.deleteAllOfUser(userId),
                UnknownEntityException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(MessageFormat.format(TicketService.UNKNOWN_USER_ID, userId));
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // ----------------------------------------------------------- TESTS POUR getLimits() -----------------------------------------------------------
    @Test
    void testGetLimits_with_tickets() {
        setUpAuthentication();

        // given
        LocalDate olderDate = LocalDate.of(2020, 6, 30);
        LocalDate youngerDate = LocalDate.of(2020, 7, 24);

        given(ticketRepository.findOlderDate(userId)).willReturn(olderDate);
        given(ticketRepository.findYoungerDate(userId)).willReturn(youngerDate);

        // when
        Map<String, LocalDate> result = ticketService.getLimits();

        // then
        assertNotNull(result);
        assertThat(result.keySet()).contains("olderDate");
        assertThat(result.keySet()).contains("youngerDate");
        assertThat(result).containsEntry("olderDate", olderDate)
                .containsEntry("youngerDate", youngerDate);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testGetLimits_without_tickets() {
        setUpAuthentication();

        // given
        given(ticketRepository.findOlderDate(userId)).willReturn(null);
        given(ticketRepository.findYoungerDate(userId)).willReturn(null);

        // when
        Map<String, LocalDate> result = ticketService.getLimits();

        // then
        assertNotNull(result);
        assertThat(result.keySet()).contains("olderDate");
        assertThat(result.keySet()).contains("youngerDate");
        assertThat(result).containsEntry("olderDate", LocalDate.now())
                .containsEntry("youngerDate", LocalDate.now());
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // --------------------------------------------------- TESTS POUR create(TicketDTO ticketDTO) ---------------------------------------------------
    private void testCreateTicket_of_known_type(TicketDTO ticketDTO, Ticket ticket, Class<? extends Ticket> ticketClass) {
        // given
        ticketDTO.setCode(ticket.getCode());

        ArgumentCaptor<Ticket> argument = ArgumentCaptor.forClass(ticket.getClass());

        given(ticketRepository.save(argument.capture())).willReturn(ticket);

        // when
        Ticket result = ticketService.create(ticketDTO);

        // then
        assertNotNull(result);
        assertThat(ticket.getCode()).isEqualTo(argument.getValue().getCode());
        assertThat(ticket.getCode()).isEqualTo(result.getCode());
        assertThat(argument.getValue()).isExactlyInstanceOf(ticketClass);
        assertThat(result).isExactlyInstanceOf(ticketClass);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testCreateTicket_of_known_types() {
        setUpAuthentication();

        final List<Ticket> list = List.of(
                CustomerMealCostTicket.builder().code(TicketCode.CUSTOMER_MEAL_COST).build(),
                ExceptionalBusinessTravelTicket.builder().code(TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL).build(),
                FuelTicket.builder().code(TicketCode.FUEL).build(),
                LodgingMealBusinessTicket.builder().code(TicketCode.LODGING_MEAL_BUSINESS).build(),
                SiteMealCostTicket.builder().code(TicketCode.SITE_MEAL_COST).build(),
                VariousBusinessTravelTicket.builder().code(TicketCode.VARIOUS_BUSINESS_TRAVEL).build(),
                VariousCostTicket.builder().code(TicketCode.VARIOUS_COST).build()
        );

        TicketDTO ticketDTO = TicketDTO.builder().build();

        for (Ticket ticket : list) {
            testCreateTicket_of_known_type(ticketDTO, ticket, ticket.getClass());
        }
    }

    @Test
    void testCreateTicket_of_unknown_type() {
        setUpAuthentication();

        // given
        TicketDTO ticketDTO = TicketDTO.builder().build();

        // when
        TechnicalException result = Assertions.catchThrowableOfType(
                () -> ticketService.create(ticketDTO),
                TechnicalException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(TicketService.NULL_TICKET_CODE);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // ----------------------------------------------- TESTS POUR update(long id, TicketDTO ticketDTO) ----------------------------------------------
    private void testUpdateTicket_of_known_type_and_id(TicketDTO ticketDTO, Ticket ticket, Class<? extends Ticket> ticketClass) {
        // given
        ticketDTO.setCode(ticket.getCode());

        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(userId).build();
        ticket.setEmployeeIdentity(employeeIdentity);

        ArgumentCaptor<Ticket> argument = ArgumentCaptor.forClass(ticket.getClass());

        given(ticketRepository.findById(ticket.getId())).willReturn(Optional.of(ticket));
        given(ticketRepository.save(argument.capture())).willReturn(ticket);

        // when
        Ticket result = ticketService.update(ticket.getId(), ticketDTO);

        // then
        assertNotNull(result);
        assertThat(ticket.getCode()).isEqualTo(argument.getValue().getCode());
        assertThat(ticket.getCode()).isEqualTo(result.getCode());
        assertThat(ticket.getId()).isEqualTo(result.getId());
        assertThat(argument.getValue()).isExactlyInstanceOf(ticketClass);
        assertThat(result).isExactlyInstanceOf(ticketClass);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateTicket_of_known_types_and_id() {
        setUpAuthentication();

        long ticketId = 1;

        final List<Ticket> list = List.of(
                CustomerMealCostTicket.builder().id(ticketId).code(TicketCode.CUSTOMER_MEAL_COST).build(),
                ExceptionalBusinessTravelTicket.builder().id(ticketId).code(TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL).build(),
                FuelTicket.builder().id(ticketId).code(TicketCode.FUEL).build(),
                LodgingMealBusinessTicket.builder().id(ticketId).code(TicketCode.LODGING_MEAL_BUSINESS).build(),
                SiteMealCostTicket.builder().id(ticketId).code(TicketCode.SITE_MEAL_COST).build(),
                VariousBusinessTravelTicket.builder().id(ticketId).code(TicketCode.VARIOUS_BUSINESS_TRAVEL).build(),
                VariousCostTicket.builder().id(ticketId).code(TicketCode.VARIOUS_COST).build()
        );

        TicketDTO ticketDTO = TicketDTO.builder().build();

        for (Ticket ticket : list) {
            testUpdateTicket_of_known_type_and_id(ticketDTO, ticket, ticket.getClass());
        }
    }

    // ----------------------------------------------- TESTS POUR statistics(LocalDate startDate, LocalDate endDate, BigDecimal mileageAllowance) ----------------------------------------------
    @Test
    void testStatistics_with_dates() {
        setUpAuthentication();

        // given
        BigDecimal mileageAllowance = BigDecimal.valueOf(0.325);
        given(compensationService.getCurrentUserMileageAllowance()).willReturn(mileageAllowance);

        LocalDate startDate = LocalDate.of(2020, 7, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 30);

        Map<TicketCode, TicketStatisticsDTO> expectedResults = new HashMap<>();
        int i = 0;

        expectedResults.put(TicketCode.SITE_MEAL_COST, new TicketStatisticsDTO(i, BigDecimal.valueOf(i++)));
        given(ticketRepository.statsValueTicketSiteMealCost(userId, startDate, endDate)).willReturn(expectedResults.get(TicketCode.SITE_MEAL_COST));

        expectedResults.put(TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL, new TicketStatisticsDTO(i, BigDecimal.valueOf(i++)));
        given(ticketRepository.statsValueTicketExceptionalBusinessTravel(userId, mileageAllowance, startDate, endDate)).willReturn(expectedResults.get(TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL));

        expectedResults.put(TicketCode.FUEL, new TicketStatisticsDTO(i, BigDecimal.valueOf(i++)));
        given(ticketRepository.statsValueTicketFuel(userId, startDate, endDate)).willReturn(expectedResults.get(TicketCode.FUEL));

        expectedResults.put(TicketCode.LODGING_MEAL_BUSINESS, new TicketStatisticsDTO(i, BigDecimal.valueOf(i++)));
        given(ticketRepository.statsValueTicketLodgingMealBusiness(userId, startDate, endDate)).willReturn(expectedResults.get(TicketCode.LODGING_MEAL_BUSINESS));

        expectedResults.put(TicketCode.CUSTOMER_MEAL_COST, new TicketStatisticsDTO(i, BigDecimal.valueOf(i++)));
        given(ticketRepository.statsValueTicketCustomerMealCost(userId, startDate, endDate)).willReturn(expectedResults.get(TicketCode.CUSTOMER_MEAL_COST));

        expectedResults.put(TicketCode.VARIOUS_BUSINESS_TRAVEL, new TicketStatisticsDTO(i, BigDecimal.valueOf(i++)));
        given(ticketRepository.statsValueTicketVariousBusinessTravel(userId, startDate, endDate)).willReturn(expectedResults.get(TicketCode.VARIOUS_BUSINESS_TRAVEL));

        expectedResults.put(TicketCode.VARIOUS_COST, new TicketStatisticsDTO(i, BigDecimal.valueOf(i)));
        given(ticketRepository.statsValueTicketVariousCost(userId, startDate, endDate)).willReturn(expectedResults.get(TicketCode.VARIOUS_COST));

        // when
        Map<TicketCode, TicketStatisticsDTO> result = ticketService.statistics(startDate, endDate);

        // then
        assertNotNull(result);
        assertThat(result.keySet()).contains(TicketCode.values());

        for (Map.Entry<TicketCode, TicketStatisticsDTO> res : result.entrySet()) {
            assertNotNull(res);
            assertNotNull(res.getKey());
            assertNotNull(res.getValue());
            assertThat(res.getValue()).isEqualTo(expectedResults.get(res.getKey()));
        }
    }

    @Test
    void testStatistics_with_null_start_date() {
        setUpAuthentication();

        // given
        BigDecimal mileageAllowance = BigDecimal.valueOf(0.325);
        given(compensationService.getCurrentUserMileageAllowance()).willReturn(mileageAllowance);

        LocalDate endDate = LocalDate.of(2020, 7, 30);

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> ticketService.statistics(null, endDate),
                BusinessException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(TicketService.NULL_DATES);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testStatistics_with_null_end_date() {
        setUpAuthentication();

        // given
        BigDecimal mileageAllowance = BigDecimal.valueOf(0.325);
        given(compensationService.getCurrentUserMileageAllowance()).willReturn(mileageAllowance);

        LocalDate startDate = LocalDate.of(2020, 7, 1);

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> ticketService.statistics(startDate, null),
                BusinessException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(TicketService.NULL_DATES);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // ----------------------------------------------- TESTS POUR updateValidity(long ticketId, boolean valid) ----------------------------------------------
    @Test
    void testUpdateValidity_with_existing_ticket() {
        setUpService();

        // given
        long ticketId = 1;

        Ticket ticket = Ticket.builder().id(ticketId).valid(false).build();

        given(ticketRepository.findById(ticketId)).willReturn(Optional.of(ticket));
        given(ticketRepository.save(ticket)).willReturn(ticket);

        // when
        Ticket result = ticketService.updateValidity(ticketId, true);

        // then
        assertNotNull(result);
        assertThat(result).isEqualTo(ticket);
        assertThat(result.isValid()).isTrue();
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testUpdateValidity_with_unknown_ticket() {
        setUpService();

        // given
        long ticketId = -1;

        given(ticketRepository.findById(ticketId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> ticketService.updateValidity(ticketId, true),
                UnknownEntityException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(MessageFormat.format(TicketService.UNKNOWN_TICKET, ticketId));
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // ----------------------------------------------- TESTS POUR archiveTicketBetween(LocalDate startDate, LocalDate endDate) ----------------------------------------------
    @Test
    void testArchivedTicketBetween() {
        setUpAuthentication();

        // given
        LocalDate startDate = LocalDate.of(2020, 7, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 30);

        // when
        ticketService.archiveTicketBetween(startDate, endDate);

        // then
        then(ticketRepository).should().archiveTicketBetween(userId, startDate, endDate, LocalDate.now());
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    // -------------------------------------------------------- TESTS POUR deleteTicketsOlderThan(LocalDate date) --------------------------------------------------------
    @Test
    void testDeleteTicketsOlderThan_with_valid_date() {
        setUpService();

        // given
        LocalDate date = LocalDate.now();

        // when
        ticketService.deleteTicketsOlderThan(date);

        // then
        then(ticketRepository).should().deleteTicketsOlderThan(date);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteTicketsOlderThan_with_null_date() {
        setUpService();

        // given

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> ticketService.deleteTicketsOlderThan(null),
                BusinessException.class
        );

        // then
        assertNotNull(result);
        assertThat(result).hasMessage(TicketService.NULL_DATE_DELETE_OLDER);
        then(ticketRepository).shouldHaveNoMoreInteractions();
    }
}
