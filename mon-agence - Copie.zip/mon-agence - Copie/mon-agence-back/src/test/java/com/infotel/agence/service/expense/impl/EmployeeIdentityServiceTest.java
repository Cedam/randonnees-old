package com.infotel.agence.service.expense.impl;

import com.infotel.agence.domain.expense.EmployeeIdentity;
import com.infotel.agence.domain.user.Authority;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.BusinessException;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.expense.EmployeeIdentityRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.text.MessageFormat;
import java.util.Optional;

import static com.infotel.agence.security.SecurityRole.Constant.ROLE_ADMIN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link EmployeeIdentityService}
 *
 * @author arob
 */
@ExtendWith(MockitoExtension.class)
class EmployeeIdentityServiceTest {
    @Mock
    private EmployeeIdentityRepository employeeIdentityRepository;

    @Mock
    private Authentication authentication;

    private EmployeeIdentityService employeeIdentityService;

    public void setUpService() {
        employeeIdentityService = new EmployeeIdentityService(employeeIdentityRepository);
    }

    public void setUpAuthentication() {
        setUpService();

        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);

        given(securityContext.getAuthentication()).willReturn(authentication);
    }

    // -------------------------------------------------------- TESTS POUR findById(long id) --------------------------------------------------------
    @Test
    void testFindEmployeeIdentity_with_existing_current_user() {
        setUpAuthentication();

        // given
        long employeeIdentityId = 1;
        EmployeeIdentity employeeIdentity = EmployeeIdentity.builder().id(employeeIdentityId).build();

        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        user.setId(employeeIdentityId);

        given(authentication.getPrincipal()).willReturn(user);
        given(employeeIdentityRepository.findById(employeeIdentityId)).willReturn(Optional.of(employeeIdentity));

        // when
        EmployeeIdentity result = employeeIdentityService.findCurrent();

        // then
        assertThat(result).isEqualTo(employeeIdentity);
        then(employeeIdentityRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindEmployeeIdentity_with_unknown_current_user() {
        setUpAuthentication();

        // given
        long employeeIdentityId = 1;

        User user = new User("admin", "admin", "Super", "Admin", new Authority(ROLE_ADMIN));
        user.setId(employeeIdentityId);

        given(authentication.getPrincipal()).willReturn(user);
        given(employeeIdentityRepository.findById(employeeIdentityId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> employeeIdentityService.findCurrent(),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage(MessageFormat.format(EmployeeIdentityService.UNKNOWN_EMPLOYEEIDENTITY, employeeIdentityId));
        then(employeeIdentityRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testFindEmployeeIdentity_with_bad_user() {
        setUpAuthentication();

        // given        
        given(authentication.getPrincipal()).willReturn(null);

        // when
        BusinessException result = Assertions.catchThrowableOfType(
                () -> employeeIdentityService.findCurrent(),
                BusinessException.class
        );

        // then
        assertThat(result).hasMessage(EmployeeIdentityService.NO_USER_CONNECTED);
        then(employeeIdentityRepository).shouldHaveNoMoreInteractions();
    }

    // -------------------------------------------------------- TESTS POUR deleteById(long id) --------------------------------------------------------
    @Test
    void testDeleteEmployeeIdentityById_with_existing_id() {
        setUpService();

        // given
        long employeeIdentityId = 1L;
        given(employeeIdentityRepository.existsById(employeeIdentityId)).willReturn(true);

        // when
        employeeIdentityService.deleteById(employeeIdentityId);

        // then
        then(employeeIdentityRepository).should().deleteById(employeeIdentityId);
        then(employeeIdentityRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteEmployeeIdentityById_with_unknown_id() {
        setUpService();

        // given
        long employeeIdentityId = -1L;
        given(employeeIdentityRepository.existsById(employeeIdentityId)).willReturn(false);

        // when
        employeeIdentityService.deleteById(employeeIdentityId);

        // then
        then(employeeIdentityRepository).shouldHaveNoMoreInteractions();
    }

}
