package com.infotel.agence.service.order.impl;

import com.infotel.agence.domain.order.Article;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.repository.order.ArticleRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.AdditionalAnswers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;

/**
 * Tests unitaires de la classe {@link ArticleService}
 *
 * @author JUBA
 */
@ExtendWith(MockitoExtension.class)
public class ArticleServiceTest {

    @Mock
    private ArticleRepository articleRepository;

    private ArticleService articleService;

    @BeforeEach
    public void setUp() {
        articleService = new ArticleService(articleRepository);
    }

    @Test
    public void testFindArticleById_with_existing_article() {
        // given
        long articleId = 1;
        Article article = Article.builder().id(articleId).build();
        given(articleRepository.findById(articleId)).willReturn(Optional.of(article));

        // when
        Article result = articleService.findById(articleId);

        // then
        assertThat(result).isEqualTo(article);
    }

    @Test
    void testFindArticleById_with_unknown_article() {
        // given
        long articleId = -1;
        given(articleRepository.findById(articleId)).willReturn(Optional.empty());

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> articleService.findById(articleId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage("Aucun article n'est référencé par l'id -1");
    }

    @Test
    public void testFindAllArticles() {
        // given
        Article article = new Article();
        given(articleRepository.findAll()).willReturn(List.of(article));

        // when
        List<Article> result = articleService.findAll();

        // then
        assertThat(result)
                .hasSize(1)
                .contains(article);
    }

    @Test
    public void testCreateArticle() {
        // given
        Article article = new Article();
        given(articleRepository.save(any(Article.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Article result = articleService.create(article);

        // then
        assertThat(result).isEqualTo(article);
    }

    @Test
    void testUpdateArticle_with_existing_article() {
        // given
        long articleId = 1;
        Article article = Article.builder().id(articleId).build();
        given(articleRepository.existsById(articleId)).willReturn(true);
        given(articleRepository.save(any(Article.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        // when
        Article result = articleService.update(article);

        // then
        assertThat(result).isEqualTo(article);
    }

    @Test
    void testUpdateArticle_with_unknown_article() {
        // given
        long articleId = -1;
        Article article = Article.builder().id(articleId).build();
        given(articleRepository.existsById(articleId)).willReturn(false);

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> articleService.update(article),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage("Aucun article n'est référencé par l'id -1");
        then(articleRepository).shouldHaveNoMoreInteractions();
    }

    @Test
    void testDeleteArticleById_with_existing_article() {
        // given
        long articleId = 1;
        given(articleRepository.existsById(articleId)).willReturn(true);

        // when
        articleService.deleteById(articleId);

        // then
        then(articleRepository).should().deleteById(articleId);
    }

    @Test
    void testDeleteArticleById_with_unknown_article() {
        // given
        long articleId = -1;
        given(articleRepository.existsById(articleId)).willReturn(false);

        // when
        UnknownEntityException result = Assertions.catchThrowableOfType(
                () -> articleService.deleteById(articleId),
                UnknownEntityException.class
        );

        // then
        assertThat(result).hasMessage("Aucun article n'est référencé par l'id -1");
        then(articleRepository).shouldHaveNoMoreInteractions();
    }
}
