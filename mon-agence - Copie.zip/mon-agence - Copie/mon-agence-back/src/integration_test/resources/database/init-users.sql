INSERT INTO AUTHORITY (AUT_ID, AUT_NAME)
VALUES (1, 'ROLE_ADMIN'),
       (2, 'ROLE_SYSTEM'),
       (10, 'ROLE_SUPPLY'),
       (11, 'ROLE_ADMIN_SUPPLY'),
       (20, 'ROLE_EXPENSE'),
       (21, 'ROLE_ADMIN_EXPENSE'),
       (30, 'ROLE_PUB'),
       (31, 'ROLE_ADMIN_PUB');

-- password is "password" for all users
INSERT INTO USER(USR_ID, USR_USER_NAME, USR_PASSWORD, USR_FIRST_NAME, USR_LAST_NAME, USR_IS_ENABLED)
VALUES (1, 'superAdmin', '$2a$10$6g8kTaoxPvkNcHRiI.GFAeKPprJwrr3k.CMVDO3itJaPc/L4ryBoi', 'Test', 'SuperAdmin', 1),
       (2, 'system', '$2a$10$6g8kTaoxPvkNcHRiI.GFAeKPprJwrr3k.CMVDO3itJaPc/L4ryBoi', 'Test', 'System', 1),
       (10, 'userSupply', '$2a$10$6g8kTaoxPvkNcHRiI.GFAeKPprJwrr3k.CMVDO3itJaPc/L4ryBoi', 'Test', 'Supply', 1),
       (11, 'adminSupply', '$2a$10$6g8kTaoxPvkNcHRiI.GFAeKPprJwrr3k.CMVDO3itJaPc/L4ryBoi', 'Test', 'AdminSupply', 1),
       (20, 'userExpense', '$2a$10$6g8kTaoxPvkNcHRiI.GFAeKPprJwrr3k.CMVDO3itJaPc/L4ryBoi', 'Test', 'Expense', 1),
       (21, 'adminExpense', '$2a$10$6g8kTaoxPvkNcHRiI.GFAeKPprJwrr3k.CMVDO3itJaPc/L4ryBoi', 'Test', 'AdminExpense', 1),
       (30, 'userPub', '$2a$10$6g8kTaoxPvkNcHRiI.GFAeKPprJwrr3k.CMVDO3itJaPc/L4ryBoi', 'Test', 'Publication', 1),
       (31, 'adminPub', '$2a$10$6g8kTaoxPvkNcHRiI.GFAeKPprJwrr3k.CMVDO3itJaPc/L4ryBoi', 'Test', 'AdminPublication', 1);

INSERT INTO USER2AUTHORITY (USR_ID, AUT_ID)
VALUES (1, 1),
       (2, 2),
       (10, 10),
       (11, 11),
       (20, 20),
       (21, 21),
       (30, 30),
       (30, 31);