package com.infotel.agence.controller.expense;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotel.agence.domain.expense.Compensation;
import com.infotel.agence.domain.expense.dto.CompensationDTO;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.service.expense.ICompensationService;
import com.infotel.agence.service.expense.impl.CompensationService;
import com.infotel.agence.service.user.IUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.EXPENSE;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.LOCATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link CompensationController}
 *
 * @author arob
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = CompensationController.class)
class CompensationControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IUserService userService;

    @MockBean
    private ICompensationService compensationService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(EXPENSE);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findCompensationById_should_return_compensation() throws Exception {
        long compensationId = 1;
        Compensation compensation = Compensation.builder().id(compensationId).build();
        given(compensationService.findById(compensationId)).willReturn(compensation);

        mockMvc.perform(get("/api/compensations/{id}", compensationId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(compensationId));
    }

    @Test
    void findCompensationById_should_return_404_if_no_match_found() throws Exception {
        long compensationId = 1;
        given(compensationService.findById(compensationId)).willThrow(new UnknownEntityException(CompensationService.UNKNOWN_COMP));

        mockMvc.perform(get("/api/compensations/{id}", compensationId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(CompensationService.UNKNOWN_COMP));
    }

    @Test
    void findAllCompensationsPage_should_return_page_of_compensations() throws Exception {
        String getUrl = "/api/compensations?page={0}" +
                "&size={1}" +
                "&sort={2}";

        // Compensation renvoyé
        Compensation resultCompensation = Compensation.builder().id(1L).build();

        // Page renvoyée
        int pageNumber = 0;
        int size = 10;
        String sort = "Cv,ASC";
        Pageable pageable = PageRequest.of(pageNumber, size, Sort.by(Sort.Direction.ASC, "Cv"));
        Page<Compensation> pageResult = new PageImpl(List.of(resultCompensation), pageable, 1);

        // given
        given(compensationService.findAllPage(pageable)).willReturn(pageResult);

        mockMvc.perform(get(getUrl, pageNumber, size, sort)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.content[0]").value(equalTo(resultCompensation), Compensation.class));
    }

    @Test
    void findAllCompensationsList_should_return_list_of_compensations() throws Exception {
        Compensation compensation = Compensation.builder().id(1L).build();
        given(compensationService.findAllList()).willReturn(List.of(compensation));

        mockMvc.perform(get("/api/compensations/all")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$[0]").value(equalTo(compensation), Compensation.class));
    }

    @Test
    void createCompensation_should_create_the_new_compensation() throws Exception {
        CompensationDTO compensationDTO = new CompensationDTO();
        Compensation compensation = Compensation.builder().id(1L).build();
        given(compensationService.create(compensationDTO)).willReturn(compensation);

        String body = objectMapper.writeValueAsString(compensationDTO);
        mockMvc.perform(post("/api/compensations")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(body)
                .secure(true))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(header().string(LOCATION, "/api/compensations/1"))
                .andExpect(jsonPath("$").value(equalTo(compensation), Compensation.class));
    }

    @Test
    void updateCompensation_should_update_the_compensation() throws Exception {
        long compensationId = 1;
        CompensationDTO compensationDTO = new CompensationDTO();
        Compensation compensation = Compensation.builder().id(compensationId).build();
        given(compensationService.update(compensationId, compensationDTO)).willReturn(compensation);

        mockMvc.perform(put("/api/compensations/{id}", compensationId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(compensationDTO))
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(compensation), Compensation.class));
    }
}
