package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.ReceiptPicture;
import com.infotel.agence.domain.expense.ticket.Ticket;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.service.expense.IReceiptPictureService;
import com.infotel.agence.service.expense.impl.ReceiptPictureService;
import com.infotel.agence.service.user.IUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.EXPENSE;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link ReceiptPictureController}
 *
 * @author arob
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = ReceiptPictureController.class)
class ReceiptPictureControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IUserService userService;

    @MockBean
    private IReceiptPictureService receiptPictureService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(EXPENSE);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findReceiptPictureByTicketId_should_return_receiptPicture() throws Exception {
        long ticketId = 1;
        Ticket ticket = Ticket.builder().id(ticketId).build();
        ReceiptPicture receiptPicture = ReceiptPicture.builder().ticket(ticket).name("Test").build();
        given(receiptPictureService.findByTicketId(ticketId)).willReturn(receiptPicture);

        mockMvc.perform(get("/api/receiptPictures/{id}", ticketId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.name").value(receiptPicture.getName()));
    }

    @Test
    void findReceiptPictureByTicketId_should_return_404_if_no_match_found() throws Exception {
        long ticketId = 1;
        given(receiptPictureService.findByTicketId(ticketId))
                .willThrow(new UnknownEntityException(ReceiptPictureService.UNKNOWN_RPIC));

        mockMvc.perform(get("/api/receiptPictures/{id}", ticketId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(ReceiptPictureService.UNKNOWN_RPIC));
    }
}
