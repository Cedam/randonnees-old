package com.infotel.agence.repository.user;

import com.infotel.agence.domain.user.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles("test")
@DataJpaTest(showSql = false)
class UserRepositoryIT {

    @Autowired
    private UserRepository userRepository;

    @Test
    void findByUsername_should_return_user() {
        // given
        final String username = "system";

        // when
        final User result = userRepository.findByUsername(username);

        // then
        assertThat(result)
                .isNotNull()
                .extracting(User::getUsername)
                .isEqualTo(username);
    }

    @Test
    void setRefreshToken_should_update_user_token() {
        // given
        final String username = "system";
        final String myToken = "MY_TOKEN";

        // when
        userRepository.setRefreshToken(username, myToken);

        // then
        assertThat(userRepository.findByUsername(username))
                .isNotNull()
                .extracting(User::getRefreshToken)
                .isEqualTo(myToken);
    }
}
