package com.infotel.agence.controller.user;

import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.service.user.impl.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.ADMIN;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link UserController}
 *
 * @author arob
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = UserController.class)
class UserControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(ADMIN);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findUserById_should_return_user() throws Exception {
        long userId = 1;
        User user = User.builder().id(userId).build();
        given(userService.findById(userId)).willReturn(user);

        mockMvc.perform(get("/api/users/{id}", userId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(userId));
    }

    @Test
    void findUserById_should_return_404_if_no_match_found() throws Exception {
        long userId = 1;
        given(userService.findById(userId)).willThrow(new UnknownEntityException(UserService.UNKNOWN_USER));

        mockMvc.perform(get("/api/users/{id}", userId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(UserService.UNKNOWN_USER));
    }

    @Test
    void findAllUsersPage_should_return_page_of_users() throws Exception {
        String getUrl = "/api/users?page={0}" +
                "&size={1}" +
                "&sort={2}";

        // Utilisateur renvoyé
        User resultUser = User.builder().id(1L).build();

        // Page renvoyée
        int pageNumber = 0;
        int size = 10;
        String sort = "username,ASC";
        Pageable pageable = PageRequest.of(pageNumber, size, Sort.by(Sort.Direction.ASC, "username"));
        Page<User> pageResult = new PageImpl(List.of(resultUser), pageable, 1);

        // given
        given(userService.findAllPage(pageable)).willReturn(pageResult);

        mockMvc.perform(get(getUrl, pageNumber, size, sort)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.content[0]").value(equalTo(resultUser), User.class));
    }

    @Test
    void findAllUsersList_should_return_list_of_users() throws Exception {
        User user = User.builder().id(1L).build();
        given(userService.findAllList()).willReturn(List.of(user));

        mockMvc.perform(get("/api/users/all")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$[0]").value(equalTo(user), User.class));
    }

    @Test
    void deleteById_should_delete_user() throws Exception {
        long userId = 1L;

        mockMvc.perform(delete("/api/users/{id}", userId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNoContent());
    }
}
