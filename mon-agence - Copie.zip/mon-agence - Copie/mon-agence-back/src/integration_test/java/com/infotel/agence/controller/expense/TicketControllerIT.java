package com.infotel.agence.controller.expense;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotel.agence.domain.expense.ReceiptPicture;
import com.infotel.agence.domain.expense.dto.TicketDTO;
import com.infotel.agence.domain.expense.ticket.*;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.service.expense.IReceiptPictureService;
import com.infotel.agence.service.expense.ITicketService;
import com.infotel.agence.service.expense.impl.TicketService;
import com.infotel.agence.service.user.IUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.*;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.AbstractMap;
import java.util.List;
import java.util.Map;

import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.EXPENSE;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.LOCATION;
import static org.springframework.http.MediaType.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link TicketController}
 *
 * @author arob
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = TicketController.class)
class TicketControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IUserService userService;

    @MockBean
    private ITicketService ticketService;

    @MockBean
    private IReceiptPictureService receiptPictureService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(EXPENSE);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findAllTicketCode() throws Exception {
        mockMvc.perform(get("/api/tickets/allCodes")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").isMap())
                .andExpect(jsonPath("$.EXCEPTIONAL_BUSINESS_TRAVEL").value(TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL.getLabel()));
    }

    @Test
    void findTicketById_should_return_ticket() throws Exception {
        long ticketId = 1;
        Ticket ticket = Ticket.builder().id(ticketId).build();
        given(ticketService.findById(ticketId)).willReturn(ticket);

        mockMvc.perform(get("/api/tickets/{id}", ticketId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(ticketId));
    }

    @Test
    void findTicketById_should_return_404_if_no_match_found() throws Exception {
        long ticketId = 1;
        given(ticketService.findById(ticketId)).willThrow(new UnknownEntityException(TicketService.UNKNOWN_TICKET));

        mockMvc.perform(get("/api/tickets/{id}", ticketId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(TicketService.UNKNOWN_TICKET));
    }

    @Test
    void findAllTicketsTest() throws Exception {
        String getUrl = "/api/tickets?page={0}" +
                "&size={1}" +
                "&ticketCode={2}" +
                "&sort={3}" +
                "&startDate={4}" +
                "&endDate={5}" +
                "&isArchived={6}";

        // Création du ticket renvoyé
        long ticketId = 1;
        Ticket resultTicket = CustomerMealCostTicket.builder().id(ticketId).code(TicketCode.CUSTOMER_MEAL_COST).build();

        // Création de la page request, de la page renvoyée et de leurs informations
        int pageNumber = 0;
        int size = 10;
        String sort = "Date,ASC";
        Pageable pageable = PageRequest.of(pageNumber, size, Sort.by(Sort.Direction.ASC, "Date"));
        Page<Ticket> pageResult = new PageImpl<>(List.of(resultTicket), pageable, 1);

        // Création des informations autres présentes dans la requête
        TicketCode ticketCode = TicketCode.CUSTOMER_MEAL_COST;
        LocalDate startDate = LocalDate.of(2020, 6, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 31);
        boolean isArchived = false;

        // given
        given(ticketService.findAll(pageable, ticketCode, startDate, endDate, isArchived)).willReturn(pageResult);

        // Test sur la requête
        mockMvc.perform(get(getUrl, pageNumber, size, ticketCode, sort, startDate.format(DateTimeFormatter.ISO_DATE),
                endDate.format(DateTimeFormatter.ISO_DATE), isArchived)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.content[0].id").value(ticketId));
    }

    @Test
    void findAllTicketsToVerifyTest() throws Exception {
        String getUrl = "/api/tickets/toVerify";

        // Création du ticket renvoyé
        long ticketId = 1;
        Ticket resultTicket = CustomerMealCostTicket.builder().id(ticketId).code(TicketCode.CUSTOMER_MEAL_COST).valid(false).build();

        // given
        given(ticketService.findAllToVerify()).willReturn(List.of(resultTicket));

        // Test sur la requête
        mockMvc.perform(get(getUrl)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$[0].id").value(ticketId));
    }

    @Test
    void deleteTicketById_should_delete_ticket() throws Exception {
        long ticketId = 1;

        mockMvc.perform(delete("/api/tickets/{id}", ticketId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNoContent());
    }

    private void createTicket(Long ticketId, TicketDTO ticketDTO, Ticket ticket, ReceiptPicture receiptPicture) throws Exception {
        given(ticketService.create(ticketDTO)).willReturn(ticket);

        byte[] data = objectMapper.writeValueAsBytes(ticketDTO);
        MockMultipartFile dataFile = new MockMultipartFile("ticketDTO", "", APPLICATION_JSON_VALUE, data);

        if (receiptPicture != null) {
            byte[] picture = objectMapper.writeValueAsBytes(receiptPicture);
            MockMultipartFile pictureFile = new MockMultipartFile("receiptPicture", "", APPLICATION_OCTET_STREAM_VALUE, picture);

            given(receiptPictureService.create(receiptPicture)).willReturn(receiptPicture);

            mockMvc.perform(multipart("/api/tickets")
                    .file(dataFile)
                    .file(pictureFile)
                    .header(AUTHORIZATION, getDefaultUserTokenAuth())
                    .accept(APPLICATION_JSON)
                    .characterEncoding(StandardCharsets.UTF_8.displayName())
                    .contentType(MULTIPART_FORM_DATA_VALUE)
                    .secure(true))
                    .andExpect(status().isCreated())
                    .andExpect(content().contentType(APPLICATION_JSON))
                    .andExpect(header().string(LOCATION, "/api/tickets/" + ticketId))
                    .andExpect(jsonPath("$.id").value(ticketId))
                    .andExpect(jsonPath("$.code").value(ticketDTO.getCode().toString()));
        } else {
            mockMvc.perform(multipart("/api/tickets")
                    .file(dataFile)
                    .header(AUTHORIZATION, getDefaultUserTokenAuth())
                    .accept(APPLICATION_JSON)
                    .characterEncoding(StandardCharsets.UTF_8.displayName())
                    .contentType(MULTIPART_FORM_DATA_VALUE)
                    .secure(true))
                    .andExpect(status().isCreated())
                    .andExpect(content().contentType(APPLICATION_JSON))
                    .andExpect(header().string(LOCATION, "/api/tickets/" + ticketId))
                    .andExpect(jsonPath("$.id").value(ticketId))
                    .andExpect(jsonPath("$.code").value(ticketDTO.getCode().toString()));
        }
    }

    @Test
    void createTicket_should_create_the_new_ticket() throws Exception {
        long ticketId = 1;

        LocalDate date = LocalDate.now();

        for (TicketCode code : TicketCode.values()) {
            createTicket(ticketId,
                    TicketDTO.builder().code(code).date(date).build(),
                    Ticket.builder().id(ticketId).code(code).date(date).build(),
                    code != TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL ? ReceiptPicture.builder().build() : null);
        }
    }

    private void updateTicket(long ticketId, TicketDTO ticketDTO, Ticket ticket) throws Exception {
        given(ticketService.update(ticketId, ticketDTO)).willReturn(ticket);

        mockMvc.perform(put("/api/tickets/{id}", ticketId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(ticketDTO))
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(ticket.getId()))
                .andExpect(jsonPath("$.code").value(ticket.getCode().toString()));
    }

    @Test
    void updateTicket_should_update_the_ticket() throws Exception {
        long ticketId = 1;

        List<Ticket> allTickets = List.of(
                CustomerMealCostTicket.builder().id(ticketId).code(TicketCode.CUSTOMER_MEAL_COST).build(),
                ExceptionalBusinessTravelTicket.builder().id(ticketId).code(TicketCode.EXCEPTIONAL_BUSINESS_TRAVEL).build(),
                FuelTicket.builder().id(ticketId).code(TicketCode.FUEL).build(),
                LodgingMealBusinessTicket.builder().id(ticketId).code(TicketCode.LODGING_MEAL_BUSINESS).build(),
                SiteMealCostTicket.builder().id(ticketId).code(TicketCode.SITE_MEAL_COST).build(),
                VariousBusinessTravelTicket.builder().id(ticketId).code(TicketCode.VARIOUS_BUSINESS_TRAVEL).build(),
                VariousCostTicket.builder().id(ticketId).code(TicketCode.VARIOUS_COST).build());

        for (Ticket ticket : allTickets) {
            updateTicket(ticketId, TicketDTO.builder().code(ticket.getCode()).date(LocalDate.now()).build(), ticket);
        }
    }

    @Test
    void updateTicketValidity_should_update_ticket() throws Exception {
        long ticketId = 1;
        Ticket ticket = Ticket.builder().id(ticketId).valid(false).build();
        given(ticketService.updateValidity(ticketId, true)).willReturn(ticket);

        mockMvc.perform(patch("/api/tickets/{id}/verify", ticketId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true)
        )
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(ticket.getId()))
                .andExpect(jsonPath("$.valid").value(ticket.isValid()));
    }

    @Test
    void getLimitsTest() throws Exception {
        LocalDate olderDate = LocalDate.of(2020, 6, 1);
        LocalDate youngerDate = LocalDate.of(2020, 7, 31);

        Map<String, LocalDate> result = Map.ofEntries(
                new AbstractMap.SimpleEntry<>("olderDate", olderDate),
                new AbstractMap.SimpleEntry<>("youngerDate", youngerDate));

        given(ticketService.getLimits()).willReturn(result);

        mockMvc.perform(get("/api/tickets/limits")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.olderDate").value(olderDate.toString()))
                .andExpect(jsonPath("$.youngerDate").value(youngerDate.toString()));
    }
}
