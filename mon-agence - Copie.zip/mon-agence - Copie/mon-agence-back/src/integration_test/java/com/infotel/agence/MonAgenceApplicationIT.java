package com.infotel.agence;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.HashMap;
import java.util.Map;

import static com.infotel.agence.helper.UserTestData.getBasicAuth;
import static com.infotel.agence.security.CustomHttpHeaders.X_AUTHORIZATION;
import static com.infotel.agence.security.CustomHttpHeaders.X_REFRESH;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ActiveProfiles("test")
@AutoConfigureMockMvc
@SpringBootTest
class MonAgenceApplicationIT {

    @Autowired
    private MockMvc mockMvc;

    /**
     * Description du process d'authentification avec un renouvellement ultérieur
     * <br> 1) POST /api/login
     * <br> 2) POST /api/login/renew
     */
    @Test
    void authentication_process() throws Exception {
        final Map<String, String> tokens = new HashMap<>();

        mockMvc.perform(post("/api/login")
                .header(AUTHORIZATION, getBasicAuth("superAdmin", "password"))
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(header().exists(X_AUTHORIZATION))
                .andExpect(header().exists(X_REFRESH))
                .andDo(result -> {
                    final MockHttpServletResponse response = result.getResponse();
                    tokens.put(X_AUTHORIZATION, response.getHeader(X_AUTHORIZATION));
                    tokens.put(X_REFRESH, response.getHeader(X_REFRESH));
                });

        // TODO ALI TEST A COMPLETER
//        mockMvc.perform(post("/api/login/renew")
//                .header(AUTHORIZATION, asBearerToken(tokens.get(X_AUTHORIZATION)))
//                .accept(APPLICATION_JSON)
//                .secure(true))
//                .andExpect(status().isOk())
//                .andExpect(header().exists(X_AUTHORIZATION))
//                .andExpect(header().exists(X_REFRESH));
    }
}
