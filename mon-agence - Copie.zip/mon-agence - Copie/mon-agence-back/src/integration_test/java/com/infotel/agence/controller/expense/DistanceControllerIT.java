package com.infotel.agence.controller.expense;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotel.agence.domain.expense.Distance;
import com.infotel.agence.domain.expense.Place;
import com.infotel.agence.domain.expense.dto.DistanceDTO;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.service.expense.IDistanceService;
import com.infotel.agence.service.expense.impl.DistanceService;
import com.infotel.agence.service.user.IUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.List;

import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.EXPENSE;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.LOCATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link DistanceController}
 *
 * @author arob
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = DistanceController.class)
class DistanceControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IUserService userService;

    @MockBean
    private IDistanceService distanceService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(EXPENSE);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findDistanceByPlacesId_should_return_distance() throws Exception {
        long placeIdA = 1;
        long placeIdB = 2;
        long distanceId = 1;
        Place placeA = Place.builder().id(placeIdA).build();
        Place placeB = Place.builder().id(placeIdB).build();
        Distance distance = Distance.builder().id(distanceId).placeStart(placeA).placeEnd(placeB).build();
        given(distanceService.findByPlacesId(placeIdA, placeIdB)).willReturn(distance);

        String getUrl = MessageFormat.format("/api/distances/byPlacesId?idPlaceA={0}&idPlaceB={1}", placeIdA, placeIdB);
        mockMvc.perform(get(getUrl)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(distance), Distance.class));
    }

    @Test
    void findDistanceByPlacesId_should_return_404_if_no_match_found() throws Exception {
        long placeIdA = 1;
        long placeIdB = 2;
        given(distanceService.findByPlacesId(placeIdA, placeIdB)).willThrow(new UnknownEntityException(DistanceService.UNKNOWN_DISTANCE));

        String getUrl = MessageFormat.format("/api/distances/byPlacesId?idPlaceA={0}&idPlaceB={1}", placeIdA, placeIdB);
        mockMvc.perform(get(getUrl)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(DistanceService.UNKNOWN_DISTANCE));
    }

    @Test
    void createDistance_should_create_the_new_distance() throws Exception {
        long distanceId = 1;
        Distance distance = Distance.builder().id(distanceId).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        given(distanceService.create(distanceDTO)).willReturn(distance);

        String body = objectMapper.writeValueAsString(distanceDTO);
        mockMvc.perform(post("/api/distances")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(body)
                .secure(true))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(header().string(LOCATION, "/api/distances/" + distanceId))
                .andExpect(jsonPath("$").value(equalTo(distance), Distance.class));
    }

    @Test
    void updateDistance_should_update_the_distance() throws Exception {
        long distanceId = 1;
        Distance distance = Distance.builder().id(distanceId).build();
        DistanceDTO distanceDTO = new DistanceDTO();
        given(distanceService.update(distanceId, distanceDTO)).willReturn(distance);

        mockMvc.perform(put("/api/distances/{id}", distanceId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(distance))
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(distance), Distance.class));
    }

    @Test
    void findAllDistances_should_return_page_of_distances() throws Exception {
        String getUrl = "/api/distances?page={0}" +
                "&size={1}" +
                "&sort={2}";

        // Distance renvoyé
        Distance resultDistance = Distance.builder().id(1L).build();

        // Page renvoyée
        int pageNumber = 0;
        int size = 10;
        String sort = "value,ASC";
        Pageable pageable = PageRequest.of(pageNumber, size, Sort.by(Sort.Direction.ASC, "value"));
        Page<Distance> pageResult = new PageImpl(List.of(resultDistance), pageable, 1);

        // given
        given(distanceService.findAll(pageable)).willReturn(pageResult);

        mockMvc.perform(get(getUrl, pageNumber, size, sort)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.content[0]").value(equalTo(resultDistance), Distance.class));
    }

    @Test
    void findDistanceById_should_return_distance() throws Exception {
        long distanceId = 1;
        Distance distance = Distance.builder().id(distanceId).build();
        given(distanceService.findById(distanceId)).willReturn(distance);

        mockMvc.perform(get("/api/distances/{id}", distanceId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(distanceId));
    }

    @Test
    void findDistanceById_should_return_404_if_no_match_found() throws Exception {
        long distanceId = 1;
        given(distanceService.findById(distanceId)).willThrow(new UnknownEntityException(DistanceService.UNKNOWN_DISTANCE));

        mockMvc.perform(get("/api/distances/{id}", distanceId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(DistanceService.UNKNOWN_DISTANCE));
    }
}
