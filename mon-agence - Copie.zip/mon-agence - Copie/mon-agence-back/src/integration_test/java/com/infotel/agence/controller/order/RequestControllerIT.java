package com.infotel.agence.controller.order;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotel.agence.domain.order.Request;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.service.order.impl.RequestService;
import com.infotel.agence.service.user.impl.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.AdditionalAnswers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static com.infotel.agence.domain.order.Request.builder;
import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.SUPPLY;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.LOCATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link RequestController}
 *
 * @author ARLI
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = RequestController.class)
class RequestControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;

    @MockBean
    private RequestService requestService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(SUPPLY);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findRequestById_should_return_the_request() throws Exception {
        long requestId = 1;
        Request expectedRequest = builder().id(requestId).build();
        given(requestService.findById(requestId)).willReturn(expectedRequest);

        mockMvc.perform(get("/api/demandes/{id}", requestId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(expectedRequest), Request.class));
    }

    @Test
    void findRequestById_should_return_404_if_no_match_found() throws Exception {
        String errorMessage = "MESSAGE";
        given(requestService.findById(anyLong())).willThrow(new UnknownEntityException(errorMessage));

        mockMvc.perform(get("/api/demandes/{id}", 1)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(errorMessage));
    }

    @Test
    void findAllRequests_should_return_list_of_requests() throws Exception {
        Request request = builder().id(1L).build();
        given(requestService.findAll()).willReturn(List.of(request));

        mockMvc.perform(get("/api/demandes")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$[0]").value(equalTo(request), Request.class));
    }

    @Test
    void createRequest_should_create_the_new_request() throws Exception {
        Request request = builder().id(1L).build();
        given(requestService.create(request)).will(AdditionalAnswers.returnsFirstArg());

        mockMvc.perform(post("/api/demandes")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
                .secure(true))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(header().string(LOCATION, "/api/demandes/1"))
                .andExpect(jsonPath("$").value(equalTo(request), Request.class));
    }

    @Test
    void updateRequest_should_update_the_request() throws Exception {
        long requestId = 1;
        Request request = builder().id(requestId).build();
        given(requestService.update(request)).will(AdditionalAnswers.returnsFirstArg());

        mockMvc.perform(put("/api/demandes/{id}", requestId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(request), Request.class));
    }

    @Test
    void deleteRequest_should_delete_the_request() throws Exception {
        long requestId = 1;
        Request request = builder().id(requestId).build();
        given(requestService.update(request)).will(AdditionalAnswers.returnsFirstArg());

        mockMvc.perform(delete("/api/demandes/{id}", requestId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .secure(true))
                .andExpect(status().isNoContent())
                .andExpect(jsonPath("$").doesNotExist());
    }
}
