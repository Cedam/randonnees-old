package com.infotel.agence.helper;

import com.infotel.agence.domain.user.Authority;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.security.SecurityRole;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.lang.NonNull;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Arrays;
import java.util.Objects;

import static io.jsonwebtoken.SignatureAlgorithm.HS512;
import static java.nio.charset.StandardCharsets.UTF_8;
import static org.springframework.http.HttpHeaders.encodeBasicAuth;

/**
 * Gestion des jeux de données utilisateur pour les tests d'intégration
 *
 * @author ARLI
 */
public class UserTestData {

    private static final String BASIC_AUTH = "Basic";
    private static final String BEARER_AUTH = "Bearer";

    private static final BCryptPasswordEncoder PASSWORD_ENCODER = new BCryptPasswordEncoder();
    private static final String JWT_SECRET_KEY;

    static {
        YamlPropertiesFactoryBean yamlPropertiesFactoryBean = new YamlPropertiesFactoryBean();
        yamlPropertiesFactoryBean.setResources(new ClassPathResource("application-test.yml"));
        JWT_SECRET_KEY = Objects.requireNonNull(yamlPropertiesFactoryBean.getObject()).getProperty("security.jwt.secret-key");
    }

    private UserTestData() {
        // private constructor
    }

    /**
     * Construit un nouvel utilisateur.
     *
     * @param username login utilisateur
     * @param password mot de passe
     * @param roles    les rôles attribués à l'utilisateur
     * @return utilisateur
     */
    public static User getUserWithRoles(@NonNull String username, @NonNull String password, SecurityRole... roles) {
        return new User(
                username,
                PASSWORD_ENCODER.encode(password),
                "lastname",
                "firstname",
                Arrays.stream(roles).map(SecurityRole::toAuthority).toArray(Authority[]::new));
    }

    /**
     * Construit un utilisateur avec par défaut le login "user" et le mot de passe "password.
     * Cet utilisateur possedera les roles passés en paramètre.
     *
     * @param roles les rôles attribués à l'utilisateur
     * @return utilisateur
     */
    public static User getDefaultUserWithRoles(SecurityRole... roles) {
        return getUserWithRoles("user", "password", roles);
    }

    /**
     * Retourne le contenu du header AUTHORIZATION avec une authentification "Basic" pour les identifants donnés en paramètre.
     *
     * @param username login utilisateur
     * @param password mot de passe
     * @return contenu du header AUTHORIZATION
     */
    public static String getBasicAuth(@NonNull String username, @NonNull String password) {
        return String.format("%s %s", BASIC_AUTH, encodeBasicAuth(username, password, UTF_8));
    }

    /**
     * Retourne le contenu du header AUTHORIZATION avec une authentification "Basic" pour l'utilisateur par défaut
     *
     * @return contenu du header AUTHORIZATION
     */
    public static String getDefaultUserBasicAuth() {
        return getBasicAuth("user", "password");
    }

    /**
     * Retourne le contenu du header AUTHORIZATION avec une authentification via le token JWT donné
     *
     * @param token JWT token
     * @return contenu du header AUTHORIZATION
     */
    public static String asBearerToken(@NonNull String token) {
        return String.format("%s %s", BEARER_AUTH, token);
    }

    /**
     * Retourne le contenu du header AUTHORIZATION avec une authentification via un token JWT pour le login donné (sans expiration)
     *
     * @param username login utilisateur
     * @return contenu du header AUTHORIZATION
     */
    public static String getTokenAuth(@NonNull String username) {
        return String.format("%s %s", BEARER_AUTH, createJWTToken(username));
    }

    /**
     * Retourne le contenu du header AUTHORIZATION avec une authentification via un token JWT pour l'utilisateur par défaut (sans expiration)
     *
     * @return contenu du header AUTHORIZATION
     */
    public static String getDefaultUserTokenAuth() {
        return getTokenAuth("user");
    }

    /**
     * Créer un nouveau token JWT
     *
     * @param subject subject
     * @return token JWT
     */
    private static String createJWTToken(@NonNull String subject) {
        return Jwts.builder()
                .setSubject(subject)
                .signWith(HS512, JWT_SECRET_KEY)
                .compact();
    }
}
