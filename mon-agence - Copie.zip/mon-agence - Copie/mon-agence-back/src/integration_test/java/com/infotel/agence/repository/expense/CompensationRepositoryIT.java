package com.infotel.agence.repository.expense;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles("test")
@DataJpaTest(showSql = false)
class CompensationRepositoryIT {

    @Autowired
    private CompensationRepository compensationRepository;

    @Test
    void getCurrentUserMileageAllowance_should_return_mileageAllowance() {
        // given
        final Long userId = 20L;

        // when
        final BigDecimal result = compensationRepository.getCurrentUserMileageAllowance(userId);

        // then
        assertThat(result)
                .isNotNull()
                .isEqualTo(BigDecimal.valueOf(0.435));
    }
}
