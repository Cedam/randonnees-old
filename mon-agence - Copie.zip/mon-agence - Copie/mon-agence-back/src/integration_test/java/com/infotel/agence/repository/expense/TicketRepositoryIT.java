package com.infotel.agence.repository.expense;

import com.infotel.agence.domain.expense.dto.TicketStatisticsDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles("test")
@DataJpaTest(showSql = false)
class TicketRepositoryIT {

    @Autowired
    private TicketRepository ticketRepository;

    @Test
    void findYoungerDate_should_find_date() {
        // given
        final long userId = 20L;

        // when
        final LocalDate result = ticketRepository.findYoungerDate(userId);

        // then
        assertThat(result)
                .isNotNull()
                .isEqualTo(LocalDate.of(2020, 5, 7));
    }

    @Test
    void findOlderDate_should_find_date() {
        // given
        final long userId = 20L;

        // when
        final LocalDate result = ticketRepository.findOlderDate(userId);

        // then
        assertThat(result)
                .isNotNull()
                .isEqualTo(LocalDate.of(2020, 5, 1));
    }

    @Test
    void findYoungerDateToGenerate_should_find_date() {
        // given
        final long userId = 20L;

        // when
        final LocalDate result = ticketRepository.findYoungerDateToGenerate(userId);

        // then
        assertThat(result)
                .isNotNull()
                .isEqualTo(LocalDate.of(2020, 5, 7));
    }

    @Test
    void findOlderDateToGenerate_should_find_date() {
        // given
        final long userId = 20L;

        // when
        final LocalDate result = ticketRepository.findOlderDateToGenerate(userId);

        // then
        assertThat(result)
                .isNotNull()
                .isEqualTo(LocalDate.of(2020, 5, 1));
    }

    @Test
    void statsValueTicketCustomerMealCost_should_return_stats() {
        // given
        final long userId = 20L;
        final LocalDate startDate = LocalDate.of(2020, 5, 1);
        final LocalDate endDate = LocalDate.of(2020, 5, 7);

        // when
        final TicketStatisticsDTO result = ticketRepository.statsValueTicketCustomerMealCost(userId, startDate, endDate);

        // then
        assertThat(result)
                .isNotNull();
        assertThat(result.getQte()).isEqualTo(1);
        assertThat(result.getValue()).isEqualByComparingTo(BigDecimal.valueOf(59.5));
    }

    @Test
    void statsValueTicketExceptionalBusinessTravel_should_return_stats() {
        // given
        final long userId = 20L;
        final LocalDate startDate = LocalDate.of(2020, 5, 1);
        final LocalDate endDate = LocalDate.of(2020, 5, 7);

        // when
        final TicketStatisticsDTO result = ticketRepository.statsValueTicketExceptionalBusinessTravel(userId, BigDecimal.valueOf(0.5), startDate, endDate);

        // then
        assertThat(result)
                .isNotNull();
        assertThat(result.getQte()).isEqualTo(1);
        assertThat(result.getValue()).isEqualByComparingTo(BigDecimal.valueOf(5.25));
    }

    @Test
    void statsValueTicketFuel_should_return_stats() {
        // given
        final long userId = 20L;
        final LocalDate startDate = LocalDate.of(2020, 5, 1);
        final LocalDate endDate = LocalDate.of(2020, 5, 7);

        // when
        final TicketStatisticsDTO result = ticketRepository.statsValueTicketFuel(userId, startDate, endDate);

        // then
        assertThat(result)
                .isNotNull();
        assertThat(result.getQte()).isEqualTo(1);
        assertThat(result.getValue()).isEqualByComparingTo(BigDecimal.valueOf(48.5));
    }

    @Test
    void statsValueTicketLodgingMealBusiness_should_return_stats() {
        // given
        final long userId = 20L;
        final LocalDate startDate = LocalDate.of(2020, 5, 1);
        final LocalDate endDate = LocalDate.of(2020, 5, 7);

        // when
        final TicketStatisticsDTO result = ticketRepository.statsValueTicketLodgingMealBusiness(userId, startDate, endDate);

        // then
        assertThat(result)
                .isNotNull();
        assertThat(result.getQte()).isEqualTo(1);
        assertThat(result.getValue()).isEqualByComparingTo(BigDecimal.valueOf(104.7));
    }

    @Test
    void statsValueTicketSiteMealCost_should_return_stats() {
        // given
        final long userId = 20L;
        final LocalDate startDate = LocalDate.of(2020, 5, 1);
        final LocalDate endDate = LocalDate.of(2020, 5, 7);

        // when
        final TicketStatisticsDTO result = ticketRepository.statsValueTicketSiteMealCost(userId, startDate, endDate);

        // then
        assertThat(result)
                .isNotNull();
        assertThat(result.getQte()).isEqualTo(1);
        assertThat(result.getValue()).isEqualByComparingTo(BigDecimal.valueOf(58.8));
    }

    @Test
    void statsValueTicketVariousBusinessTravel_should_return_stats() {
        // given
        final long userId = 20L;
        final LocalDate startDate = LocalDate.of(2020, 5, 1);
        final LocalDate endDate = LocalDate.of(2020, 5, 7);

        // when
        final TicketStatisticsDTO result = ticketRepository.statsValueTicketVariousBusinessTravel(userId, startDate, endDate);

        // then
        assertThat(result)
                .isNotNull();
        assertThat(result.getQte()).isEqualTo(1);
        assertThat(result.getValue()).isEqualByComparingTo(BigDecimal.valueOf(21.5));
    }

    @Test
    void statsValueTicketVariousCost_should_return_stats() {
        // given
        final long userId = 20L;
        final LocalDate startDate = LocalDate.of(2020, 5, 1);
        final LocalDate endDate = LocalDate.of(2020, 5, 7);

        // when
        final TicketStatisticsDTO result = ticketRepository.statsValueTicketVariousCost(userId, startDate, endDate);

        // then
        assertThat(result)
                .isNotNull();
        assertThat(result.getQte()).isEqualTo(1);
        assertThat(result.getValue()).isEqualByComparingTo(BigDecimal.valueOf(28.5));
    }

    @Test
    void archiveTicketBetween_should_update_tickets() {
        // given
        final long userId = 20L;
        final LocalDate startDate = LocalDate.of(2020, 5, 1);
        final LocalDate endDate = LocalDate.of(2020, 5, 7);
        final LocalDate todayDate = LocalDate.now();

        // when
        ticketRepository.archiveTicketBetween(userId, startDate, endDate, todayDate);

        // then
        assertThat(ticketRepository.findById(2L).get().getArchived()).isNotNull();
        assertThat(ticketRepository.findById(4L).get().getArchived()).isNotNull();
        assertThat(ticketRepository.findById(8L).get().getArchived()).isNotNull();
        assertThat(ticketRepository.findById(6L).get().getArchived()).isNotNull();
        assertThat(ticketRepository.findById(10L).get().getArchived()).isNotNull();
        assertThat(ticketRepository.findById(12L).get().getArchived()).isNotNull();
        assertThat(ticketRepository.findById(14L).get().getArchived()).isNotNull();
    }

    @Test
    void updateValidIfIdPlace_should_update_ticket() {
        // given
        final long placeId = 7L;
        final boolean valid = false;

        // when
        ticketRepository.updateValidIfIdPlace(placeId, valid);

        // then
        assertThat(ticketRepository.findById(5L).get().isValid()).isFalse();
    }

    @Test
    void updateValidIfIdDistance_should_update_ticket() {
        // given
        final long distanceId = 5L;
        final boolean valid = false;

        // when
        ticketRepository.updateValidIfIdDistance(distanceId, valid);

        // then
        assertThat(ticketRepository.findById(6L).get().isValid()).isFalse();
    }

    @Test
    void deleteTicketsOlderThan_should_delete_tickets() {
        // given
        final LocalDate date = LocalDate.of(2020, 10, 1);

        // when
        final int result = ticketRepository.deleteTicketsOlderThan(date);

        // then
        assertThat(result)
                .isEqualTo(7);
    }

    @Test
    void deleteTicketsOfUser_should_delete_tickets() {
        // given
        final long userId = 20L;

        // when
        final int result = ticketRepository.deleteTicketsOfUser(userId);

        // then
        assertThat(result)
                .isEqualTo(14);
    }
}
