package com.infotel.agence.controller.expense;

import com.infotel.agence.domain.expense.dto.GeneratedReportDTO;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.service.expense.IGeneratedReportService;
import com.infotel.agence.service.user.IUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.EXPENSE;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link GeneratedReportController}
 *
 * @author arob
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = GeneratedReportController.class)
class GeneratedReportControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private IUserService userService;

    @MockBean
    private IGeneratedReportService generatedReportService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(EXPENSE);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findAllGeneratedReportList_should_return_list_of_generatedReportDTO() throws Exception {
        GeneratedReportDTO generatedReportDTO = new GeneratedReportDTO();
        given(generatedReportService.findAllList()).willReturn(List.of(generatedReportDTO));

        mockMvc.perform(get("/api/generatedReports/all")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$[0]").value(equalTo(generatedReportDTO), GeneratedReportDTO.class));
    }

    @Test
    void findPdfById_should_return_byteArray() throws Exception {
        mockMvc.perform(get("/api/generatedReports/{id}", 1)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept("application/pdf")
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/pdf"));
    }

    @Test
    void findExcelById_should_return_byteArray() throws Exception {
        mockMvc.perform(get("/api/generatedReports/{id}", 1)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
    }

    @Test
    void findZipById_should_return_byteArray() throws Exception {
        mockMvc.perform(get("/api/generatedReports/{id}", 1)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept("application/zip")
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/zip"));
    }
}
