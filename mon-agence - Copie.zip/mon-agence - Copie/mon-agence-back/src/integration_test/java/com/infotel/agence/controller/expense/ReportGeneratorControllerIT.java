package com.infotel.agence.controller.expense;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotel.agence.domain.expense.dto.TicketStatisticsDTO;
import com.infotel.agence.domain.expense.ticket.TicketCode;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.service.expense.IReportGeneratorService;
import com.infotel.agence.service.expense.ITicketService;
import com.infotel.agence.service.user.IUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;

import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.EXPENSE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.APPLICATION_OCTET_STREAM;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link ReportGeneratorController}
 *
 * @author arob
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = ReportGeneratorController.class)
class ReportGeneratorControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IUserService userService;

    @MockBean
    private IReportGeneratorService reportGeneratorService;

    @MockBean
    private ITicketService ticketService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(EXPENSE);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void getLimitsTest() throws Exception {
        LocalDate olderDate = LocalDate.of(2020, 6, 1);
        LocalDate youngerDate = LocalDate.of(2020, 7, 31);

        Map<String, LocalDate> result = Map.ofEntries(
                new AbstractMap.SimpleEntry<>("olderDate", olderDate),
                new AbstractMap.SimpleEntry<>("youngerDate", youngerDate));

        given(reportGeneratorService.getLimits()).willReturn(result);

        mockMvc.perform(get("/api/reports/limits")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.olderDate").value(olderDate.toString()))
                .andExpect(jsonPath("$.youngerDate").value(youngerDate.toString()));
    }

    @Test
    void statisticsTest() throws Exception {
        LocalDate startDate = LocalDate.of(2020, 6, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 31);

        Map<TicketCode, TicketStatisticsDTO> result = new HashMap<>();
        TicketStatisticsDTO dataStats = new TicketStatisticsDTO(1, BigDecimal.TEN);

        for (TicketCode code : TicketCode.values()) {
            result.put(code, dataStats);
        }

        given(ticketService.statistics(startDate, endDate)).willReturn(result);

        String expectedBody = objectMapper.writeValueAsString(result);
        String resultBody = mockMvc.perform(get("/api/reports?startDate={startDate}&endDate={endDate}", startDate, endDate)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andReturn().getResponse().getContentAsString();

        assertThat(resultBody).isEqualTo(expectedBody);
    }

    @Test
    void generateTest() throws Exception {
        LocalDate startDate = LocalDate.of(2020, 6, 1);
        LocalDate endDate = LocalDate.of(2020, 7, 31);
        int month = 1;
        String filename = "5555_noteFrais_janvier";

        given(reportGeneratorService.getFilename(month)).willReturn(filename);

        mockMvc.perform(get("/api/reports/zip?startDate={startDate}&endDate={endDate}&month={month}", startDate, endDate, month)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_OCTET_STREAM)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_OCTET_STREAM))
                .andExpect(header().string(CONTENT_DISPOSITION,
                        String.format("attachment; filename=\"%s.zip\"", filename)));

        then(reportGeneratorService).should().export(eq(startDate), eq(endDate), eq(filename), eq(month), any(OutputStream.class));
    }
}
