package com.infotel.agence.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.service.user.impl.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static com.infotel.agence.helper.UserTestData.*;
import static com.infotel.agence.security.CustomHttpHeaders.X_AUTHORIZATION;
import static com.infotel.agence.security.SecurityRole.SUPPLY;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link LoginController}
 *
 * @author ARLI
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = LoginController.class)
class LoginControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;

    private User dbUser;

    @BeforeEach
    void setUp() {
        dbUser = getDefaultUserWithRoles(SUPPLY);
        given(userService.loadUserByUsername(dbUser.getUsername())).willReturn(dbUser);
    }

    @Test
    void identifyUser_should_return_connected_user() throws Exception {
        ResultActions resultActions = mockMvc.perform(post("/api/login")
                .header(AUTHORIZATION, getDefaultUserBasicAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(header().string(X_AUTHORIZATION, notNullValue()));

        assertThat(resultActions.andReturn().getResponse().getContentAsString())
                .isEqualTo(objectMapper.writeValueAsString(dbUser));
    }

    @Test
    void identifyUser_should_return_unauthorized_for_wrong_password() throws Exception {
        mockMvc.perform(post("/api/login")
                .header(AUTHORIZATION, getBasicAuth("user", "wrong_password"))
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isUnauthorized())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value("Utilisateur non autorisé"));
    }

    @Test
    void identifyUser_should_return_forbidden_for_wrong_url() throws Exception {
        mockMvc.perform(post("/api/wrong_url")
                .header(AUTHORIZATION, getDefaultUserBasicAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isForbidden())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value("Accès non authorisé"));
    }
}
