package com.infotel.agence.controller.order;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotel.agence.domain.order.Mail;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.service.order.impl.MailService;
import com.infotel.agence.service.user.impl.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.AdditionalAnswers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static com.infotel.agence.domain.order.Mail.builder;
import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.SUPPLY;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.LOCATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link MailController}
 *
 * @author ARLI
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = MailController.class)
class MailControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;

    @MockBean
    private MailService mailService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(SUPPLY);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findMailById_should_return_the_mail() throws Exception {
        long mailId = 1;
        Mail expectedMail = builder().id(mailId).build();
        given(mailService.findById(mailId)).willReturn(expectedMail);

        mockMvc.perform(get("/api/mails/{id}", mailId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(expectedMail), Mail.class));
    }

    @Test
    void findMailById_should_return_404_if_no_match_found() throws Exception {
        String errorMessage = "MESSAGE";
        given(mailService.findById(anyLong())).willThrow(new UnknownEntityException(errorMessage));

        mockMvc.perform(get("/api/mails/{id}", 1)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(errorMessage));
    }

    @Test
    void findAllMails_should_return_list_of_mails() throws Exception {
        Mail mail = builder().id(1L).build();
        given(mailService.findAll()).willReturn(List.of(mail));

        mockMvc.perform(get("/api/mails")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$[0]").value(equalTo(mail), Mail.class));
    }

    @Test
    void createMail_should_create_the_new_mail() throws Exception {
        Mail mail = builder().id(1L).build();
        given(mailService.create(mail)).will(AdditionalAnswers.returnsFirstArg());

        mockMvc.perform(post("/api/mails")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(mail))
                .secure(true))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(header().string(LOCATION, "/api/mails/1"))
                .andExpect(jsonPath("$").value(equalTo(mail), Mail.class));
    }

    @Test
    void updateMail_should_update_the_mail() throws Exception {
        long mailId = 1;
        Mail mail = builder().id(mailId).build();
        given(mailService.update(mail)).will(AdditionalAnswers.returnsFirstArg());

        mockMvc.perform(put("/api/mails/{id}", mailId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(mail))
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(mail), Mail.class));
    }

    @Test
    void deleteMail_should_delete_the_mail() throws Exception {
        long mailId = 1;
        Mail mail = builder().id(mailId).build();
        given(mailService.update(mail)).will(AdditionalAnswers.returnsFirstArg());

        mockMvc.perform(delete("/api/mails/{id}", mailId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .secure(true))
                .andExpect(status().isNoContent())
                .andExpect(jsonPath("$").doesNotExist());
    }
}
