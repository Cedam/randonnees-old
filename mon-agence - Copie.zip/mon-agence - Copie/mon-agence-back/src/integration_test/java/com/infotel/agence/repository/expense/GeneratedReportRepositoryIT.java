package com.infotel.agence.repository.expense;

import com.infotel.agence.domain.expense.dto.GeneratedReportDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ActiveProfiles("test")
@DataJpaTest(showSql = false)
class GeneratedReportRepositoryIT {

    @Autowired
    private GeneratedReportRepository generatedReportRepository;

    @Test
    void findAllGeneratedReportDTO_should_return_generatedReport() {
        // given
        final Long userId = 20L;

        // when
        final List<GeneratedReportDTO> result = generatedReportRepository.findAllGeneratedReportDTO(userId);

        // then
        assertThat(result)
                .isNotNull();
        assertThat(result.size())
                .isEqualTo(1);
    }

    @Test
    void findPdfFileOfId_should_return_pdfFile() {
        // given
        final Long reportId = 1L;

        // when
        final byte[] result = generatedReportRepository.findPdfFileOfId(reportId);

        // then
        assertThat(new String(result)).isEqualTo("pdf");
    }

    @Test
    void findXlsxFileOfId_should_return_xlsxFile() {
        // given
        final Long reportId = 1L;

        // when
        final byte[] result = generatedReportRepository.findXlsxFileOfId(reportId);

        // then
        assertThat(new String(result)).isEqualTo("excel");
    }

    @Test
    void findZipFileOfId_should_return_zipFile() {
        // given
        final Long reportId = 1L;

        // when
        final byte[] result = generatedReportRepository.findZipFileOfId(reportId);

        // then
        assertThat(new String(result)).isEqualTo("zip");
    }

    @Test
    void existsByIdForUserId_should_return_one() {
        // given
        final Long reportId = 1L;
        final Long userId = 20L;

        // when
        final long result = generatedReportRepository.existsByIdForUserId(reportId, userId);

        // then
        assertThat(result).isEqualTo(1);
    }

    @Test
    void deleteGeneratedReportsOlderThan_should_delete_generatedReport() {
        // given
        final LocalDate date = LocalDate.of(2020, 10, 2);

        // when
        final int result = generatedReportRepository.deleteGeneratedReportsOlderThan(date);

        // then
        assertThat(result)
                .isEqualTo(1);
    }
}
