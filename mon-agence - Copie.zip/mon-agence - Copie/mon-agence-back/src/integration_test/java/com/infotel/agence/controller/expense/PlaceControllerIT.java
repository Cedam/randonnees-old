package com.infotel.agence.controller.expense;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotel.agence.domain.expense.Place;
import com.infotel.agence.domain.expense.dto.MergePlacesDTO;
import com.infotel.agence.domain.expense.dto.PlaceDTO;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.service.expense.IPlaceService;
import com.infotel.agence.service.expense.impl.PlaceService;
import com.infotel.agence.service.user.IUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.EXPENSE;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.LOCATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link PlaceController}
 *
 * @author arob
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = PlaceController.class)
class PlaceControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IUserService userService;

    @MockBean
    private IPlaceService placeService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(EXPENSE);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findPlaceById_should_return_place() throws Exception {
        long placeId = 1;
        Place place = Place.builder().id(placeId).build();
        given(placeService.findById(placeId)).willReturn(place);

        mockMvc.perform(get("/api/places/{id}", placeId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(placeId));
    }

    @Test
    void findPlaceById_should_return_404_if_no_match_found() throws Exception {
        long placeId = 1;
        given(placeService.findById(placeId)).willThrow(new UnknownEntityException(PlaceService.UNKNOWN_PLACE));

        mockMvc.perform(get("/api/places/{id}", placeId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(PlaceService.UNKNOWN_PLACE));
    }

    @Test
    void findAllPlacesList_should_return_list_of_places() throws Exception {
        Place place = Place.builder().id(1L).build();
        given(placeService.findAllList()).willReturn(List.of(place));

        mockMvc.perform(get("/api/places/all")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$[0]").value(equalTo(place), Place.class));
    }

    @Test
    void findAllPlacesPage_should_return_page_of_places() throws Exception {
        String getUrl = "/api/places?page={0}" +
                "&size={1}" +
                "&sort={2}";

        // Place renvoyé
        Place resultPlace = Place.builder().id(1L).build();

        // Page renvoyée
        int pageNumber = 0;
        int size = 10;
        String sort = "placeName,ASC";
        Pageable pageable = PageRequest.of(pageNumber, size, Sort.by(Sort.Direction.ASC, "placeName"));
        Page<Place> pageResult = new PageImpl(List.of(resultPlace), pageable, 1);

        // given
        given(placeService.findAllPage(pageable)).willReturn(pageResult);

        mockMvc.perform(get(getUrl, pageNumber, size, sort)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.content[0]").value(equalTo(resultPlace), Place.class));
    }

    @Test
    void createPlace_should_create_the_new_place() throws Exception {
        PlaceDTO placeDTO = new PlaceDTO();
        Place place = Place.builder().id(1L).build();
        given(placeService.create(placeDTO)).willReturn(place);

        String body = objectMapper.writeValueAsString(placeDTO);
        mockMvc.perform(post("/api/places")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(body)
                .secure(true))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(header().string(LOCATION, "/api/places/1"))
                .andExpect(jsonPath("$").value(equalTo(place), Place.class));
    }

    @Test
    void updatePlace_should_update_the_place() throws Exception {
        long placeId = 1;
        PlaceDTO placeDTO = new PlaceDTO();
        Place place = Place.builder().id(placeId).build();
        given(placeService.update(placeId, placeDTO)).willReturn(place);

        String body = objectMapper.writeValueAsString(placeDTO);
        mockMvc.perform(put("/api/places/{id}", placeId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(body)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(place), Place.class));
    }

    @Test
    void mergePlaces_should_merge_the_places() throws Exception {
        long placeIdDelete = 1;
        long placeIdRecipient = 2;
        MergePlacesDTO mergePlacesDTO = new MergePlacesDTO();
        mergePlacesDTO.setPlaceIdDelete(placeIdDelete);
        mergePlacesDTO.setPlaceIdRecipient(placeIdRecipient);

        String body = objectMapper.writeValueAsString(mergePlacesDTO);
        mockMvc.perform(post("/api/places/merge")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(body)
                .secure(true))
                .andExpect(status().isNoContent());
    }
}
