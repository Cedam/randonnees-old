package com.infotel.agence.controller.order;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infotel.agence.domain.order.Article;
import com.infotel.agence.domain.user.User;
import com.infotel.agence.exception.UnknownEntityException;
import com.infotel.agence.service.order.impl.ArticleService;
import com.infotel.agence.service.user.impl.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.AdditionalAnswers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static com.infotel.agence.domain.order.Article.builder;
import static com.infotel.agence.helper.UserTestData.getDefaultUserTokenAuth;
import static com.infotel.agence.helper.UserTestData.getDefaultUserWithRoles;
import static com.infotel.agence.security.SecurityRole.SUPPLY;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.LOCATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Tests d'integration de la classe {@link ArticleController}
 *
 * @author ARLI
 */
@ActiveProfiles("test")
@WebMvcTest(controllers = ArticleController.class)
class ArticleControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;

    @MockBean
    private ArticleService articleService;

    @BeforeEach
    void setUp() {
        User user = getDefaultUserWithRoles(SUPPLY);
        given(userService.loadUserByUsername(user.getUsername())).willReturn(user);
    }

    @Test
    void findArticleById_should_return_the_article() throws Exception {
        long articleId = 1;
        Article expectedArticle = builder().id(articleId).build();
        given(articleService.findById(articleId)).willReturn(expectedArticle);

        mockMvc.perform(get("/api/articles/{id}", articleId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(expectedArticle), Article.class));
    }

    @Test
    void findArticleById_should_return_404_if_no_match_found() throws Exception {
        String errorMessage = "MESSAGE";
        given(articleService.findById(anyLong())).willThrow(new UnknownEntityException(errorMessage));

        mockMvc.perform(get("/api/articles/{id}", 1)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isNotFound())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$.message").value(errorMessage));
    }

    @Test
    void findAllArticles_should_return_list_of_articles() throws Exception {
        Article article = builder().id(1L).build();
        given(articleService.findAll()).willReturn(List.of(article));

        mockMvc.perform(get("/api/articles")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$[0]").value(equalTo(article), Article.class));
    }

    @Test
    void createArticle_should_create_the_new_article() throws Exception {
        Article article = builder().id(1L).build();
        given(articleService.create(article)).will(AdditionalAnswers.returnsFirstArg());

        mockMvc.perform(post("/api/articles")
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(article))
                .secure(true))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(header().string(LOCATION, "/api/articles/1"))
                .andExpect(jsonPath("$").value(equalTo(article), Article.class));
    }

    @Test
    void updateArticle_should_update_the_article() throws Exception {
        long articleId = 1;
        Article article = builder().id(articleId).build();
        given(articleService.update(article)).will(AdditionalAnswers.returnsFirstArg());

        mockMvc.perform(put("/api/articles/{id}", articleId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .accept(APPLICATION_JSON)
                .characterEncoding(StandardCharsets.UTF_8.displayName())
                .contentType(APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(article))
                .secure(true))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andExpect(jsonPath("$").value(equalTo(article), Article.class));
    }

    @Test
    void deleteArticle_should_delete_the_article() throws Exception {
        long articleId = 1;
        Article article = builder().id(articleId).build();
        given(articleService.update(article)).will(AdditionalAnswers.returnsFirstArg());

        mockMvc.perform(delete("/api/articles/{id}", articleId)
                .header(AUTHORIZATION, getDefaultUserTokenAuth())
                .secure(true))
                .andExpect(status().isNoContent())
                .andExpect(jsonPath("$").doesNotExist());
    }
}
