import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App';
import './index.scss';
import { SnackbarProvider } from 'notistack';

const app = <SnackbarProvider maxSnack={3}>
                <App />
            </SnackbarProvider>;

ReactDOM.render(app, document.getElementById('root'));
