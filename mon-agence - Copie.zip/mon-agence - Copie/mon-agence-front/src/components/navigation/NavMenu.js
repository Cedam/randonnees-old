import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import React from 'react';
import {Link} from 'react-router-dom';
import * as styles from './NavMenu.module.scss';
import userStore from '../../store/UserStore';
import {observer} from 'mobx-react';

function NavMenu(props) {
    return (
        <Drawer open={props.open} onClose={() => props.onClose()}>
            <div className={styles.Container}>
                <NavList items={props.items} onClick={() => props.onClose()}/>
            </div>
        </Drawer>
    );
}

const NavList = observer(({items, onClick}) => {
    return (
        <List>
            {
                items.filter(item => userStore.hasAnyRole(item.roles))
                    .map((item, index) => (
                        <NavItem key={item.text} item={item} onClick={onClick} level={0}/>
                    ))
            }
        </List>
    )
})

const NavItem = ({item, onClick, level}) => {

    const itemPaddingLeft = 16 + (level * 16) + "px";

    // Si des sous-menus existent
    if (item.children) {

        let children = [];

        // On crée le NavItem pour chacun de ses sous-menus
        item.children.forEach(child => {
                children.push(<NavItem key={child.text} item={child} onClick={onClick} level={level + 1}/>);
            }
        );

        // On retourne le parent en non cliquable et ses enfants
        return (
            <>
                <ListItem style={{paddingLeft: itemPaddingLeft}}>
                    <ListItemIcon className={styles.Icon}>{item.icon}</ListItemIcon>
                    <ListItemText className={styles.Text} primary={item.text}/>
                </ListItem>
                {children}
            </>
        )
    }
    // Si aucun sous-menus n'existe
    else {
        // On retourne le parent en cliquable
        return (
            <li onClick={() => onClick()}>
                <ListItem button component={Link} to={item.to} style={{paddingLeft: itemPaddingLeft}}>
                    <ListItemIcon className={styles.Icon}>{item.icon}</ListItemIcon>
                    <ListItemText className={styles.Text} primary={item.text}/>
                </ListItem>
            </li>
        )
    }
}

export default NavMenu;
