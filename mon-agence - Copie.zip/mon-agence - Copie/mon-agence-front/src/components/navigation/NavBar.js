import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import MenuIcon from '@material-ui/icons/Menu';
import Paper from '@material-ui/core/Paper';
import MenuList from '@material-ui/core/MenuList';
import MenuItem from '@material-ui/core/MenuItem';
import Popper from '@material-ui/core/Popper';
import Grow from '@material-ui/core/Grow';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import {Link} from 'react-router-dom';
import * as styles from './NavBar.module.scss';
import {observer} from 'mobx-react';
import userStore from '../../store/UserStore';
import authenticationManager from '../../services/AuthenticationManager';


function NavBar(props) {
  return (
    <AppBar position="static">
      <Toolbar variant="dense">
        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          onClick={() => props.onOpenNavMenu()}
        >
          <MenuIcon />
        </IconButton>
        <Typography variant="h6" className={styles.Title}>
          <Link to="/">{props.title}</Link>
        </Typography>
        <ActionMenu onShowLoginDialog={() => props.onShowLoginDialog()} />
      </Toolbar>
    </AppBar>
  );
}

@observer
class ActionMenu extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      open: false
    }
    this.anchorRef = React.createRef();
  }

  handleToggle() {
    this.setState({ open: !this.state.open });
  }

  handleClose() {
    this.setState({ open: false });
  }

  render() {
    const handleBtnClick = userStore.connected ? () => this.handleToggle() : this.props.onShowLoginDialog;
    return (
      <>
        <Button
          ref={this.anchorRef}
          color="inherit"
          onClick={() => handleBtnClick()}
        >
          {userStore.connected ? userStore.fullname : 'S\'identifier'}
        </Button>
        <Popper open={this.state.open} anchorEl={this.anchorRef.current} transition>
          {({ TransitionProps }) => (
            <Grow {...TransitionProps}>
              <Paper>
                <ClickAwayListener onClickAway={() => this.handleClose()}>
                  <MenuList>
                    <li>
                      <MenuItem component={Link} to="/myProfile" onClick={() => this.handleClose()}>
                        Mon profil
                      </MenuItem>
                    </li>
                    <li>
                      <MenuItem component={Link} to="/" onClick={() => {
                        this.handleClose();
                        authenticationManager.logout();
                      }}>
                        Déconnexion
                      </MenuItem>
                    </li>
                  </MenuList>
                </ClickAwayListener>
              </Paper>
            </Grow>
          )}
        </Popper>
      </>
    );
  }
}

export default NavBar;
