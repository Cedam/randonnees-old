import {
    Archive as ArchiveIcon,
    Euro as EuroIcon,
    Grain as GrainIcon,
    Help as HelpIcon,
    Home as HomeIcon,
    Info as InfoIcon,
    SupervisorAccount as AdminIcon
} from '@material-ui/icons';
import React from 'react';
import {BrowserRouter, Redirect, Route, Switch} from 'react-router-dom';
import Home from '../pages/home/Home';
import About from '../pages/about/About';
import Help from '../pages/help/Help';
import Admin from '../pages/admin/Admin';
import MyProfile from '../pages/myProfile/MyProfile';
import LoginDialog from './authentication/LoginDialog';
import NavBar from './navigation/NavBar';
import NavMenu from './navigation/NavMenu';
import {configure} from 'mobx';
// following import is required by mobx-react
import {observer} from 'mobx-react';
import userStore from '../store/UserStore';

import TicketsManager from '../pages/expense/ExpenseManager/TicketsManager';
import ExpenseGenerator from "../pages/expense/ExpenseGenerator/ExpenseGenerator";
import Notifier from "./Notifier";
import {SnackbarProvider} from "notistack";
import ExpenseArchive from "../pages/expense/ExpenseArchive/ExpenseArchive";

class App extends React.Component {
    constructor(props) {
        super(props);

        this.navItems = [
            {text: 'Accueil', icon: <HomeIcon/>, to: '/', roles: []},
            {
                text: 'Administration',
                icon: <AdminIcon/>,
                to: '/admin',
                roles: ["ROLE_ADMIN", "ROLE_ADMIN_SUPPLY", "ROLE_ADMIN_EXPENSE"]
            },
            {
                text: 'Mes notes de frais', icon: <EuroIcon/>, roles: ['ROLE_EXPENSE'],
                children: [
                    {text: 'Mes tickets', icon: <GrainIcon/>, to: '/expenseManager'},
                    {text: 'Historique', icon: <ArchiveIcon/>, to: '/expenseArchive'}
                ]
            },
            {text: 'Aide', icon: <HelpIcon/>, to: '/help', roles: []},
            {text: 'À propos', icon: <InfoIcon/>, to: '/about', roles: []}
        ];
        this.state = {
            isMenuOpen: false,
            isLoginDialogOpen: false
        };
    }

    handleMenu(isOpen) {
        this.setState({isMenuOpen: isOpen});
    }

    handleLoginDialog(isOpen) {
        this.setState({isLoginDialogOpen: isOpen});
    }

    render() {
        return (
            <>
                <SnackbarProvider maxSnack={5}>
                    <Notifier/>
                </SnackbarProvider>
                <BrowserRouter basename={process.env.PUBLIC_URL}>
                    <NavBar
                        title="Mon Agence"
                        onOpenNavMenu={() => this.handleMenu(true)}
                        onShowLoginDialog={() => this.handleLoginDialog(true)}
                    />
                    <NavMenu
                        items={this.navItems}
                        open={this.state.isMenuOpen}
                        onClose={() => this.handleMenu(false)}
                    />
                    <LoginDialog
                        open={this.state.isLoginDialogOpen}
                        onClose={() => this.handleLoginDialog(false)}
                    />
                    <Switch>
                        <Route exact path="/" render={Home}/>

                        <PrivateRoute path="/admin" roles={["ROLE_ADMIN", "ROLE_ADMIN_SUPPLY", "ROLE_ADMIN_EXPENSE"]}>
                            <Admin/>
                        </PrivateRoute>

                        <PrivateRoute path="/myProfile" roles={[]}>
                            <MyProfile/>
                        </PrivateRoute>

                        <Route path="/help" render={Help}/>

                        <Route path="/about" render={About}/>

                        <PrivateRoute path="/expenseManager" roles={["ROLE_EXPENSE"]}>
                            <TicketsManager/>
                        </PrivateRoute>

                        <PrivateRoute path="/expenseGenerator" roles={["ROLE_EXPENSE"]}>
                            <ExpenseGenerator/>
                        </PrivateRoute>

                        <PrivateRoute path="/expenseArchive" roles={["ROLE_EXPENSE"]}>
                            <ExpenseArchive/>
                        </PrivateRoute>

                        <Route render={NotFound}/>

                    </Switch>
                </BrowserRouter>
            </>
        );
    }
}

/**
 * Cette fonction renvoie une route vers l'enfant donné si UN des roles donnés en paramètre est possédé
 * par l'utilisateur connecté.
 *
 * @type {function({children: *, [p: string]: *}): JSX.Element}
 */
const PrivateRoute = observer(({children, ...rest}) => {
    const isAuthorized = userStore.connected && (rest.roles.length > 0 ? userStore.hasAnyRole(rest.roles) : true);
    return (
        <Route
            {...rest}
            render={({location}) =>
                isAuthorized ? (
                    children
                ) : (
                    <NotFound/>
                )
            }
        />
    )
});

function NotFound() {
    return <Redirect to="/"/>;
}

// configuration for mobx
configure({
    enforceActions: 'observed',
    computedRequiresReaction: true,
    observableRequiresReaction: true,
    reactionRequiresObservable: true
})

export default App;
