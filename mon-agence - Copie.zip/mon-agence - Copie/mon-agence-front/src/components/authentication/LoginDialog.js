import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import Checkbox from '@material-ui/core/Checkbox';
import Container from '@material-ui/core/Container';
import Dialog from '@material-ui/core/Dialog';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import React from 'react';
import authenticationManager from '../../services/AuthenticationManager';
import * as styles from './LoginDialog.module.scss';

function LoginDialog(props) {
  return (
    <Dialog onClose={() => props.onClose()} open={props.open}>
      <Container maxWidth="xs" className={styles.LoginContainer}>
        <Avatar>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          S'identifier
        </Typography>
        <LoginForm onConnectedUser={() => props.onClose()} />
      </Container>
    </Dialog>
  );
}

class LoginForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = { username: '', password: '', remember: false };
  }

  updateUsername(event) {
    this.setState({ username: event.target.value });
  }

  updatePassword(event) {
    this.setState({ password: event.target.value });
  }

  updateRemember(event) {
    this.setState({ remember: event.target.checked });
  }

  handleSubmit(event) {
    event.preventDefault();

    if (isValidForm(this.state.username, this.state.password)) {
      authenticationManager.authenticate(
        this.state.username,
        this.state.password,
        this.state.remember
      )
        .then(() => {
          this.props.onConnectedUser();
        })
        .catch(() => {
          this.setState({ password: '' });
        });
    }
  }

  render() {
    return (
      <form noValidate onSubmit={e => this.handleSubmit(e)}>
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          label="Nom d'utilisateur"
          autoFocus
          value={this.state.username}
          onChange={e => this.updateUsername(e)}
        />
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          label="Mot de passe"
          type="password"
          value={this.state.password}
          onChange={e => this.updatePassword(e)}
        />
        <FormControlLabel
          control={
            <Checkbox
              color="primary"
              checked={this.state.remember}
              onChange={e => this.updateRemember(e)}
            />
          }
          label="Rester connecté"
        />
        <Button
          type="submit"
          fullWidth
          variant="contained"
          color="primary"
          className={styles.SubmitButton}
        >
          Connexion
        </Button>
        {/* <Link href="#" variant="body2">
          Mot de passe oublié?
        </Link> */}
      </form>
    );
  }
}

function isValidForm(username, password) {
  return username.length > 0 && password.length > 0;
}

export default LoginDialog;
