import {URL_EMPLOYEE_IDENTITY} from '../pages/expense/constants';
import httpClient from './HttpClient'
import snackbarStore from "../store/SnackbarStore";

/**
 * Fonction permettant d'effectuer des appels axios vers le back pour la fonction traitant les idéntités d'employés.
 */
class EmployeeIdentityService {
    /**
     * Permets de récuperer les informations liés à l'identité d'un employé selon un id.
     * @param handleUserMileageAllowanceChange
     */
    static getEmployeeIdentity = (handleUserMileageAllowanceChange) => {
        httpClient.get(URL_EMPLOYEE_IDENTITY)
            .then(function (response) {
                handleUserMileageAllowanceChange(response.data.compensation.mileageAllowance);
            })
            .catch(function (error) {
                handleUserMileageAllowanceChange(-1);
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de vos informations employée");
                console.log(error);
            })
    }
}

export default EmployeeIdentityService;
