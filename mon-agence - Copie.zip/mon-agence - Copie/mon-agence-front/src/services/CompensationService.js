import httpClient from './HttpClient';
import {URL_COMPENSATIONS} from '../pages/expense/constants';
import snackbarStore from "../store/SnackbarStore";

/**
 * Ensemble de fonctions permettant d'effectuer les appels axios vers le back pour les fonctions traitant les compensations.
 */
class CompensationService {
    /**
     * Permets de récuperer une page contenant des indemnités kilométriques.
     * @param page
     * @param rowsPerPage
     * @param order
     * @param orderBy
     * @param updateAllCompensationsAndPagination
     */
    static getPageCompensations = (page, rowsPerPage, order, orderBy, updateAllCompensationsAndPagination) => {
        const getUrl = URL_COMPENSATIONS + "?page=" + page
            + "&size=" + rowsPerPage
            + "&sort=" + orderBy + "," + order;

        httpClient.get(getUrl)
            .then(function (response) {
                updateAllCompensationsAndPagination(response.data.content, response.data.totalElements);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la page de compensation.");
                updateAllCompensationsAndPagination([], 0);
            });
    }

    /**
     * Permets de récuperer la liste de toutes les indemnités kilométriques.
     * @param updateAllCompensations
     */
    static getListCompensations = (updateAllCompensations) => {
        const getUrl = URL_COMPENSATIONS + "/all";

        httpClient.get(getUrl)
            .then(function (response) {
                updateAllCompensations(response.data);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la liste de compensations.");
                updateAllCompensations([]);
            });
    }

    /**
     * Permets d'ajouter une indemnités kilométrique.
     * @param cv
     * @param mileageAllowance
     * @param doUpdate
     * @param handleDialogClose
     */
    static addCompensation = (cv, mileageAllowance, doUpdate, handleDialogClose) => {
        httpClient.post(URL_COMPENSATIONS, {
            cv: cv,
            mileageAllowance: mileageAllowance
        }).then(function (response) {
            doUpdate();
            snackbarStore.addSnackbarSuccess("Ajout de votre compensation réussi.");
            handleDialogClose();
        }).catch(function (error) {
            snackbarStore.addSnackbarError("Erreur rencontrée lors de l'ajout de votre compensation.");
        });
    }

    /**
     * Permets de récuperer une indemnité kilométrique selon un id.
     * @param compensationId
     * @param handleInitData
     */
    static getCompensationById = (compensationId, handleInitData) => {
        const getUrl = URL_COMPENSATIONS + "/" + compensationId;

        httpClient.get(getUrl)
            .then(function (response) {
                handleInitData(response.data.cv, response.data.mileageAllowance);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la compensation selectionnée.");
            });
    }

    /**
     * Permets de mettre à jour toutes les données d'une indemnités kilométrique.
     * @param compensationId
     * @param cv
     * @param mileageAllowance
     * @param doUpdate
     * @param toggleIsEditable
     * @param handleModalCompensationDetailsId
     */
    static updateCompensation = (compensationId, cv, mileageAllowance, doUpdate, toggleIsEditable, handleModalCompensationDetailsId) => {
        const putUrl = URL_COMPENSATIONS + "/" + compensationId;

        httpClient.put(putUrl, {
            cv: cv,
            mileageAllowance: mileageAllowance
        })
            .then(function (response) {
                toggleIsEditable();
                doUpdate();
                snackbarStore.addSnackbarSuccess("Mise à jour de votre compensation réussie.");
            })
            .catch(function (error) {
                toggleIsEditable();
                doUpdate();
                handleModalCompensationDetailsId(-1);
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la mise à jour de votre compensation.");
            });
    }
}

export default CompensationService;