import httpClient from './HttpClient';
import {URL_DISTANCES} from '../pages/expense/constants';
import snackbarStore from "../store/SnackbarStore";

/**
 * Ensemble de fonctions permettant d'effectuer les appels axios vers le back pour les fonctions traitant les distances.
 */
class DistanceService {
    /**
     * Permets de récuperer une page contenant des distances.
     * @param page
     * @param rowsPerPage
     * @param order
     * @param orderBy
     * @param updateAllDistancesAndPagination
     */
    static getAllDistances = (page, rowsPerPage, order, orderBy, updateAllDistancesAndPagination) => {
        const getUrl = URL_DISTANCES + "?page=" + page
            + "&size=" + rowsPerPage
            + "&sort=" + orderBy + "," + order;

        httpClient.get(getUrl)
            .then(function (response) {
                updateAllDistancesAndPagination(response.data.content, response.data.totalElements);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la liste des distances.");
                updateAllDistancesAndPagination([], 0);
            });
    }

    /**
     * Permets de récuperer la distance entre deux places selon leur id.
     * @param placeA
     * @param placeB
     * @param handleDistanceExistChange
     * @param handleMileageChange
     */
    static getDistanceByPlaces = (placeA, placeB, handleDistanceExistChange, handleMileageChange) => {
        const getUrl = URL_DISTANCES + "/byPlacesId?idPlaceA=" + placeA
            + "&idPlaceB=" + placeB;

        httpClient.get(getUrl)
            .then(function (response) {
                handleDistanceExistChange(true);
                handleMileageChange({"target": {"value": response.data.value}});
            })
            .catch(function (error) {
                handleDistanceExistChange(false);
                handleMileageChange({"target": {"value": 0}});
            });
    }

    /**
     * Permets d'ajouter une distance entre deux places
     * @param placeStartData
     * @param placeEndData
     * @param mileage
     * @param doUpdate
     * @param handleDialogClose
     */
    static addDistance = (placeStartData, placeEndData, mileage, doUpdate, handleDialogClose) => {
        httpClient.post(URL_DISTANCES, {
            placeStart: {id: placeStartData.id},
            placeEnd: {id: placeEndData.id},
            value: mileage
        }).then(function (response) {
            doUpdate();
            snackbarStore.addSnackbarSuccess("Ajout de votre distance réussi.");
            handleDialogClose();
        }).catch(function (error) {
            snackbarStore.addSnackbarError("Erreur rencontrée lors de l'ajout de votre distance");
        })
    }

    /**
     * Permets de récuperer les informations liées à une distance selon son id.
     * @param distanceId
     * @param handleDistanceInit
     */
    static getDistanceById = (distanceId, handleDistanceInit) => {
        const getUrl = URL_DISTANCES + "/" + distanceId;

        httpClient.get(getUrl)
            .then(function (response) {
                handleDistanceInit(response.data.placeStart, response.data.placeEnd, response.data.value);
                // handleDistanceInit(response);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la distance selectionnée.");
            });
    }

    /**
     * Permets de mettre à jour toutes les informations liées à une distance.
     * @param distanceId
     * @param placeStartData
     * @param placeEndData
     * @param mileage
     * @param doUpdate
     * @param toggleIsEditable
     * @param handleModalDistanceDetailsId
     */
    static updateDistance = (distanceId, placeStartData, placeEndData, mileage, doUpdate, toggleIsEditable, handleModalDistanceDetailsId) => {

        const putUrl = URL_DISTANCES + "/" + distanceId;

        httpClient.put(putUrl, {
            id: distanceId,
            placeStart: {id: placeStartData.id},
            placeEnd: {id: placeEndData.id},
            value: mileage
        })
            .then(function (response) {
                toggleIsEditable();
                doUpdate();
                snackbarStore.addSnackbarSuccess("Mise à jour de la distance réussie.");
            })
            .catch(function (error) {
                toggleIsEditable();
                doUpdate();
                handleModalDistanceDetailsId(-1);
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la mise à jour de la distance");
            });
    }
}

export default DistanceService;
