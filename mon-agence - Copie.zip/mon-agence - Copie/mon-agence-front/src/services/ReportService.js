import {URL_REPORT} from '../pages/expense/constants';
import httpClient from './HttpClient'
import snackbarStore from "../store/SnackbarStore";
import moment from "moment";

/**
 * Ensemble de fonctions permettant d'effectuer les appels axios vers le back pour les fonctions traitant de la génération de compte-rendus.
 */
class ReportService {
    /**
     * Permets de récuperer les statistiques des tickets validés et non archivés pour une période de temps donnée.
     * @param selectedStartDate
     * @param selectedEndDate
     * @param handleStatsTicketsChange
     */
    static getStatsTickets = (selectedStartDate, selectedEndDate, handleStatsTicketsChange) => {

        const getUrl = URL_REPORT + "?startDate=" + selectedStartDate
            + "&endDate=" + selectedEndDate;

        httpClient.get(getUrl)
            .then(function (response) {
                handleStatsTicketsChange(response.data);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération des statistiques liées aux tickets validés.");
                handleStatsTicketsChange([]);
            });
    };

    /**
     * Permets de récuperer la limites de tickets validés et non archivés puis les statistiques des tickets validés et non archivés pour cette
     * limite de temps donnée.
     *
     * @param selectedStartDate
     * @param selectedEndDate
     * @param handleInitialisation
     */
    static getInitialStatsTickets = (selectedStartDate, selectedEndDate, handleInitialisation) => {

        const getUrlLimit = URL_REPORT + "/limits";

        httpClient.get(getUrlLimit)
            .then(function (limitResponse) {
                let realStartDate = selectedStartDate;
                let realEndDate = selectedEndDate;

                // MAJ de la date de début
                if (moment().startOf('month').isSameOrAfter(moment(limitResponse.data.olderDate, 'YYYY-MM-DD'))) {
                    realStartDate = limitResponse.data.olderDate;
                }

                // MAJ de la date de fin si présent après la fin du mois
                if (moment().endOf('month').isSameOrBefore(moment(limitResponse.data.youngerDate, 'YYYY-MM-DD'))) {
                    realEndDate = limitResponse.data.youngerDate;
                }

                const getUrlReport = URL_REPORT + "?startDate=" + realStartDate
                    + "&endDate=" + realEndDate;

                httpClient.get(getUrlReport)
                    .then(function (reportResponse) {
                        handleInitialisation(realStartDate, realEndDate, reportResponse.data);
                    })
                    .catch(function (error) {
                        snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération des statistiques liées aux tickets validés.");
                        handleInitialisation(realStartDate, realEndDate, []);
                    });

            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la limite des tickets validés.");
            })


    };

    /**
     * Permets de lancer la récupération et l'enregistrement du rapport final.
     * @param selectedStartDate
     * @param selectedEndDate
     * @param monthSelected
     * @param callback
     */
    static getReport = (selectedStartDate, selectedEndDate, monthSelected, callback) => {

        const getUrl = URL_REPORT + "/zip?startDate=" + selectedStartDate
            + "&endDate=" + selectedEndDate
            + "&month=" + monthSelected;

        httpClient.get(getUrl,
            {
                'headers': {'Accept': 'application/octet-stream'},
                'responseType': 'blob' // Permet de préciser au serveur de nous renvoyer l'excel sous format blob
            }
        )
            .then(function (response) {

                // const blob = new Blob([response.data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                const blob = new Blob([response.data], {type: 'application/zip'});

                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                // Hide the new link
                link.style.cssText = 'visibility:hidden';

                // Get the file name in the content-disposition header
                link.download = response.headers["content-disposition"].toString().slice(22, -1);

                link.target = "_blank";

                // Add the link to the DOM, simulate click on it and finally delete it
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);

                callback();

            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération du fichier de compte rendu.");
            });
    };
}

export default ReportService;