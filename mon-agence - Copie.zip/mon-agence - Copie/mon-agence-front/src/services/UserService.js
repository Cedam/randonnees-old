import httpClient from "./HttpClient";
import snackbarStore from "../store/SnackbarStore";

/**
 * Ensemble de fonctions permettant d'effectuer les appels axios vers le back pour les fonctions traitant les users.
 */
class UserService {

    /**
     * Permets de récuperer une page de users selon des filtres précis.
     * @param page
     * @param rowsPerPage
     * @param orderBy
     * @param order
     * @param updateAllUsersAndPagination
     */
    static getAllUsers = (page, rowsPerPage, orderBy, order, updateAllUsersAndPagination) => {
        const getUrl = "/users?page=" + page
            + "&size=" + rowsPerPage
            + "&sort=" + orderBy + "," + order;

        httpClient.get(getUrl)
            .then(function (response) {
                updateAllUsersAndPagination(response.data.content, response.data.totalElements);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur lors de la récupération de la liste des utilisateurs");
            })
    }

    /**
     * Fonction permettant de récuperer les informations relatives à un utilisateur selon un id donné.
     * @param userId
     * @param handleInitUser
     */
    static getUserById = (userId, handleInitUser) => {
        const getUrl = "/users/" + userId;

        httpClient.get(getUrl)
            .then(function (response) {
                handleInitUser(response.data);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur lors de la récupération des informations liées à l'utilisateur.");
            })
    }

    static deleteUserById = (userId, handleDeleteDialogIsOpen, handleModalUserDetailsId, doUpdate) => {
        const delUrl = "/users/" + userId;

        httpClient.delete(delUrl)
            .then(function (response) {
                doUpdate();
                handleDeleteDialogIsOpen(false);
                handleModalUserDetailsId(-1);
                snackbarStore.addSnackbarSuccess("Suppression de l'utilisateur réussit.");
            })
            .catch(function (error) {
                doUpdate();
                handleDeleteDialogIsOpen(false);
                handleModalUserDetailsId(-1);
                snackbarStore.addSnackbarError("Erreur lors de la suppression de l'utilisateur.");
            })
    }
}

export default UserService;