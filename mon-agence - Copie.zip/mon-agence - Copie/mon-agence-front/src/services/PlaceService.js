import {URL_PLACES} from '../pages/expense/constants';
import httpClient from './HttpClient'
import snackbarStore from "../store/SnackbarStore";

/**
 * Ensemble de fonctions permettant d'effectuer les appels axios vers le back pour les fonctions traitant les places.
 */
class PlaceService {
    /**
     * Permets de récupérer une liste de toutes les places.
     * @param handleAllPlacesChange
     */
    static getAllPlacesList = (handleAllPlacesChange) => {
        const getUrl = URL_PLACES + "/all";

        httpClient.get(getUrl)
            .then(function (response) {
                handleAllPlacesChange(response.data);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la liste des places.");
            });
    }

    /**
     * Permets de récuperer une page contenant des places.
     * @param page
     * @param rowsPerPage
     * @param order
     * @param orderBy
     * @param updateAllPlacesAndPagination
     */
    static getAllPlacesPage = (page, rowsPerPage, order, orderBy, updateAllPlacesAndPagination) => {
        const getUrl = URL_PLACES + "?page=" + page
            + "&size=" + rowsPerPage
            + "&sort=" + orderBy + "," + order;

        httpClient.get(getUrl)
            .then(function (response) {
                updateAllPlacesAndPagination(response.data.content, response.data.totalElements);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la page des places.");
                updateAllPlacesAndPagination([], 0);
            });
    }

    /**
     * Permets l'ajout d'une place.
     * @param placeName
     * @param handleAddPlaceDialogIsOpen
     * @param doUpdate
     */
    static addPlace = (placeName, handleAddPlaceDialogIsOpen, doUpdate) => {

        httpClient.post(URL_PLACES, {
            name: placeName,
        })
            .then(function (response) {
                // SI l'ajout c'est bien effectué,
                // je demande la MAJ de la liste des places
                doUpdate()

                // snackbar success
                snackbarStore.addSnackbarSuccess("Ajout de votre place réussi.");

                // fermeture du dialog d'ajout
                handleAddPlaceDialogIsOpen(false);

            })
            .catch(function (error) {
                // snackbar error
                snackbarStore.addSnackbarError("Erreur rencontrée lors de l'ajout de votre place.");

                // fermeture du dialog d'ajout
                handleAddPlaceDialogIsOpen(false);
            });
    }

    /**
     * Permets la récupération des informations liées à une place selon son id.
     * @param placeId
     * @param handlePlaceNameChange
     */
    static getPlaceById = (placeId, handlePlaceNameChange) => {
        const getUrl = URL_PLACES + "/" + placeId;

        httpClient.get(getUrl)
            .then(function (response) {
                handlePlaceNameChange(response.data.name);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la place selectionnée.");
            });
    }

    /**
     * Permets de mettre à jour toutes les informations liées à une place.
     * @param placeId
     * @param placeName
     * @param doUpdate
     * @param toggleIsEditable
     * @param handleModalPlaceDetailsId
     */
    static updatePlace = (placeId, placeName, doUpdate, toggleIsEditable, handleModalPlaceDetailsId) => {
        const putUrl = URL_PLACES + "/" + placeId;

        httpClient.put(putUrl, {
            name: placeName
        })
            .then(function (response) {
                toggleIsEditable();
                doUpdate();
                snackbarStore.addSnackbarSuccess("Mise à jour de la place réussie.");
            })
            .catch(function (error) {
                toggleIsEditable();
                doUpdate();
                handleModalPlaceDetailsId(-1);
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la mise à jour de la place.");
            });
    }

    /**
     * Permets de fussioner une place (ayant l'id placeIdDelete) sur une autre (ayant l'id placeIdRecipient).
     * @param placeIdDelete l'id de la place qui sera supprimée
     * @param placeIdRecipient l'id de la place qui recoit la fusion
     * @param handleMergePlacesDialogIsOpen fonction permettant l'ouverture ou la fermeture du dialog de fusion de places
     * @param doUpdate fonction permettant la MAJ de la liste des places
     */
    static mergePlace = (placeIdDelete, placeIdRecipient, handleMergePlacesDialogIsOpen, doUpdate) => {
        httpClient.post(URL_PLACES + "/merge", {
            placeIdDelete: placeIdDelete,
            placeIdRecipient: placeIdRecipient
        })
            .then(function (response) {
                // SI le merge c'est bien effectué,
                // je demande la MAJ de la liste des places
                doUpdate();

                // snackbar success
                snackbarStore.addSnackbarSuccess("Fusion de vos places réussie.");

                // fermeture du dialog de fusion
                handleMergePlacesDialogIsOpen(false);

            })
            .catch(function (error) {
                // snackbar error
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la fusion de vos places.");

                // fermeture du dialog de fusion
                handleMergePlacesDialogIsOpen(false);
            });
    }
}

export default PlaceService;
