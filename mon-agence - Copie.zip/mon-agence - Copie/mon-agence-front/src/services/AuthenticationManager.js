import userStore from '../store/UserStore';
import httpClient, {handleError} from './HttpClient'

const ACCESS_TOKEN = 'ACCESS_TOKEN';
const REFRESH_TOKEN = 'REFRESH_TOKEN'

/**
 * Gestion de l'authentification des utilisateurs
 */
class AuthenticationManager {

  constructor() {
    this._restoreAuthentication();
  }

  /**
   * Permet l'authentification d'un utilisateur à partir de son login/mot de passe.
   * @param username
   * @param password
   * @param remember
   * @returns {Promise}
   */
  authenticate(username, password, remember) {
    const requestConfig = {
      url: '/login',
      method: 'POST',
      auth: {
        username: username,
        password: password
      }
    };

    return httpClient.request(requestConfig)
      .then(response => this._handleAuthentication(response))
      .then(user => userStore.setUser(user))
      .catch(handleError);
  }

  /**
   * Déconnecte l'utilisateur courant.
   */
  logout() {
    userStore.reset();
    this._clearAuthentication();
  }

  /**
   * Récupère le token d'accès et le token de refresh depuis la réponse et stocke ces derniers dans le local storage.
   * Le token d'accès est ajouté dans le header Authorization pour les futures requêtes HTTP.
   * @param response
   */
  _handleAuthentication(response) {
    const accessToken = response.headers['x-authorization'];
    const refreshToken = response.headers['x-refresh'];

    if (accessToken && refreshToken) {
      localStorage.setItem(ACCESS_TOKEN, accessToken);
      localStorage.setItem(REFRESH_TOKEN, refreshToken);
      this._setAccessToken(accessToken);
    }
    return response.data;
  }

  /**
   * Supprime les données d'authentification.
   */
  _clearAuthentication() {
    localStorage.removeItem(ACCESS_TOKEN);
    localStorage.removeItem(REFRESH_TOKEN);
    this._setAccessToken();
  }

  /**
   * Récupère le token d'accès depuis le local storage si celui-ci existe,
   * et l'ajoute dans le header Authorization pour les futures requêtes HTTP.
   */
  _restoreAuthentication() {
    this._setAccessToken(localStorage.getItem(ACCESS_TOKEN));
  }

  /**
   * Configure/supprime le header Authorization avec le token d'accès pour toutes les requètes HTTP.
   * @param accessToken
   */
  _setAccessToken(accessToken) {
    if (accessToken) {
      httpClient.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`;
    } else {
      delete httpClient.defaults.headers.common['Authorization'];
    }
  }
}

const authenticationManager = new AuthenticationManager();
export default authenticationManager;