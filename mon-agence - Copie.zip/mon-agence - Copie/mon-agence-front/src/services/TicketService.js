import {URL_DISTANCES, URL_TICKETS} from '../pages/expense/constants';
import httpClient from './HttpClient';
import moment from "moment";
import snackbarStore from "../store/SnackbarStore";

/**
 * Ensemble de fonctions permettant d'effectuer les appels axios vers le back pour les fonctions traitant les services.
 */
class TicketService {
    /**
     * Permets de récuperer les informations liées aux types de tickets existants.
     * @param handleAllTicketsCodeChange
     */
    static getAllTicketsCode = (handleAllTicketsCodeChange) => {
        const getAllTicketCodeUrl = URL_TICKETS + "/allCodes";

        httpClient.get(getAllTicketCodeUrl)
            .then(function (response) {
                handleAllTicketsCodeChange(response.data);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la liste des codes de ticket.");
            });
    }

    /**
     * Permets d'initialisation le composant tableau gérant l'affichage d'une page de tickets.
     * @param page
     * @param rowsPerPage
     * @param order
     * @param orderBy
     * @param ticketTypeCode
     * @param showArchived
     * @param selectedStartDate
     * @param selectedEndDate
     * @param handleInitialisation
     */
    static getInitialTickets = (page, rowsPerPage, order, orderBy, ticketTypeCode, showArchived, selectedStartDate, selectedEndDate,
                                handleInitialisation) => {
        const getLimitsUrl = URL_TICKETS + "/limits";

        httpClient.get(getLimitsUrl)
            .then(function (response) {
                let realStartDate = selectedStartDate;
                let realEndDate = selectedEndDate;

                // MAJ de la date de début
                if (moment().startOf('month').isSameOrAfter(moment(response.data.olderDate, 'YYYY-MM-DD'))) {
                    realStartDate = response.data.olderDate;
                }

                // MAJ de la date de fin si présent après la fin du mois
                if (moment().endOf('month').isSameOrBefore(moment(response.data.youngerDate, 'YYYY-MM-DD'))) {
                    realEndDate = response.data.youngerDate;
                }

                const getTicketsUrl = URL_TICKETS + "?page=" + page
                    + "&size=" + rowsPerPage
                    + "&ticketCode=" + ticketTypeCode
                    + "&sort=" + orderBy + "," + order
                    + "&startDate=" + realStartDate
                    + "&endDate=" + realEndDate
                    + "&isArchived=" + showArchived;

                httpClient.get(getTicketsUrl)
                    .then(function (responseTickets) {
                        handleInitialisation(realStartDate, realEndDate, responseTickets.data.content, responseTickets.data.totalElements);
                    })
                    .catch(function (error) {
                        snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération initiale des tickets.");
                        handleInitialisation(realStartDate, realEndDate, [], 0);
                    });
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la limite des tickets.");
                return null;
            });
    };

    /**
     * Permets de récuperer une page de tickets selon des filtres précis.
     * @param page
     * @param rowsPerPage
     * @param order
     * @param orderBy
     * @param ticketTypeCode
     * @param showArchived
     * @param selectedStartDate
     * @param selectedEndDate
     * @param updateAllTicketsAndPagination
     */
    static getAllTickets = (page, rowsPerPage, order, orderBy, ticketTypeCode, showArchived,
                            selectedStartDate, selectedEndDate, updateAllTicketsAndPagination) => {

        const getUrl = URL_TICKETS + "?page=" + page
            + "&size=" + rowsPerPage
            + "&ticketCode=" + ticketTypeCode
            + "&sort=" + orderBy + "," + order
            + "&startDate=" + selectedStartDate
            + "&endDate=" + selectedEndDate
            + "&isArchived=" + showArchived;

        httpClient.get(getUrl)
            .then(function (response) {
                updateAllTicketsAndPagination(response.data.content, response.data.totalElements);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la page des tickets filtrés.");
                updateAllTicketsAndPagination([], 0);
            });
    };

    /**
     * Permets de récuperer la liste des tickets necessitant une validation.
     * @param handleAllTicketsChange
     * @param handleVerifyDialogIsOpen
     */
    static getAllTicketsToVerify = (handleAllTicketsChange, handleVerifyDialogIsOpen) => {
        const getUrl = URL_TICKETS + "/toVerify";

        httpClient.get(getUrl)
            .then(function (response) {
                handleAllTicketsChange(response.data);

                if (response.data.length === 0) {
                    snackbarStore.addSnackbarInfo("Aucun ticket ne nécessite actuellement une validation.");
                    handleVerifyDialogIsOpen(false);
                }
            })
            .catch(function (error) {
                handleAllTicketsChange([]);
                snackbarStore.addSnackbarError("Erreur rencontrée de la récupération de la liste des tickets à valider.");
                handleVerifyDialogIsOpen(false);
            });
    }

    /**
     * Permet d'effectuer l'ajout d'un ticket.
     * Est appelée par addNewTicket(...).
     * @param ticketTypeCode
     * @param date
     * @param receiptPicture
     * @param customer
     * @param employeeAmount
     * @param vehicle
     * @param purpose
     * @param siteOrMeeting
     * @param bedroomAmount
     * @param breakfastAmount
     * @param lunchAmount
     * @param dinnerAmount
     * @param placeStartData
     * @param placeEndData
     * @param isRoundTrip
     * @param handleStartDateChange
     * @param handleEndDateChange
     * @param selectedStartDate
     * @param selectedEndDate
     * @param handleUpdateForMajNeeded
     */
    static _postNewTicket = (ticketTypeCode, date, receiptPicture, customer, employeeAmount, vehicle, purpose, siteOrMeeting, bedroomAmount,
                             breakfastAmount, lunchAmount, dinnerAmount, placeStartData, placeEndData, isRoundTrip,
                             handleStartDateChange, handleEndDateChange, selectedStartDate, selectedEndDate, handleUpdateForMajNeeded) => {

        let valid = false;
        // Si le ticket concerne un frais de déplacement exceptionnal on le valide de base, sinon on ne le valide pas
        if (ticketTypeCode === "EXCEPTIONAL_BUSINESS_TRAVEL") {
            valid = true;
        }

        // Initialisation du formData pour envoyer les informations dans la requete
        const formData = new FormData();

        // Création d'un ticketDTO contenant toutes ses informations
        const ticketDTO = {
            code: ticketTypeCode,
            date: date,
            receiptPicture: null,
            valid: valid,
            customer: customer,
            employeeAmount: employeeAmount,
            vehicle: vehicle,
            purpose: purpose,
            siteOrMeeting: siteOrMeeting,
            bedroomAmount: bedroomAmount,
            breakfastAmount: breakfastAmount,
            lunchAmount: lunchAmount,
            dinnerAmount: dinnerAmount,
            startPlace: {id: (placeStartData !== null ? placeStartData.id : null)},
            endPlace: {id: (placeEndData !== null ? placeEndData.id : null)}
        };

        // Ajout des informations du ticketDTO dans le formData
        formData.append("ticketDTO", JSON.stringify(ticketDTO));

        // On ajoute l'image dans le formData
        formData.append("receiptPicture", receiptPicture);

        httpClient.post(URL_TICKETS, formData, {headers: {"Content-Type": "multipart/form-data"}})
            .then(function (response) {
                if (isRoundTrip && ticketTypeCode === "EXCEPTIONAL_BUSINESS_TRAVEL") {
                    TicketService._postNewTicket(ticketTypeCode, date, receiptPicture, customer, employeeAmount, vehicle, purpose, siteOrMeeting, bedroomAmount,
                        breakfastAmount, lunchAmount, dinnerAmount, placeEndData, placeStartData, false, handleStartDateChange,
                        handleEndDateChange, selectedStartDate, selectedEndDate, handleUpdateForMajNeeded);
                } else {
                    // Si le ticket ajouté est avant ou après la période selectionnée, mise à jour de la borne necessaire
                    if (moment(date, 'YYYY-MM-DD').isSameOrBefore(selectedStartDate)) {
                        handleStartDateChange(date);
                    } else if (moment(date, 'YYYY-MM-DD').isSameOrAfter(selectedEndDate)) {
                        handleEndDateChange(date);
                    }

                    // Demande de MAJ de la liste dans tous les cas
                    handleUpdateForMajNeeded(true);

                    // Affichage du pop-up de succès
                    snackbarStore.addSnackbarSuccess("Ajout de votre ticket réussi.");
                }
            })
            .catch(function (error) {
                console.log(error);
                snackbarStore.addSnackbarError("Erreur rencontrée lors de l'ajout de votre ticket.");
            });
    };

    /**
     * Permets de gérer l'ajout d'un nouveau ticket.
     * @param ticketTypeCode
     * @param date
     * @param receiptPicture
     * @param customer
     * @param employeeAmount
     * @param vehicle
     * @param mileage
     * @param purpose
     * @param siteOrMeeting
     * @param bedroomAmount
     * @param breakfastAmount
     * @param lunchAmount
     * @param dinnerAmount
     * @param placeStartData
     * @param placeEndData
     * @param distanceExist
     * @param isRoundTrip
     * @param handleStartDateChange
     * @param handleEndDateChange
     * @param selectedStartDate
     * @param selectedEndDate
     * @param handleUpdateForMajNeeded
     */
    static addNewTicket = (ticketTypeCode, date, receiptPicture, customer, employeeAmount, vehicle, mileage, purpose, siteOrMeeting, bedroomAmount,
                           breakfastAmount, lunchAmount, dinnerAmount, placeStartData, placeEndData, distanceExist, isRoundTrip, handleStartDateChange,
                           handleEndDateChange, selectedStartDate, selectedEndDate, handleUpdateForMajNeeded) => {

        // Si distanceExist == false et que le type de ticket necessite une distance, il faut créer la distance entre les deux places
        if (!distanceExist && ticketTypeCode === "EXCEPTIONAL_BUSINESS_TRAVEL") {
            httpClient.post(URL_DISTANCES, {
                placeStart: {id: placeStartData.id},
                placeEnd: {id: placeEndData.id},
                value: mileage
            })
                .then(function (response) {
                    // Puis on ajoute le ticket
                    TicketService._postNewTicket(ticketTypeCode, date, receiptPicture, customer, employeeAmount, vehicle, purpose, siteOrMeeting, bedroomAmount,
                        breakfastAmount, lunchAmount, dinnerAmount, placeStartData, placeEndData, isRoundTrip, handleStartDateChange, handleEndDateChange,
                        selectedStartDate, selectedEndDate, handleUpdateForMajNeeded);
                })
                .catch(function (error) {
                    snackbarStore.addSnackbarError("Erreur rencontrée lors de l'ajout de votre ticket.");
                });
        } else {
            TicketService._postNewTicket(ticketTypeCode, date, receiptPicture, customer, employeeAmount, vehicle, purpose, siteOrMeeting, bedroomAmount,
                breakfastAmount, lunchAmount, dinnerAmount, placeStartData, placeEndData, isRoundTrip, handleStartDateChange, handleEndDateChange,
                selectedStartDate, selectedEndDate, handleUpdateForMajNeeded);
        }
    };

    /**
     * Permets de récuperer les informations liées à un ticket selon son id.
     * @param ticketId
     * @param handleTicketFormInitialisation
     */
    static getTicketById = (ticketId, handleTicketFormInitialisation) => {
        const getUrl = URL_TICKETS + "/" + ticketId;

        httpClient.get(getUrl)
            .then(function (response) {
                handleTicketFormInitialisation(response.data);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération du ticket selectionné");
            });
    }

    /**
     * Permets de supprimer un ticket selon son id.
     * @param ticketId
     * @param handleDeleteDialogIsOpen
     * @param handleModalTicketDetailsId
     * @param handleUpdateForMajNeeded
     */
    static deleteTicketById = (ticketId, handleDeleteDialogIsOpen, handleModalTicketDetailsId, handleUpdateForMajNeeded) => {
        const delUrl = URL_TICKETS + "/" + ticketId;

        httpClient.delete(delUrl)
            .then(function (response) {
                // Demande de mise à jour du tableau global
                handleUpdateForMajNeeded(true);

                // Affichage du retour utilisateur
                snackbarStore.addSnackbarSuccess("Suppression de votre ticket réussie.");

                // Fermeture de la fenêtre de confirmation de suppression
                handleDeleteDialogIsOpen(false);

                // Fermeture du détails du ticket en cours
                handleModalTicketDetailsId(-1);

            })
            .catch(function (error) {
                // Demande de mise à jour du tableau global
                handleUpdateForMajNeeded(true);

                // Affichage du retour utilisateur
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la suppression du ticket selectionné");

                // Fermeture de la fenêtre de confirmation de suppression
                handleDeleteDialogIsOpen(false);

                // Fermeture du détails du ticket en cours
                handleModalTicketDetailsId(-1);
            })
    }

    /**
     * Permets d'effectuer la mise à jour des informations d'un ticket.
     * @param ticketId
     * @param ticketTypeCode
     * @param date
     * @param customer
     * @param employeeAmount
     * @param vehicle
     * @param purpose
     * @param siteOrMeeting
     * @param bedroomAmount
     * @param breakfastAmount
     * @param lunchAmount
     * @param dinnerAmount
     * @param placeStartData
     * @param placeEndData
     * @param isValid
     * @param handleUpdateForMajNeeded
     * @param toggleIsEditable
     * @param handleModalTicketDetailsId
     */
    static _putTicket = (ticketId, ticketTypeCode, date, customer, employeeAmount, vehicle, purpose, siteOrMeeting, bedroomAmount,
                         breakfastAmount, lunchAmount, dinnerAmount, placeStartData, placeEndData, isValid, handleUpdateForMajNeeded,
                         toggleIsEditable, handleModalTicketDetailsId) => {
        const putTicketUrl = URL_TICKETS + "/" + ticketId;

        httpClient.put(putTicketUrl, {
            code: ticketTypeCode,
            date: date,
            valid: isValid,
            customer: customer,
            employeeAmount: employeeAmount,
            vehicle: vehicle,
            purpose: purpose,
            siteOrMeeting: siteOrMeeting,
            bedroomAmount: bedroomAmount,
            breakfastAmount: breakfastAmount,
            lunchAmount: lunchAmount,
            dinnerAmount: dinnerAmount,
            startPlace: {id: (placeStartData !== null ? placeStartData.id : null)},
            endPlace: {id: (placeEndData !== null ? placeEndData.id : null)}
        })
            .then(function (response) {
                handleUpdateForMajNeeded(true);
                toggleIsEditable();
                handleModalTicketDetailsId(-1);
                snackbarStore.addSnackbarSuccess("Mise à jour de votre ticket réussie.");
            })
            .catch(function (error) {
                handleModalTicketDetailsId(-1);
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la mise à jour de votre ticket.");
            });
    }

    /**
     * Permets de gérer la mise à jour des informations d'un ticket.
     * @param ticketId
     * @param ticketTypeCode
     * @param date
     * @param customer
     * @param employeeAmount
     * @param vehicle
     * @param mileage
     * @param purpose
     * @param siteOrMeeting
     * @param bedroomAmount
     * @param breakfastAmount
     * @param lunchAmount
     * @param dinnerAmount
     * @param placeStartData
     * @param placeEndData
     * @param distanceExist
     * @param isValid
     * @param handleUpdateForMajNeeded fonction permettant de prevenir le composant parent qu'une mise à jour de l'affichage
     * est nécessaire.
     * @param toggleIsEditable
     * @param handleModalTicketDetailsId
     */
    static updateTicket = (ticketId, ticketTypeCode, date, customer, employeeAmount, vehicle, mileage, purpose, siteOrMeeting,
                           bedroomAmount, breakfastAmount, lunchAmount, dinnerAmount, placeStartData, placeEndData, distanceExist, isValid,
                           handleUpdateForMajNeeded, toggleIsEditable, handleModalTicketDetailsId) => {

        if (!distanceExist && ticketTypeCode === "EXCEPTIONAL_BUSINESS_TRAVEL") {
            // Une distance est à rajouter
            httpClient.post(URL_DISTANCES, {
                placeStart: {id: placeStartData.id},
                placeEnd: {id: placeEndData.id},
                value: mileage
            })
                .then(function (response) {
                    // puis je put le ticket
                    TicketService._putTicket(ticketId, ticketTypeCode, date, customer, employeeAmount, vehicle, purpose, siteOrMeeting, bedroomAmount,
                        breakfastAmount, lunchAmount, dinnerAmount, placeStartData, placeEndData, isValid, handleUpdateForMajNeeded,
                        toggleIsEditable, handleModalTicketDetailsId);
                })
                .catch(function (error) {
                    handleModalTicketDetailsId(-1);
                    snackbarStore.addSnackbarError("Erreur rencontrée lors de l'ajout de votre distance.");
                });
        } else {
            // sinon, seul un put du ticket est nécessaire
            TicketService._putTicket(ticketId, ticketTypeCode, date, customer, employeeAmount, vehicle, purpose, siteOrMeeting, bedroomAmount,
                breakfastAmount, lunchAmount, dinnerAmount, placeStartData, placeEndData, isValid, handleUpdateForMajNeeded,
                toggleIsEditable, handleModalTicketDetailsId);
        }
    }

    /**
     * Fonction appelée lors de la validation des tickets. Permets de valider le ticket puis de passer au ticket
     * suivant en cas de réussite.
     *
     * @param ticketId
     * @param handleNext
     * @param handleUpdateForMajNeeded fonction permettant de prevenir le composant parent qu'une mise à jour de l'affichage
     * est nécessaire.
     */
    static verifyTicket = (ticketId, handleNext, handleUpdateForMajNeeded) => {
        const patchUrl = URL_TICKETS + "/" + ticketId + "/verify";

        httpClient.patch(patchUrl)
            .then(function (response) {
                snackbarStore.addSnackbarSuccess("Validation du ticket réussie.");
                handleUpdateForMajNeeded(true);
                handleNext();
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la validation du ticket.");
            });
    }
}

export default TicketService;