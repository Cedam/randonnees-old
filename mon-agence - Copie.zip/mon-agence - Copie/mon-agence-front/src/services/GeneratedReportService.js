import {URL_GENERATED_REPORT} from '../pages/expense/constants';
import httpClient from './HttpClient'
import snackbarStore from "../store/SnackbarStore";

/**
 * Ensemble de fonctions permettant d'effectuer les appels axios vers le back pour les fonctions traitant de la gestion des archives de compte-rendus.
 */
class GeneratedReportService {
    /**
     * Permets de récupérer une liste de tous les historiques.
     * @param handleAllReportsChange
     */
    static getAllReportsList = (handleAllReportsChange) => {
        const getUrl = URL_GENERATED_REPORT + "/all";

        httpClient.get(getUrl)
            .then(function (response) {
                handleAllReportsChange(response.data);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération de la liste des historiques.");
            });
    };

    /**
     * Permets de lancer la récupération et l'enregistrement du fichier excel lié au rapport dont l'id est passé en
     * paramètre.
     * @param id
     */
    static getExcelArchive = (id) => {

        const getUrl = URL_GENERATED_REPORT + "/" + id;

        httpClient.get(getUrl,
            {
                'headers': {'Accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'},
                'responseType': 'blob' // Permet de préciser au serveur de nous renvoyer l'excel sous format blob
            }
        )
            .then(function (response) {

                const blob = new Blob([response.data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});

                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                // Hide the new link
                link.style.cssText = 'visibility:hidden';

                // Get the file name in the content-disposition header
                link.download = response.headers["content-disposition"].toString().slice(22, -1);

                link.target = "_blank";

                // Add the link to the DOM, simulate click on it and finally delete it
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération du fichier Excel de l'archive.");
            });
    };

    /**
     * Permets de lancer la récupération et l'enregistrement du fichier pdf lié au rapport dont l'id est passé en
     * paramètre.
     * @param id
     */
    static getPdfArchive = (id) => {

        const getUrl = URL_GENERATED_REPORT + "/" + id;

        httpClient.get(getUrl,
            {
                'headers': {'Accept': 'application/pdf'},
                'responseType': 'blob' // Permet de préciser au serveur de nous renvoyer l'excel sous format blob
            }
        )
            .then(function (response) {

                const blob = new Blob([response.data], {type: 'application/pdf'});

                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                // Hide the new link
                link.style.cssText = 'visibility:hidden';

                // Get the file name in the content-disposition header
                link.download = response.headers["content-disposition"].toString().slice(22, -1);

                link.target = "_blank";

                // Add the link to the DOM, simulate click on it and finally delete it
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération du fichier PDF de l'archive.");
            });
    };

    /**
     * Permets de lancer la récupération et l'enregistrement du fichier zip lié au rapport dont l'id est passé en
     * paramètre.
     * @param id
     */
    static getZipArchive = (id) => {

        const getUrl = URL_GENERATED_REPORT + "/" + id;

        httpClient.get(getUrl,
            {
                'headers': {'Accept': 'application/zip'},
                'responseType': 'blob' // Permet de préciser au serveur de nous renvoyer l'excel sous format blob
            }
        )
            .then(function (response) {

                const blob = new Blob([response.data], {type: 'application/zip'});

                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                // Hide the new link
                link.style.cssText = 'visibility:hidden';

                // Get the file name in the content-disposition header
                link.download = response.headers["content-disposition"].toString().slice(22, -1);

                link.target = "_blank";

                // Add the link to the DOM, simulate click on it and finally delete it
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            })
            .catch(function (error) {
                snackbarStore.addSnackbarError("Erreur rencontrée lors de la récupération du fichier ZIP de l'archive.");
            });
    };
}

export default GeneratedReportService;