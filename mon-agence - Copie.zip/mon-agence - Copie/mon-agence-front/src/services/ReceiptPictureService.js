import {URL_RECEIPT_PICTURE} from '../pages/expense/constants';
import httpClient from './HttpClient';
import snackbarStore from "../store/SnackbarStore";


/**
 * Ensemble de fonctions permettant d'effectuer les appels axios vers le back pour les fonctions traitant les services.
 */
class ReceiptPictureService {
    /**
     * Permets de récuperer une image selon l'id du ticket associé
     */
    static getReceiptPictureByTicketId = (idTicket, handleReceiptPictureChange) => {
        const getUrl = URL_RECEIPT_PICTURE + "/" + idTicket;

        httpClient.get(getUrl)
            .then(function (response) {
                if (response.data !== null) {
                    fetch("data:" +
                        response.data.mimeType +
                        ";base64," + response.data.receiptPicture)
                        .then(res => res.blob())
                        .then(blob => {
                                let file = new File([blob], response.data.name, {
                                    type: response.data.mimeType,
                                    lastModified: Date.now()
                                });

                                handleReceiptPictureChange(file);
                            }
                        );
                }
            })
            .catch(function (error) {
                handleReceiptPictureChange(null);
                snackbarStore.addSnackbarError("Erreur lors de la récupération de l'image liée au ticket selectionné.");
            })
    }
}

export default ReceiptPictureService;