import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const BASE_API_URL = BACKEND_URL + (BACKEND_URL.endsWith('/') ? 'api' : '/api');

/**
 * Client HTTP pour faire les appels sur l'api exposée par Mon Agence
 * @type {AxiosInstance}
 */
export const httpClient = axios.create({
  baseURL: BASE_API_URL,
  timeout: 3000,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  }
});

/**
 * Gére de manière générique les erreurs sur les appels HTTP.
 * TODO utiliser une snackbar (notistacck) pour afficher les erreurs
 * @param error
 */
export const handleError = error => {
  if (error.response) {
    // Le serveur a répondu à la requête
    const response = error.response;
    // TODO manage retry with refresh token on 401 error and logout if not renewed
    const message = (response.data && response.data.message) || response.statusText;
    console.error(message);

  } else if (error.request) {
    // La requête a été réalisée mais aucune réponse n'a été reçue
    console.error('Timeout exceeded');
  } else {
    // Something happened in setting up the request that triggered an Error
    console.error('Error', error.message);
  }
}

export default httpClient;