import {action, observable} from 'mobx';

const _ = require('lodash');

class SnackbarStore {
    @observable notifications;

    constructor() {
        this.notifications = []
    }

    @action addSnackbarSuccess(message) {
        this.notifications.push(
            new Notification(
                this.generateRandomKey(),
                message,
                {
                    variant: 'success',
                    autoHideDuration: 5000,
                },
            ));
    }

    @action addSnackbarError(message) {
        this.notifications.push(
            new Notification(
                this.generateRandomKey(),
                message,
                {
                    variant: 'error',
                    autoHideDuration: 8000,
                },
            ));

    }

    @action addSnackbarWarning(message) {
        this.notifications.push(
            new Notification(
                this.generateRandomKey(),
                message,
                {
                    variant: 'warning',
                    autoHideDuration: 5000,
                },
            ));

    }

    @action addSnackbarInfo(message) {
        this.notifications.push(
            new Notification(
                this.generateRandomKey(),
                message,
                {
                    variant: 'info',
                    autoHideDuration: 5000,
                },
            ));

    }

    @action removeSnackbar(key) {
        let indexNotification = _.findIndex(this.notifications, function (targetNotification) {
            return targetNotification.key === key;
        })
        this.notifications.splice(indexNotification, 1);
    }

    generateRandomKey() {
        return new Date().getTime() + Math.random();
    }
}

class Notification {
    key = '';
    message = '';
    options = {};

    constructor(key, message, options) {
        this.key = key;
        this.message = message;
        this.options = options;
    }
}

const snackbarStore = new SnackbarStore()
export default snackbarStore;
