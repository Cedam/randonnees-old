import {action, computed, observable} from 'mobx';
import {computedFn} from 'mobx-utils';
import * as _ from 'lodash';

const CURRENT_USER = 'CURRENT_USER';

/**
 * Store pour stocker l'utilisateur connecté
 */
class UserStore {
    @observable user;

    constructor() {
        const connectedUser = localStorage.getItem(CURRENT_USER);
        this.user = connectedUser ? JSON.parse(connectedUser) : null;
    }

    @action setUser(user) {
        this.user = new User(user);
        localStorage.setItem(CURRENT_USER, JSON.stringify(this.user));
    }

    @action reset() {
        this.user = null;
        localStorage.removeItem(CURRENT_USER);
    }

    @computed get connected() {
        return !_.isNil(this.user);
    }

    @computed get fullname() {
        if (this.user && !_.isEmpty(this.user.firstname) && !_.isEmpty(this.user.lastname)) {
            return this.user.firstname + ' ' + this.user.lastname.toUpperCase();
        }
        return '';
    }

    @computed get roles() {
        if (this.user) {
            return this.user.roles;
        }
        return [];
    }

    @computedFn hasRole(role) {
        return _.includes(this.roles, role);
    }

    @computedFn hasAnyRole(roles) {
        return _.isArray(roles) && (roles.length === 0 || _.some(this.roles, r => _.includes(roles, r)))
    }
}

class User {
    id = '';
    username = '';
    firstname = '';
    lastname = '';
    roles = [];

    constructor(user) {
        this.id = user.id;
        this.username = user.username;
        this.firstname = user.firstname;
        this.lastname = user.lastname;
        this.roles = _.map(user.authorities, a => a.name);
    }
}

const userStore = new UserStore();
export default userStore;