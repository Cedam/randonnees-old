import React from 'react';
import * as styles from './Help.module.scss';

function Help() {
  return (
    <div className={styles.Root}>
      <span>Aide</span>
    </div>
  );
}

export default Help;
