import React from 'react';
import * as styles from './MyProfile.module.scss';

function MyProfile() {
  return (
    <div className={styles.Root}>
      <span>Profil utilisateur</span>
    </div>
  );
}

export default MyProfile;
