import React from 'react';

import {TableCell, TableHead, TableRow, TableSortLabel} from '@material-ui/core';

/**
 * Composant permettant de gérer l'en-tête d'un composant tableau.
 * @param props
 * @returns {JSX.Element}
 * @constructor
 */
export default function EnhancedTableHead(props) {

    const createSortHandler = (property) => (event) => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow>
                {props.headCells.map((headCell) => (
                    <TableCell
                        key={headCell.id}
                        align={'left'}
                        padding={'default'}
                        sortDirection={props.orderBy === headCell.id ? props.order : false}
                    >
                        <TableSortLabel
                            active={props.orderBy === headCell.id}
                            direction={props.orderBy === headCell.id ? props.order : 'asc'}
                            onClick={createSortHandler(headCell.id)}
                            disabled={headCell.isDisabled}
                        >
                            {headCell.label}
                        </TableSortLabel>
                    </TableCell>
                ))}
            </TableRow>
        </TableHead>
    );
}