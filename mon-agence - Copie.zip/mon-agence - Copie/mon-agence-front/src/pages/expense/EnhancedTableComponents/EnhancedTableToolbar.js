import React from 'react';

import {Toolbar, Typography} from '@material-ui/core';

/**
 * Composant permettant de gérer le titre d'un composant tableau.
 * @param props
 * @returns {JSX.Element}
 * @constructor
 */
export default function EnhancedTableToolbar(props) {
    return (
        <Toolbar>
            <Typography variant="h6" id="tableTitle" component="div">
                <span>{props.title} </span>
            </Typography>
        </Toolbar>
    );
}