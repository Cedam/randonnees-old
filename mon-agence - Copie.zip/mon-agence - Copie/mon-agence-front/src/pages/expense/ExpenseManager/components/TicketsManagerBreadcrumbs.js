import React from 'react';

import {Breadcrumbs, Container, Link, Typography} from '@material-ui/core';
import {Euro as EuroIcon, Grain as GrainIcon, Home as HomeIcon} from '@material-ui/icons';
import {useHistory} from "react-router-dom";
import {makeStyles} from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    link: {
        display: 'flex',
        cursor: 'pointer',
    },
    flat: {
        display: 'flex',
    },
    icon: {
        marginRight: theme.spacing(0.5),
        width: 22,
        height: 22,
    },
}));

/**
 * Composant fil d'Arianne pour le composant "TicketsManager.js".
 *
 * @param props
 * @returns {JSX.Element}
 * @constructor
 */
function TicketsManagerBreadcrumbs(props) {
    const history = useHistory();
    const classes = useStyles();

    return (
        <Container>
            <Breadcrumbs style={{"marginTop": 10 + "px", "marginLeft": -20 + "px"}}>
                <Link color="inherit" onClick={() => history.push("/")} className={classes.link}>
                    <HomeIcon className={classes.icon}/>Accueil
                </Link>
                <Typography color="textPrimary" className={classes.flat}>
                    <EuroIcon className={classes.icon}/>Mes notes de frais
                </Typography>
                <Typography color="textPrimary" className={classes.flat}>
                    <GrainIcon className={classes.icon}/>Mes tickets
                </Typography>
            </Breadcrumbs>
        </Container>
    );
}

export default TicketsManagerBreadcrumbs;