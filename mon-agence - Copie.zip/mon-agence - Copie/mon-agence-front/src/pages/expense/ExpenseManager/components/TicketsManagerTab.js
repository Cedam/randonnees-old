import React from 'react';
import {
    Checkbox,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TablePagination,
    TableRow,
    Tooltip
} from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import {showFormattedDate, showTicketType} from '../../utilities';
import EnhancedTableHead from '../../EnhancedTableComponents/EnhancedTableHead';
import EnhancedTableToolbar from '../../EnhancedTableComponents/EnhancedTableToolbar';
import DetailsTicketDialog from '../../ExpenseDialogs/DetailsTicketDialog';
import TicketService from "../../../../services/TicketService";

/**
 * Composant affichant tous les tickets en cours de traitement pré-filtré par "TicketsManager.js".
 * Permet aussi l'affichage d'un pop-up dialog permettant d'afficher le détail d'un ticket particulier.
 */
class TicketsManagerTab extends React.Component {
    constructor(props) {
        super(props);

        // Cette variable permet de bloquer le doUpdate si jamais l'initialisation
        // du composant est en cours
        this.initializationInProgress = false;

        this.state = {
            page: 0, // Page actuellement choisie
            rowsPerPage: 10, // Nombre d'elements à afficher par page
            order: 'asc', // Ordre actuellement choisi
            orderBy: 'date', // En-tête du tableau actuellement ordonnée
            allTickets: [], // Liste de tous les tickets pré-filtré
            paginationTotalElement: 0, // Nombre d'élement total, afin de gérer les calculs de pagination
            emptyRows: 10, // Nombre de ligne vide à afficher
            modalTicketDetailsId: -1 // Id du ticket dont on doit afficher le détail (-1 si il ne faut pas afficher le détail d'un ticket)
        };

        this.handleRequestSort = this.handleRequestSort.bind(this);
        this.handleModalTicketDetailsId = this.handleModalTicketDetailsId.bind(this);
        this.handleChangePage = this.handleChangePage.bind(this);
        this.handleChangeRowsPerPage = this.handleChangeRowsPerPage.bind(this);
        this.updateAllTicketsAndPagination = this.updateAllTicketsAndPagination.bind(this);
        this.handleInitialisation = this.handleInitialisation.bind(this);
    }

    componentDidMount() {
        // On previent le componentDidUpdate qu'il ne doit pas refaire la requete malgré le changement des dates filtrées
        this.initializationInProgress = true;

        TicketService.getInitialTickets(this.state.page, this.state.rowsPerPage, this.state.order, this.state.orderBy, this.props.ticketTypeCode,
            this.props.showArchived, this.props.selectedStartDate, this.props.selectedEndDate, this.handleInitialisation);
    }

    doUpdate() {
        // Si il faut faire la requête
        if (!this.initializationInProgress) {
            // Requete
            TicketService.getAllTickets(this.state.page, this.state.rowsPerPage, this.state.order, this.state.orderBy, this.props.ticketTypeCode,
                this.props.showArchived, this.props.selectedStartDate, this.props.selectedEndDate, this.updateAllTicketsAndPagination);
            // Mise à faux de la nécessité de mettre à jour
            this.props.handleUpdateForMajNeeded(false);
        }
    }

    componentDidUpdate(prevProps, prevState) {
        // Si MAJ necessaire suite à un ajout dans la liste
        if (this.props.updateForMajNeeded) {
            this.doUpdate();
        }
        // Sinon si MAJ nécessaire car un paramètre de filtrage à changer
        else if (
            prevState.page !== this.state.page ||
            prevState.rowsPerPage !== this.state.rowsPerPage ||
            prevState.order !== this.state.order ||
            prevState.orderBy !== this.state.orderBy ||
            prevProps.ticketTypeCode !== this.props.ticketTypeCode ||
            prevProps.showArchived !== this.props.showArchived ||
            prevProps.selectedStartDate !== this.props.selectedStartDate ||
            prevProps.selectedEndDate !== this.props.selectedEndDate) {
            this.doUpdate();
        }
    }

    // Fonction utilisée une seule fois lors de l'initialisation du composant
    handleInitialisation(realStartDate, realEndDate, allTickets, totalElements) {
        this.setState({
            allTickets: allTickets,
            emptyRows: this.state.rowsPerPage - Math.min(this.state.rowsPerPage, allTickets.length),
            paginationTotalElement: totalElements
        });
        this.props.handleLimitsInitialisation(realStartDate, realEndDate);

        this.initializationInProgress = false;
    }

    // Fonction permettant de mettre à jour les informations lors de la récupération des tickets
    updateAllTicketsAndPagination(newTickets, newPaginationTotalElement) {
        // Si la page demandée est > 0 et que la liste retournée est vide, il faut remettre page à 0
        if (this.state.page > 0 && newTickets.length === 0) {
            this.setState({page: 0});
        } else {
            this.setState({allTickets: newTickets});
            this.setState({emptyRows: this.state.rowsPerPage - Math.min(this.state.rowsPerPage, newTickets.length)});
            this.setState({paginationTotalElement: newPaginationTotalElement});
        }
    }

    handleRequestSort(event, property) {
        const isAsc = this.state.orderBy === property && this.state.order === 'asc';

        this.setState({order: isAsc ? 'desc' : 'asc', orderBy: property});
    }

    handleModalTicketDetailsId(idTicket) {
        this.setState({modalTicketDetailsId: idTicket});
    }

    handleChangePage(event, newPage) {
        this.setState({page: newPage});
    }

    handleChangeRowsPerPage(event) {
        this.setState({rowsPerPage: parseInt(event.target.value, 10), page: 0});
    }

    render() {

        const headCells = [
            {id: 'date', label: 'Date'},
            {id: 'code', label: 'Type'},
            {id: 'valid', label: 'Validé'}
        ];

        return (
            <div style={{"marginTop": 10 + "px"}}>
                <Paper>
                    <EnhancedTableToolbar title={"Mes tickets"}/>
                    <TableContainer>
                        <Table
                            size={'medium'}
                        >
                            <EnhancedTableHead
                                order={this.state.order}
                                orderBy={this.state.orderBy}
                                onRequestSort={this.handleRequestSort}
                                rowCount={this.state.allTickets.length}
                                headCells={headCells}
                            />
                            <TableBody>
                                {this.state.allTickets.map((row, index) => {
                                    const labelId = `enhanced-table-checkbox-tickets-${index}`;

                                    return (
                                        <Tooltip title="Ce ticket est déjà archivé !" arrow
                                                 disableHoverListener={!row.archived}
                                                 key={"ticketTooltip-" + row.id}>
                                            <TableRow
                                                hover={!row.archived}
                                                selected={!!row.archived}
                                                onClick={(event) => this.handleModalTicketDetailsId(row.id)}
                                                style={row.archived ? {
                                                    "backgroundColor": "rgba(117, 148, 155, 0.16)",
                                                    "marginLeft": -20 + "px"
                                                } : {}}
                                                key={row.id}
                                            >
                                                <TableCell component="th" id={labelId} scope="row" align="left"
                                                           padding="default">{showFormattedDate(row.date)}</TableCell>
                                                <TableCell align="left"
                                                           padding="default">{showTicketType(row.code, this.props.allTicketsCode)}</TableCell>
                                                <TableCell align="left" padding="checkbox"><Checkbox disabled
                                                                                                     checked={row.valid}
                                                                                                     color="primary"/></TableCell>
                                            </TableRow>
                                        </Tooltip>
                                    )
                                })}

                                {this.state.emptyRows > 0 && (
                                    <TableRow style={{height: 53 * this.state.emptyRows}}>
                                        <TableCell colSpan={6}/>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        rowsPerPageOptions={[5, 10, 25]}
                        component="div"
                        count={this.state.paginationTotalElement}
                        rowsPerPage={this.state.rowsPerPage}
                        page={this.state.page}
                        onChangePage={this.handleChangePage}
                        onChangeRowsPerPage={this.handleChangeRowsPerPage}
                        labelRowsPerPage="Lignes par page : "
                    />
                </Paper>
                <DetailsTicketDialog allPlaces={this.props.allPlaces}
                                     modalTicketDetailsId={this.state.modalTicketDetailsId}
                                     handleModalTicketDetailsId={this.handleModalTicketDetailsId}
                                     allTickets={this.state.allTickets} allTicketsCode={this.props.allTicketsCode}
                                     mileageAllowance={this.props.mileageAllowance}
                                     handleUpdateForMajNeeded={this.props.handleUpdateForMajNeeded}
                />
            </div>
        );
    }
}

export default TicketsManagerTab;