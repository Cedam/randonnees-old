import React, {useState} from 'react';
import {FormControlLabel, Grid, Select, Switch} from '@material-ui/core';
import {KeyboardDatePicker, MuiPickersUtilsProvider} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import frLocale from 'date-fns/locale/fr';
import {getAllTicketsTypeOptionList} from '../../utilities';

/**
 * Composant permettant le filtrage du tableau présent dans le composant "TicketsManager.js".
 *
 * @param props
 * @returns {JSX.Element}
 * @constructor
 */
function TicketsManagerFilters(props) {
    const [isStartDateDatepickerOpen, setIsStartDateDatepickerOpen] = useState(false);
    const [isEndDateDatepickerOpen, setIsEndDateDatepickerOpen] = useState(false);

    const handleStartDateChange = (date) => {
        props.handleStartDateChange(date);
        setIsStartDateDatepickerOpen(!isStartDateDatepickerOpen);
    }

    const handleEndDateChange = (date) => {
        props.handleEndDateChange(date);
        setIsEndDateDatepickerOpen(!isEndDateDatepickerOpen);
    }

    return (
        <Grid container direction="row" justify="center" alignItems="center" spacing={3}
              style={{"marginTop": -25 + "px"}}>
            <Grid item style={{"marginTop": 25 + "px"}}>
                {/* Liste déroulante permettant le choix d'un type de ticket */}
                <FormControlLabel
                    label="Type du ticket : "
                    labelPlacement="start"
                    control={
                        <Select native value={props.ticketTypeCode} onChange={props.handleTicketTypeCodeChange}
                                inputProps={{name: 'ticketTypeCode', id: 'type-native-simple'}}>
                            <option value=""/>
                            {
                                getAllTicketsTypeOptionList(props.allTicketsCode, true)
                            }
                        </Select>
                    }
                />
            </Grid>

            <Grid item>
                <MuiPickersUtilsProvider utils={DateFnsUtils} locale={frLocale}>
                    {/* Choix d'une date de début de période */}
                    <KeyboardDatePicker
                        disableToolbar
                        variant="inline"
                        format="dd/MM/yyyy"
                        margin="normal"
                        id="date-picker-inline-startDate"
                        label="Date de début (incluse)"
                        value={props.selectedStartDate}
                        onChange={handleStartDateChange}
                        KeyboardButtonProps={{
                            onFocus: e => {
                                setIsStartDateDatepickerOpen(true);
                            }
                        }}
                        PopoverProps={{
                            disableRestoreFocus: true,
                            onClose: () => {
                                setIsStartDateDatepickerOpen(false);
                            }
                        }}
                        InputProps={{
                            onFocus: () => {
                                setIsStartDateDatepickerOpen(true);
                            }
                        }}
                        open={isStartDateDatepickerOpen}
                    />
                </MuiPickersUtilsProvider>
            </Grid>

            <Grid item>
                <MuiPickersUtilsProvider utils={DateFnsUtils} locale={frLocale}>
                    {/* Choix d'une date de fin de période */}
                    <KeyboardDatePicker
                        disableToolbar
                        variant="inline"
                        format="dd/MM/yyyy"
                        margin="normal"
                        id="date-picker-inline-startEnd"
                        label="Date de fin (incluse)"
                        value={props.selectedEndDate}
                        onChange={handleEndDateChange}
                        KeyboardButtonProps={{
                            onFocus: e => {
                                setIsEndDateDatepickerOpen(true);
                            }
                        }}
                        PopoverProps={{
                            disableRestoreFocus: true,
                            onClose: () => {
                                setIsEndDateDatepickerOpen(false);
                            }
                        }}
                        InputProps={{
                            onFocus: () => {
                                setIsEndDateDatepickerOpen(true);
                            }
                        }}
                        open={isEndDateDatepickerOpen}
                    />
                </MuiPickersUtilsProvider>
            </Grid>

            <Grid item style={{"marginTop": 25 + "px"}}>
                {/* Bouton ON/OFF afin d'afficher ou non les tickets archivés */}
                <FormControlLabel
                    label="Tickets archivés"
                    labelPlacement="start"

                    control={
                        <Switch
                            checked={props.showArchived}
                            onChange={props.handleShowArchivedChange}
                            color="primary"
                            name="isArchived"
                        />
                    }
                />
            </Grid>
        </Grid>
    );
}

export default TicketsManagerFilters;