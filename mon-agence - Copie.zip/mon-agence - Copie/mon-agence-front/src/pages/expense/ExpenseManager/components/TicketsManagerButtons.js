import React from 'react';

import {Button, Container, Grid} from '@material-ui/core';
import NoteAddIcon from '@material-ui/icons/NoteAddOutlined';
import CheckIcon from '@material-ui/icons/Check';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';

import AddTicketDialog from '../../ExpenseDialogs/AddTicketDialog';
import VerifyTicketDialog from '../../ExpenseDialogs/VerifyTicketDialog';
import {useHistory} from "react-router-dom";

/**
 * Ensemble de boutons utilisé par le composant "TicketsManager.js".
 *
 * @param props
 * @returns {JSX.Element}
 * @constructor
 */
function TicketsManagerButtons(props) {
    const [modalAddTicketIsOpen, setModalAddTicketIsOpen] = React.useState(false);
    const [modalVerifyTicketIsOpen, setModalVerifyTicketIsOpen] = React.useState(false);

    let history = useHistory();

    return (
        <Container>
            <Grid container justify="center" alignItems="center" spacing={1} style={{"marginTop": 5 + "px"}}>
                <Grid container item justify="center" alignItems="center" xs={12} sm={3} md={3}>
                    <Button color="primary"
                            variant="contained"
                            onClick={() => setModalAddTicketIsOpen(true)}
                            startIcon={<NoteAddIcon/>}
                    >
                        Ajouter un ticket
                    </Button>
                </Grid>

                <Grid container item justify="center" alignItems="center" xs={12} sm={3} md={3}>
                    <Button color="default"
                            variant="contained"
                            onClick={() => setModalVerifyTicketIsOpen(true)}
                            startIcon={<CheckIcon/>}
                    >
                        Valider tous mes tickets
                    </Button>
                </Grid>

                <Grid container item justify="center" alignItems="center" xs={12} sm={3} md={3}>
                    <Button color="default"
                            variant="contained"
                            onClick={() => history.push("/expenseGenerator")}
                            startIcon={<ArrowForwardIcon/>}
                    >
                        Créer une note de frais
                    </Button>
                </Grid>

            </Grid>
            <AddTicketDialog allPlaces={props.allPlaces}
                             modalAddTicketIsOpen={modalAddTicketIsOpen}
                             setModalAddTicketIsOpen={setModalAddTicketIsOpen}
                             handleStartDateChange={props.handleStartDateChange}
                             handleEndDateChange={props.handleEndDateChange}
                             allTicketsCode={props.allTicketsCode}
                             handleUpdateForMajNeeded={props.handleUpdateForMajNeeded}
                             selectedStartDate={props.selectedStartDate} selectedEndDate={props.selectedEndDate}
                             mileageAllowance={props.mileageAllowance}
            />
            <VerifyTicketDialog allPlaces={props.allPlaces}
                                verifyDialogIsOpen={modalVerifyTicketIsOpen}
                                handleVerifyDialogIsOpen={setModalVerifyTicketIsOpen}
                                handleUpdateForMajNeeded={props.handleUpdateForMajNeeded}
                                allTicketsCode={props.allTicketsCode}
                                mileageAllowance={props.mileageAllowance}
            />
        </Container>
    );
}

export default TicketsManagerButtons;