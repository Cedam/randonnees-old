import React from 'react';

import TicketsManagerFilters from './components/TicketsManagerFilters';
import TicketsManagerBreadcrumbs from './components/TicketsManagerBreadcrumbs';
import TicketsManagerTab from './components/TicketsManagerTab';
import TicketsManagerButtons from './components/TicketsManagerButtons';
import moment from "moment";
import {Container} from '@material-ui/core';
import TicketService from "../../../services/TicketService";
import EmployeeIdentityService from "../../../services/EmployeeIdentityService";
import PlaceService from "../../../services/PlaceService";

/**
 * Composant permettant d'afficher le composant montrant tous les tickets en cours de traitement,
 * du filtrage de ces derniers ainsi que d'un fil d'Arianne et de boutons de navigation.
 */
class TicketsManager extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            allTicketsCode: [], // Listes des types de TicketCode existants et d'une chaine les representants
            allPlaces: [], // Liste des places existantes

            userMileageAllowance: 0, // Indémnité de l'utilisateur actuellement connecté

            filterTicketTypeCode: '', // Type de ticket actuellement filtré
            filterSelectedStartDate: moment().date(1).format("YYYY-MM-DD"), // Date de début actuellement filtrée
            filterSelectedEndDate: moment().endOf('month').format("YYYY-MM-DD"), // Date de fin actuellement filtrée
            filterShowArchived: false, // Doit-on affiché les tickets archivés

            updateForMajNeeded: false // Une mise à jour de la liste des tickets est-elle nécessaire (car un ticket y a été modifié)
        };

        // handler permettant l'initialisation de la liste de types de ticket
        this.handleAllTicketsCodeChange = this.handleAllTicketsCodeChange.bind(this);

        // handler permettant l'initialisation de la liste de places
        this.handleAllPlacesChange = this.handleAllPlacesChange.bind(this);

        // handler propre au filtrage
        this.handleTicketTypeCodeChange = this.handleTicketTypeCodeChange.bind(this);
        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.handleEndDateChange = this.handleEndDateChange.bind(this);
        this.handleShowArchivedChange = this.handleShowArchivedChange.bind(this);

        // handler permettant l'initialisation des dates dans le filtre
        this.handleLimitsInitialisation = this.handleLimitsInitialisation.bind(this);

        // handler permettant de savoir si une mise à jour du tableau est nécessaire
        this.handleUpdateForMajNeeded = this.handleUpdateForMajNeeded.bind(this);

        // handler permettant de stocker l'indemnité kilométrique de l'utilisateur connecté
        this.handleUserMileageAllowanceChange = this.handleUserMileageAllowanceChange.bind(this);
    }

    componentDidMount() {
        // Récupération de la liste des types de tickets
        TicketService.getAllTicketsCode(this.handleAllTicketsCodeChange);

        // Récupération des places existantes
        PlaceService.getAllPlacesList(this.handleAllPlacesChange);

        // Récupération des informations relatives à l'identité de l'employée
        EmployeeIdentityService.getEmployeeIdentity(this.handleUserMileageAllowanceChange);
    }

    handleAllTicketsCodeChange(allTicketsCode) {
        this.setState({allTicketsCode: allTicketsCode});
    }

    handleAllPlacesChange(newAllPlaces) {
        this.setState({allPlaces: newAllPlaces});
    }

    handleTicketTypeCodeChange(event) {
        this.setState({filterTicketTypeCode: event.target.value});
    }

    handleStartDateChange(date) {
        if (typeof date === "object") {
            this.setState({filterSelectedStartDate: date.toISOString().substr(0, 10)});
        } else {
            this.setState({filterSelectedStartDate: date});
        }
    }

    handleEndDateChange(date) {
        if (typeof date === "object") {
            this.setState({filterSelectedEndDate: date.toISOString().substr(0, 10)})
        } else {
            this.setState({filterSelectedEndDate: date});
        }
    }

    // Cette méthode est appelée une seule fois, lors de l'initialisation
    // du sous-composant AllTicketsTab
    handleLimitsInitialisation(startDate, endDate) {
        this.setState({
            filterSelectedStartDate: startDate,
            filterSelectedEndDate: endDate
        });
    }

    handleShowArchivedChange(event) {
        this.setState({filterShowArchived: event.target.checked});
    }

    handleUserMileageAllowanceChange(userMileageAllowance) {
        this.setState({userMileageAllowance: userMileageAllowance});
    }

    handleUpdateForMajNeeded(updateNeeded) {
        this.setState({updateForMajNeeded: updateNeeded});
    }

    render() {

        return (
            <Container>

                <TicketsManagerBreadcrumbs/>

                <TicketsManagerFilters allTicketsCode={this.state.allTicketsCode}
                                       ticketTypeCode={this.state.filterTicketTypeCode}
                                       handleTicketTypeCodeChange={this.handleTicketTypeCodeChange}
                                       showArchived={this.state.filterShowArchived}
                                       handleShowArchivedChange={this.handleShowArchivedChange}
                                       selectedStartDate={this.state.filterSelectedStartDate}
                                       handleStartDateChange={this.handleStartDateChange}
                                       selectedEndDate={this.state.filterSelectedEndDate}
                                       handleEndDateChange={this.handleEndDateChange}
                />

                <TicketsManagerTab allTicketsCode={this.state.allTicketsCode}
                                   ticketTypeCode={this.state.filterTicketTypeCode}
                                   allPlaces={this.state.allPlaces}
                                   showArchived={this.state.filterShowArchived}
                                   selectedStartDate={this.state.filterSelectedStartDate}
                                   selectedEndDate={this.state.filterSelectedEndDate}
                                   handleStartDateChange={this.handleStartDateChange}
                                   handleEndDateChange={this.handleEndDateChange}
                                   updateForMajNeeded={this.state.updateForMajNeeded}
                                   handleUpdateForMajNeeded={this.handleUpdateForMajNeeded}
                                   handleLimitsInitialisation={this.handleLimitsInitialisation}
                                   mileageAllowance={this.state.userMileageAllowance}
                />

                <TicketsManagerButtons allTicketsCode={this.state.allTicketsCode}
                                       allPlaces={this.state.allPlaces}
                                       handleUpdateForMajNeeded={this.handleUpdateForMajNeeded}
                                       handleStartDateChange={this.handleStartDateChange}
                                       handleEndDateChange={this.handleEndDateChange}
                                       selectedStartDate={this.state.filterSelectedStartDate}
                                       selectedEndDate={this.state.filterSelectedEndDate}
                                       mileageAllowance={this.state.userMileageAllowance}
                />
            </Container>
        );
    }
}

export default TicketsManager;