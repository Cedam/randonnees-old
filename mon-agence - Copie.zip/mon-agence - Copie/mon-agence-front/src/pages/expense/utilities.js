import moment from "moment";
import 'moment/locale/fr';
import React from "react";
import {MenuItem} from "@material-ui/core";

/**
 * Transforme une date JS en une date moment afin de permettre un affichage propre.
 * @param date
 * @returns {string}
 */
export function showFormattedDate(date) {
    return moment(date, 'YYYY-MM-DD').locale("fr").format("DD MMM YYYY");
}

/**
 * Transforme un ticketCode en son string d'affichage
 * @param ticketCode
 * @param allTicketsCode
 * @returns {string}
 */
export function showTicketType(ticketCode, allTicketsCode) {
    let res = "/!\\ undefined /!\\";
    Object.getOwnPropertyNames(allTicketsCode).forEach((code, index) => {

        if (ticketCode === code) {
            res = allTicketsCode[code]
        }
    });
    return res;
}

/**
 * Retourne une liste contenant les options (ou les menuItems) contenant les différents types de tickets
 *
 * @param allTicketsCode la liste des codes de tickets existants
 * @param optionFormat true pour avoir des 'options', false pour avoir des 'MenuItem'.
 * @returns {[]}
 */
export function getAllTicketsTypeOptionList(allTicketsCode, optionFormat) {
    let result = [];

    Object.getOwnPropertyNames(allTicketsCode).forEach((code) => {
        if (optionFormat) {
            result.push(<option value={code} key={code}>{allTicketsCode[code]}</option>);
        } else {
            result.push(<MenuItem value={code} key={code}>{allTicketsCode[code]}</MenuItem>);
        }
    });
    return result;
}
