// ------------------------------------------ TICKETS ------------------------------------------ //
/**
 * Url de base pour les tickets
 */
export const URL_TICKETS = "/tickets";

// ------------------------------------------ PLACES ------------------------------------------- //
/**
 * Url de base pour les places
 */
export const URL_PLACES = "/places";

// ----------------------------------------- DISTANCE ------------------------------------------ //
/**
 * Url de base pour les distances
 */
export const URL_DISTANCES = "/distances";


// ------------------------------------ EMPLOYEE_IDENTITY -------------------------------------- //
/**
 * Url de base pour les identités d'employés
 */
export const URL_EMPLOYEE_IDENTITY = "/employeeIdentities";

// -------------------------------------- Compensations ---------------------------------------- //
/**
 * Url de base pour les compensations
 */
export const URL_COMPENSATIONS = "/compensations";

// -------------------------------------- Comptes-rendus ---------------------------------------- //
/**
 * Url de base pour les comptes-rendus
 */
export const URL_REPORT = "/reports";

// -------------------------------------- Recus justificatifs ---------------------------------------- //
/**
 * Url de base pour les comptes-rendus
 */
export const URL_RECEIPT_PICTURE = "/receiptPictures";

// -------------------------------- Historiques des comptes-rendus ----------------------------------- //
/**
 * Url de base pour les historiques de comptes-rendus
 */
export const URL_GENERATED_REPORT = "/generatedReports";