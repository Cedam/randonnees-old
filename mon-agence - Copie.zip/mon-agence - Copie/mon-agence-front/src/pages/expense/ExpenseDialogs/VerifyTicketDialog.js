import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid,
    MenuItem,
    MobileStepper,
    TextField
} from '@material-ui/core';
import {ThumbDown as ThumbDownIcon, ThumbUp as ThumbUpIcon, Update as UpdateIcon} from '@material-ui/icons';
import PanToolOutlinedIcon from '@material-ui/icons/PanToolOutlined';
import {KeyboardDatePicker, MuiPickersUtilsProvider} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import frLocale from "date-fns/locale/fr";
import FormTicket from "./components/FormTicket";
import {getAllTicketsTypeOptionList} from "../utilities";
import DistanceService from "../../../services/DistanceService";
import TicketService from "../../../services/TicketService";
import snackbarStore from "../../../store/SnackbarStore";
import ReceiptPictureService from "../../../services/ReceiptPictureService";

/**
 * Composant gérant l'affichage d'une boite permettant de valider un à un les tickets non validés.
 */
class VerifyTicketDialog extends React.Component {
    // Variable permettant de savoir si les informations relatives au ticket actuellement choisit
    // sont completement arrivées afin de débloquer le clic sur les boutons "ignorer" et "valider"
    _ticketDataIsComplete = false;

    constructor(props) {
        super(props);

        this.state = {
            currentStep: -1, // étape actuelle
            allTickets: [],

            // Informations relatives aux tickets de type
            // EXCEPTIONAL_BUSINESS_TRAVEL
            mileage: 0,
            expectedAmount: 0,

            // Images relatives aux autres types
            // de ticket
            receiptPicture: null,
        };

        this.handleNext = this.handleNext.bind(this);
        this.handleAllTicketsChange = this.handleAllTicketsChange.bind(this);
        this.getCurrentTicket = this.getCurrentTicket.bind(this);
        this.handleMileageChange = this.handleMileageChange.bind(this);
        this.handleReceiptPictureChange = this.handleReceiptPictureChange.bind(this);
        this.getDistanceInformations = this.getDistanceInformations.bind(this);
        this.getReceiptPicture = this.getReceiptPicture.bind(this);
        this.validTicketAndHandleNext = this.validTicketAndHandleNext.bind(this);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        // Si la fenetre de dialogue vient juste de s'ouvrir
        if (prevProps.verifyDialogIsOpen !== this.props.verifyDialogIsOpen && this.props.verifyDialogIsOpen === true) {
            this._ticketDataIsComplete = false;
            TicketService.getAllTicketsToVerify(this.handleAllTicketsChange, this.props.handleVerifyDialogIsOpen);
        }

        // Si la fenetre de dialogue vient de s'incrementer d'un pas et est toujours ouverte
        if (prevState.currentStep !== this.state.currentStep && this.props.verifyDialogIsOpen === true) {
            this._ticketDataIsComplete = false;
            // On regarde si on doit aller chercher une distance
            this.getDistanceInformations();
            // On regarde si on doit aller chercher une image
            this.getReceiptPicture();
        }
    }

    handleNext() {
        // Si le pas suivant tombe en dehors de la taille du tableau
        if (this.state.currentStep + 1 >= this.state.allTickets.length) {
            // On ferme la boite de dialogue
            this.props.handleVerifyDialogIsOpen(false);

            this.setState({currentStep: -1});
            this.setState({allTickets: []});
            this.handleReceiptPictureChange(null);

            // On previent l'utilisateur qu'il a fini sa validation
            snackbarStore.addSnackbarInfo("Vous avez fini votre validation de tickets.");
        } else {
            // Sinon on incremente le pas
            this.setState({currentStep: this.state.currentStep + 1});
            // On supprime les informations supplémentaires relatives pour l'ancien ticket
            this.setState({mileage: 0});
            this.setState({expectedAmount: 0});
            this.setState({receiptPicture: null});
        }
    }

    validTicketAndHandleNext() {
        TicketService.verifyTicket(this.getCurrentTicket().id, this.handleNext, this.props.handleUpdateForMajNeeded);
    }

    handleAllTicketsChange(allTickets) {
        this.setState({allTickets: allTickets});
        this.setState({currentStep: 0});
        this.getDistanceInformations();
        this.getReceiptPicture();
    }

    getCurrentTicket() {
        if (this.state.currentStep !== -1 && this.state.allTickets.length > this.state.currentStep) {
            return this.state.allTickets[this.state.currentStep];
        } else {
            return {code: ""};
        }
    }

    handleMileageChange(event) {
        this._ticketDataIsComplete = true;
        this.setState({
            mileage: event.target.value,
            expectedAmount: event.target.value * this.props.mileageAllowance
        });
    }

    getDistanceInformations() {
        const currentTicket = this.getCurrentTicket();

        // Si le ticket est de type EXCEPTIONAL_BUSINESS_TRAVEL, on doit aller chercher son kilométrage
        if (currentTicket.code === 'EXCEPTIONAL_BUSINESS_TRAVEL') {
            DistanceService.getDistanceByPlaces(currentTicket.startPlace.id, currentTicket.endPlace.id, () => {
            }, this.handleMileageChange);
        }
    }

    handleReceiptPictureChange(file) {
        this._ticketDataIsComplete = true;
        this.setState({receiptPicture: file});
    }

    getReceiptPicture() {
        const currentTicket = this.getCurrentTicket();

        // Si l'image n'est pas de type EXCEPTIONAL_BUSINESS_TRAVEL et n'est pas vide, on doit aller chercher son image
        if (currentTicket.code !== '' && currentTicket.code !== "EXCEPTIONAL_BUSINESS_TRAVEL") {
            ReceiptPictureService.getReceiptPictureByTicketId(currentTicket.id, this.handleReceiptPictureChange);
        }
        else {
            this.handleReceiptPictureChange(null);
        }
    }

    render() {

        const res = FormTicket({
            ticketTypeCode: this.getCurrentTicket().code,
            customer: this.getCurrentTicket().customer,
            employeeAmount: this.getCurrentTicket().employeeAmount,
            siteOrMeeting: this.getCurrentTicket().siteOrMeeting,
            purpose: this.getCurrentTicket().purpose,
            vehicle: this.getCurrentTicket().vehicle,
            mileage: this.state.mileage,
            placeStartData: this.getCurrentTicket().startPlace,
            placeEndData: this.getCurrentTicket().endPlace,
            allPlaces: this.props.allPlaces,
            expectedAmount: this.state.expectedAmount,
            isRoundTripHidden: true,
            isAddPlaceButtonHidden: true,
            bedroomAmount: this.getCurrentTicket().bedroomAmount,
            breakfastAmount: this.getCurrentTicket().breakfastAmount,
            lunchAmount: this.getCurrentTicket().lunchAmount,
            dinnerAmount: this.getCurrentTicket().dinnerAmount,
            receiptPicture: this.state.receiptPicture,
            disabled: true, // Veut-on que tous les elements affichés ne soient qu'en lecture seul ?
            marginTop: 10,
        });

        let secondFormTicket = res.secondFormTicket;

        return (
            <Container>
                <Dialog open={this.props.verifyDialogIsOpen}
                        onClose={() => {
                            this.props.handleVerifyDialogIsOpen(false);
                            this.setState({currentStep: 0});
                            this.setState({allTickets: []});
                        }}
                        aria-labelledby="form-dialog-verifyTicketDialog" fullWidth={true} maxWidth={"md"}
                >

                    <DialogTitle id="form-dialog-verifyTicketDialog">
                        Vérification des tickets ({this.state.currentStep + 1}/{this.state.allTickets.length})
                    </DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Vérifier vos tickets vous permets de les inclure lors de la génération d'une note de frais.
                        </DialogContentText>

                        <Divider/>

                        <Grid container>
                            <div
                                style={{minHeight: '450px', minWidth: '100%'}}
                            >
                                <Grid container justify="center" alignItems="center" spacing={1}>
                                    <Grid item xs={12} md={6}>
                                        <TextField select value={this.getCurrentTicket().code} label="Type de ticket *"
                                                   fullWidth onChange={() => null}
                                                   style={{"marginTop": 10 + "px"}} variant="outlined" disabled
                                        >
                                            <MenuItem value={""}> </MenuItem>
                                            {
                                                getAllTicketsTypeOptionList(this.props.allTicketsCode, false)
                                            }
                                        </TextField>
                                    </Grid>

                                    {/* Selection de la date du ticket */}
                                    <Grid item xs={12} md={6}>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils} locale={frLocale}>
                                            {/* Choix de la date du ticket */}
                                            <KeyboardDatePicker
                                                disableToolbar
                                                variant="inline"
                                                format="dd/MM/yyyy"
                                                margin="normal"
                                                id="date-picker-inline"
                                                label="Date du justificatif *"
                                                value={this.getCurrentTicket().date}
                                                InputProps={{
                                                    disabled: !this.state.isEditable
                                                }}
                                                inputVariant="outlined"
                                                open={false}
                                                fullWidth
                                            />
                                        </MuiPickersUtilsProvider>
                                    </Grid>
                                </Grid>
                                {/* DEUXIEME CONTENUE LIE AU TYPE DE TICKET */}
                                {secondFormTicket}
                            </div>

                            <Grid container justify="center" alignItems="center" spacing={1}>

                                <Grid item xs={12} md={12}>
                                    {/* Barre d'avancement de validation des tickets */}
                                    <MobileStepper
                                        variant="progress"
                                        steps={this.state.allTickets.length + 1}
                                        position="static"
                                        activeStep={this.state.currentStep}
                                        nextButton={
                                            <Button onClick={this.validTicketAndHandleNext}
                                                    endIcon={<ThumbUpIcon/>}
                                                    color="primary"
                                                    disabled={!this._ticketDataIsComplete}
                                            >
                                                Valider
                                            </Button>
                                        }
                                        backButton={
                                            <Button onClick={this.handleNext}
                                                    startIcon={<ThumbDownIcon/>}
                                                    color="primary"
                                                    disabled={!this._ticketDataIsComplete}
                                            >
                                                Ignorer
                                            </Button>
                                        }
                                    />
                                </Grid>
                            </Grid>
                        </Grid>
                    </DialogContent>

                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button color="primary" onClick={() => {
                            this.props.handleVerifyDialogIsOpen(false);
                            this.setState({currentStep: 0})
                        }}
                                startIcon={<PanToolOutlinedIcon/>}
                        >
                            S'arrêter
                        </Button>
                        <Button startIcon={<UpdateIcon/>} color="primary" disabled>
                            Modifier ce ticket
                        </Button>
                    </DialogActions>
                </Dialog>
            </Container>
        )
    }
}

export default VerifyTicketDialog;