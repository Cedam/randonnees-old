import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle
} from '@material-ui/core';
import TicketService from "../../../services/TicketService";

/**
 * Composant permettant l'affichage d'une boite demandant la confirmation de suppression d'un ticket.
 */
class DeleteTicketDialog extends React.Component {
    constructor(props) {
        super(props);

        this.deleteTicket = this.deleteTicket.bind(this);
    }

    deleteTicket() {
        TicketService.deleteTicketById(this.props.ticketId, this.props.handleDeleteDialogIsOpen, this.props.handleModalTicketDetailsId,
            this.props.handleUpdateForMajNeeded);
    }

    render() {
        return (
            <Container>
                <Dialog open={this.props.deleteDialogIsOpen} onClose={() => this.props.handleDeleteDialogIsOpen(false)}
                        aria-labelledby="form-dialog-deleteTicketDialog" fullWidth={true} maxWidth={"xs"}
                >
                    <DialogTitle id="form-dialog-deleteTicketDialog">
                        Suppression du ticket
                    </DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Etes-vous sûr de vouloir supprimer ce ticket ?
                        </DialogContentText>
                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleDeleteDialogIsOpen(false)} color="primary">
                            Retour
                        </Button>
                        <Button onClick={() => this.deleteTicket()} color="secondary">
                            Confirmer
                        </Button>
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default DeleteTicketDialog;