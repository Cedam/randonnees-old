import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid,
    TextField
} from '@material-ui/core';
import CompensationService from "../../../services/CompensationService";

/**
 * Composant permettant l'affichage du détails d'un ticket choisit.
 */
class DetailsCompensationDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isEditable: false, // Permet de savoir si on est en mode édition ou non

            // Cv
            cv: "",

            // Indemnité
            mileageAllowance: 0,

            // Gestion validation
            mileageAllowanceError: false,
        };

        // Validation du formulaire
        this.formIsValid = this.formIsValid.bind(this);

        // Fonction permettant l'activation de la modification du formulaire
        this.toggleIsEditable = this.toggleIsEditable.bind(this);

        // Fonction appeler lors d'un clic sur le bouton enregistrer
        this.updateCompensation = this.updateCompensation.bind(this);

        // Fonction gérant la MAJ de l'input
        this.handleMileageAllowanceChange = this.handleMileageAllowanceChange.bind(this);

        // Fonction gérant l'initialisation de l'input
        this.handleInitData = this.handleInitData.bind(this);

        // Fonction permettant de clean le formulaire
        this.cleanForms = this.cleanForms.bind(this);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        // Si l'id de la place à changé
        // et qu'il est différent de -1
        // on récupère les données sur l'API
        if (prevProps.modalCompensationDetailsId !== this.props.modalCompensationDetailsId && this.props.modalCompensationDetailsId !== -1) {
            CompensationService.getCompensationById(this.props.modalCompensationDetailsId, this.handleInitData);
            this.setState({isEditable: false});
        }

        if (prevProps.modalCompensationDetailsId !== this.props.modalCompensationDetailsId && this.props.modalCompensationDetailsId === -1) {
            this.cleanForms();
        }
    }

    handleInitData(cv, mileageAllowance) {
        this.setState({cv: cv, mileageAllowance: mileageAllowance});
    }

    handleMileageAllowanceChange(event) {
        this.setState({mileageAllowance: event.target.value, mileageAllowanceError: event.target.value === ""});
    }

    formIsValid() {
        let isValid = true;

        // L'indemnité doit etre > 0
        if (this.state.mileageAllowance <= 0) {
            this.setState({mileageAllowanceError: true});
            isValid = false;
        } else {
            this.setState({mileageAllowanceError: false});
        }

        return isValid;
    }

    toggleIsEditable() {
        this.setState({isEditable: !this.state.isEditable});
    }

    updateCompensation() {
        if (this.formIsValid()) {
            CompensationService.updateCompensation(this.props.modalCompensationDetailsId, this.state.cv, this.state.mileageAllowance, this.props.doUpdate, this.toggleIsEditable,
                this.props.handleModalCompensationDetailsId);
        }
    }

    cleanForms() {
        this.setState({
            cv: "",
            mileageAllowance: 0,
            mileageAllowanceError: false,
        });
    }

    render() {

        let secondButton;

        if (!this.state.isEditable) {
            secondButton = <Button onClick={this.toggleIsEditable} color="primary">Modifier</Button>
        } else {
            secondButton = <Button onClick={this.updateCompensation} color="primary">Enregistrer</Button>;
        }

        return (
            <Container>
                <Dialog open={this.props.modalCompensationDetailsId !== -1}
                        onClose={() => this.props.handleModalCompensationDetailsId(-1)}
                        aria-labelledby="form-dialog-detailsCompensationDialog" fullWidth={true} maxWidth={"md"}
                >
                    <DialogTitle id="form-dialog-detailsCompensationDialog">Détails du barème d'Indemnité</DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Modification du barème d'indemnité selectionné
                        </DialogContentText>

                        <Divider/>

                        <Grid container>
                            <Grid container justify="center" alignItems="center" spacing={1}>
                                <Grid item xs={12} md={10}>
                                    <TextField type="number"
                                               value={this.state.cv}
                                               fullWidth
                                               InputLabelProps={{shrink: true,}}
                                               label="Cv"
                                               variant="outlined"
                                               disabled
                                               style={{"marginTop": "20px"}}
                                    />
                                    <TextField type="number"
                                               value={this.state.mileageAllowance}
                                               inputProps={{"step": "0.001"}}
                                               onChange={this.handleMileageAllowanceChange}
                                               fullWidth
                                               disabled={!this.state.isEditable}
                                               InputLabelProps={{shrink: true,}}
                                               label="Indemnité kilométrique *"
                                               variant="outlined"
                                               error={this.state.mileageAllowanceError}
                                               placeholder="Indemnité kilométrique"
                                               style={{"marginTop": "20px"}}
                                    />
                                </Grid>
                            </Grid>
                        </Grid>

                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleModalCompensationDetailsId(-1)} color="primary">
                            Retour
                        </Button>
                        {secondButton}
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default DetailsCompensationDialog;