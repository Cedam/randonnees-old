import React from 'react';

import {
    Button,
    Checkbox,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    FormControlLabel,
    Grid,
    TextField
} from '@material-ui/core';
import {KeyboardDatePicker, MuiPickersUtilsProvider} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import frLocale from 'date-fns/locale/fr';
import moment from "moment";
import DeleteTicketDialog from './DeleteTicketDialog';
import FormTicket from './components/FormTicket';
import {getAllTicketsTypeOptionList} from "../utilities";
import TicketService from "../../../services/TicketService";
import DistanceService from "../../../services/DistanceService";
import ReceiptPictureService from "../../../services/ReceiptPictureService";

/**
 * Composant permettant l'affichage du détails d'un ticket choisit.
 */
class DetailsTicketDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isEditable: false, // Permet de savoir si on est en mode édition ou non

            // state lié à la première partie du formulaire
            ticketTypeCode: '',
            selectedDate: moment().format("YYYY-MM-DD"),

            // state lié au datepicker
            isOpenDatepicker: false,

            // state lié aux secondes parties du formulaire
            isArchived: false,
            isValid: false,
            customer: "",
            employeeAmount: 0,
            vehicle: "",
            mileage: 0,
            purpose: "",
            siteOrMeeting: "",
            bedroomAmount: 0,
            breakfastAmount: 0,
            lunchAmount: 0,
            dinnerAmount: 0,
            placeStartData: null,
            placeEndData: null,
            distanceExist: false,
            expectedAmount: 0,
            receiptPicture: null,

            // Dialog de confirmation de demande de suppression
            deleteDialogIsOpen: false,

            // state d'error liés à certains elements clefs
            // du formulaire lors de la modification
            employeeAmountError: false, // employeeAmount > 0
            purposeError: false, // purpose.length > 0
            placeStartDataError: false, // != null
            placeEndDataError: false, // != null
            mileageError: false, // mileage > 0     
            sumOfAmountsError: false, // Somme(bedroomAmount, breakfastAmount, lunchAmount, dinnerAmount) > 0
        };

        // Validation du formulaire
        this.formIsValid = this.formIsValid.bind(this);

        // Fonction permettant l'initialisation des informations
        this.handleTicketFormInitialisation = this.handleTicketFormInitialisation.bind(this);

        // Fonction permettant l'activation de la modification du formulaire
        this.toggleIsEditable = this.toggleIsEditable.bind(this);

        // Fonction appeler lors d'un clic sur le bouton enregistrer
        this.updateTicket = this.updateTicket.bind(this);

        // Fonction gérant l'affichage du datePicker
        this.handleSelectedDateChange = this.handleSelectedDateChange.bind(this);

        // Fonction gérant l'affichage de la boite de confirmation de suppression
        this.handleDeleteDialogIsOpen = this.handleDeleteDialogIsOpen.bind(this);

        // Fonction gérant les MAJ des inputs
        this.handleSelectedDateChange = this.handleSelectedDateChange.bind(this);
        this.handleCustomerChange = this.handleCustomerChange.bind(this);
        this.handleEmployeeAmountChange = this.handleEmployeeAmountChange.bind(this);
        this.handleVehiculeChange = this.handleVehiculeChange.bind(this);
        this.handleMileageChange = this.handleMileageChange.bind(this);
        this.handlePurposeChange = this.handlePurposeChange.bind(this);
        this.handleSiteOrMeetingChange = this.handleSiteOrMeetingChange.bind(this);
        this.handleBedroomAmountChange = this.handleBedroomAmountChange.bind(this);
        this.handleBreakfastAmountChange = this.handleBreakfastAmountChange.bind(this);
        this.handleLunchAmountChange = this.handleLunchAmountChange.bind(this);
        this.handleDinnerAmountChange = this.handleDinnerAmountChange.bind(this);
        this.handlePlaceStartDataChange = this.handlePlaceStartDataChange.bind(this);
        this.handlePlaceEndDataChange = this.handlePlaceEndDataChange.bind(this);
        this.handleDistanceExistChange = this.handleDistanceExistChange.bind(this);
        this.handleExpectedAmountChange = this.handleExpectedAmountChange.bind(this);
        this.handleIsValidChange = this.handleIsValidChange.bind(this);
        this.handleReceiptPictureChange = this.handleReceiptPictureChange.bind(this);
        // Fonction permettant de clean le formulaire
        this.cleanForms = this.cleanForms.bind(this);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        // Si l'id du ticket à changé
        // et qu'il est différent de -1
        // on récupère ses données sur l'API
        if (prevProps.modalTicketDetailsId !== this.props.modalTicketDetailsId && this.props.modalTicketDetailsId !== -1) {
            TicketService.getTicketById(this.props.modalTicketDetailsId, this.handleTicketFormInitialisation);
            this.setState({isEditable: false});
        }

        if (prevProps.modalTicketDetailsId !== this.props.modalTicketDetailsId && this.props.modalTicketDetailsId === -1) {
            this.cleanForms();
        }
    }

    handleTicketFormInitialisation(data) {
        // On clean le formulaire pour purger les data déjà présentes
        this.cleanForms();

        // Envoie de la requete pour récuperer l'image liée au ticket si le ticket a une image
        if (data.code !== "EXCEPTIONAL_BUSINESS_TRAVEL") {
            ReceiptPictureService.getReceiptPictureByTicketId(data.id, this.handleReceiptPictureChange);
        }

        // MAJ avec les informations données
        this.setState({
            ticketTypeCode: data.code,
            selectedDate: data.date,
            isArchived: data.archived,
            isValid: data.valid,
            employeeAmount: data.employeeAmount,
            customer: data.customer,
            purpose: data.purpose,
            bedroomAmount: data.bedroomAmount,
            breakfastAmount: data.breakfastAmount,
            lunchAmount: data.lunchAmount,
            dinnerAmount: data.dinnerAmount,
            siteOrMeeting: data.siteOrMeeting,
            vehicle: data.vehicle
        });
        this.handlePlaceStartDataChange(null, typeof data.startPlace === "undefined" ? null : data.startPlace);
        this.handlePlaceEndDataChange(null, typeof data.endPlace === "undefined" ? null : data.endPlace);
    }

    formIsValid() {
        let isValid = true;

        // La valeur du ticker doit être > 0 SAUF pour les tickets 'EXCEPTIONAL_BUSINESS_TRAVEL' et 'LODGING_MEAL_BUSINESS'
        if (this.state.ticketTypeCode !== 'EXCEPTIONAL_BUSINESS_TRAVEL' && this.state.ticketTypeCode !== 'LODGING_MEAL_BUSINESS') {
            if (this.state.employeeAmount <= 0) {
                this.setState({employeeAmountError: true});
                isValid = false;
            } else {
                this.setState({employeeAmountError: false});
            }
        }

        // La taille du motif du ticket doit être > 0 pour les tickets 'VARIOUS_COST', 'FUEL' et 'VARIOUS_BUSINESS_TRAVEL'
        if (this.state.ticketTypeCode === 'VARIOUS_COST' ||
            this.state.ticketTypeCode === 'FUEL' ||
            this.state.ticketTypeCode === 'VARIOUS_BUSINESS_TRAVEL') {
            if (this.state.purpose.length <= 0) {
                this.setState({purposeError: true});
                isValid = false;
            } else {
                this.setState({purposeError: false});
            }
        }

        // Si le ticket est 'EXCEPTIONAL_BUSINESS_TRAVEL'
        if (this.state.ticketTypeCode === 'EXCEPTIONAL_BUSINESS_TRAVEL') {
            // Les informations de place de départ doivent être != null
            if (this.state.placeStartData === null) {
                this.setState({placeStartDataError: true});
                isValid = false;
            } else {
                this.setState({placeStartDataError: false});
            }
            // Les informations de place d'arrivée doivent être != null
            if (this.state.placeEndData === null) {
                this.setState({placeEndDataError: true});
                isValid = false;
            } else {
                this.setState({placeEndDataError: false});
            }
            // La distance doit être > 0
            if (this.state.mileage <= 0) {
                this.setState({mileageError: true});
                isValid = false;
            } else {
                this.setState({mileageError: false});
            }
        }

        // Si le ticket est 'LODGING_MEAL_BUSINESS'
        if (this.state.ticketTypeCode === 'LODGING_MEAL_BUSINESS') {
            // La somme des montants doit être > 0
            if (this.state.bedroomAmount + this.state.breakfastAmount + this.state.lunchAmount + this.state.dinnerAmount <= 0) {
                this.setState({sumOfAmountsError: true});
                isValid = false;
            } else {
                this.setState({sumOfAmountsError: false});
            }
        }

        return isValid;
    }

    toggleIsEditable() {
        this.setState({isEditable: !this.state.isEditable});
    }

    updateTicket() {
        if (this.formIsValid()) {
            TicketService.updateTicket(this.props.modalTicketDetailsId, this.state.ticketTypeCode, this.state.selectedDate, this.state.customer,
                this.state.employeeAmount, this.state.vehicle, this.state.mileage, this.state.purpose,
                this.state.siteOrMeeting, this.state.bedroomAmount, this.state.breakfastAmount, this.state.lunchAmount, this.state.dinnerAmount,
                this.state.placeStartData, this.state.placeEndData, this.state.distanceExist, false, this.props.handleUpdateForMajNeeded,
                this.toggleIsEditable, this.props.handleModalTicketDetailsId);
        }
    }

    handleDeleteDialogIsOpen(isOpen) {
        this.setState({deleteDialogIsOpen: isOpen});
    }

    handleSelectedDateChange(date) {
        if (this.state.isEditable) {
            this.setState({selectedDate: date.toISOString().substr(0, 10)})
        }
        this.handleIsOpenDatepicker(!this.state.isOpenDatepicker);
    }

    handleIsOpenDatepicker(isOpenDatepicker) {
        if (this.state.isEditable) {
            this.setState({isOpenDatepicker: isOpenDatepicker});
        }
    }

    handleCustomerChange(event) {
        this.setState({customer: event.target.value});
    }

    handleEmployeeAmountChange(event) {
        this.setState({employeeAmount: event.target.value, employeeAmountError: event.target.value <= 0});
    }

    handleVehiculeChange(event) {
        this.setState({vehicle: event.target.value});
    }

    handleMileageChange(event) {
        this.setState({
            mileage: event.target.value, mileageError: event.target.value <= 0,
            expectedAmount: event.target.value * this.props.mileageAllowance
        });
    }

    handlePurposeChange(event) {
        this.setState({purpose: event.target.value, purposeError: event.target.value.length <= 0});
    }

    handleSiteOrMeetingChange(event) {
        this.setState({siteOrMeeting: event.target.value});
    }

    handleBedroomAmountChange(event) {
        this.setState({
            bedroomAmount: event.target.value
        });
        this.handleSumOfAmountsError(event.target.value, this.state.breakfastAmount, this.state.lunchAmount, this.state.dinnerAmount);
    }

    handleBreakfastAmountChange(event) {
        this.setState({
            breakfastAmount: event.target.value
        });
        this.handleSumOfAmountsError(this.state.bedroomAmount, event.target.value, this.state.lunchAmount, this.state.dinnerAmount);
    }

    handleLunchAmountChange(event) {
        this.setState({
            lunchAmount: event.target.value
        });
        this.handleSumOfAmountsError(this.state.bedroomAmount, this.state.breakfastAmount, event.target.value, this.state.dinnerAmount);
    }

    handleDinnerAmountChange(event) {
        this.setState({
            dinnerAmount: event.target.value
        });
        this.handleSumOfAmountsError(this.state.bedroomAmount, this.state.breakfastAmount, this.state.lunchAmount, event.target.value);
    }

    handleSumOfAmountsError(bedroom, breakfast, lunch, dinner) {
        this.setState({
                sumOfAmountsError: bedroom
                    + breakfast
                    + lunch
                    + dinner <= 0
            }
        )
    }

    handlePlaceStartDataChange(event, value) {
        this.setState({placeStartData: value});

        if (value !== null && this.state.placeEndData !== null) {
            DistanceService.getDistanceByPlaces(value.id, this.state.placeEndData.id, this.handleDistanceExistChange, this.handleMileageChange);
            this.setState({placeStartDataError: false});
        } else {
            this.handleDistanceExistChange(false);
            this.handleMileageChange({target: {value: 0}});
        }

        if (value === null) {
            this.setState({placeStartDataError: true});
        }
    }

    handlePlaceEndDataChange(event, value) {
        this.setState({placeEndData: value});

        if (value !== null && this.state.placeStartData !== null) {
            DistanceService.getDistanceByPlaces(value.id, this.state.placeStartData.id, this.handleDistanceExistChange, this.handleMileageChange);
            this.setState({placeEndDataError: false});
        } else {
            this.handleDistanceExistChange(false);
            this.handleMileageChange({target: {value: 0}});
        }

        if (value === null) {
            this.setState({placeEndDataError: true});
        }
    }

    handleDistanceExistChange(distanceExist) {
        this.setState({distanceExist: distanceExist});
    }

    handleExpectedAmountChange(expectedAmount) {
        this.setState({expectedAmount: expectedAmount});
    }

    handleIsValidChange(isValid) {
        this.setState({isValid: isValid});
    }

    handleReceiptPictureChange(newReceiptPicture) {
        this.setState({receiptPicture: newReceiptPicture});
    }

    cleanForms() {
        this.setState({
            ticketTypeCode: '',
            selectedDate: moment().format("YYYY-MM-DD"),
            customer: "",
            employeeAmount: 0,
            vehicle: "",
            mileage: 0,
            purpose: "",
            siteOrMeeting: "",
            bedroomAmount: 0,
            breakfastAmount: 0,
            lunchAmount: 0,
            dinnerAmount: 0,
            placeStartData: null,
            placeEndData: null,
            distanceExist: false,
            expectedAmount: 0,
            receiptPicture: null,

            employeeAmountError: false,
            purposeError: false,
            placeStartDataError: false,
            placeEndDataError: false,
            mileageError: false,
            sumOfAmountsError: false,
        });
    }

    render() {

        let secondButton;

        if (!this.state.isEditable) {
            secondButton = <Button onClick={this.toggleIsEditable} color="primary"
                                   disabled={this.state.isArchived}>Modifier</Button>
        } else {
            secondButton = <><Button onClick={() => this.handleDeleteDialogIsOpen(true)}
                                     color="secondary">Supprimer</Button><Button onClick={this.updateTicket}
                                                                                 color="primary">Enregistrer</Button></>;
        }

        const res = FormTicket({
            ticketTypeCode: this.state.ticketTypeCode,
            customer: this.state.customer,
            handleCustomerChange: this.handleCustomerChange,
            employeeAmount: this.state.employeeAmount,
            handleEmployeeAmountChange: this.handleEmployeeAmountChange,
            employeeAmountError: this.state.employeeAmountError,
            siteOrMeeting: this.state.siteOrMeeting,
            handleSiteOrMeetingChange: this.handleSiteOrMeetingChange,
            purpose: this.state.purpose,
            handlePurposeChange: this.handlePurposeChange,
            purposeError: this.state.purposeError,
            vehicle: this.state.vehicle,
            handleVehiculeChange: this.handleVehiculeChange,
            mileage: this.state.mileage,
            handleMileageChange: this.handleMileageChange,
            mileageError: this.state.mileageError,
            placeStartData: this.state.placeStartData,
            handlePlaceStartDataChange: this.handlePlaceStartDataChange,
            placeStartDataError: this.state.placeStartDataError,
            placeEndData: this.state.placeEndData,
            handlePlaceEndDataChange: this.handlePlaceEndDataChange,
            placeEndDataError: this.state.placeEndDataError,
            allPlaces: this.props.allPlaces,
            handleAllPlacesChange: this.handleAllPlacesChange,
            expectedAmount: this.state.expectedAmount,
            distanceExist: this.state.distanceExist,
            handleDistanceExistChange: this.state.handleDistanceExistChange,
            isRoundTripHidden: true,
            isAddPlaceButtonHidden: !this.state.isEditable,
            bedroomAmount: this.state.bedroomAmount,
            handleBedroomAmountChange: this.handleBedroomAmountChange,
            breakfastAmount: this.state.breakfastAmount,
            handleBreakfastAmountChange: this.handleBreakfastAmountChange,
            lunchAmount: this.state.lunchAmount,
            handleLunchAmountChange: this.handleLunchAmountChange,
            dinnerAmount: this.state.dinnerAmount,
            handleDinnerAmountChange: this.handleDinnerAmountChange,
            sumOfAmountsError: this.state.sumOfAmountsError,
            receiptPicture: this.state.receiptPicture,
            handleReceiptPictureChange: null,
            disabled: !this.state.isEditable, // Veut-on que tous les elements affichés ne soient qu'en lecture seul ?
            marginTop: 10,
        });

        let ticketTypeExplication = res.ticketTypeExplication;
        let secondFormTicket = res.secondFormTicket;

        return (
            <Container>
                <Dialog open={this.props.modalTicketDetailsId !== -1}
                        onClose={() => this.props.handleModalTicketDetailsId(-1)}
                        aria-labelledby="form-dialog-detailsTicketDialog" fullWidth={true} maxWidth={"md"}
                >
                    <DialogTitle id="form-dialog-detailsTicketDialog">Détails du ticket</DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            {ticketTypeExplication}
                        </DialogContentText>

                        <Divider/>

                        {/* PREMIERE LIGNE : TYPE + ISVALID */}
                        <Grid container>
                            <div
                                style={{minHeight: '450px', minWidth: '100%'}}
                            >
                                <Grid container>
                                    {/* Selection du type de ticket*/}
                                    <Grid container justify="center" alignItems="center" spacing={1}>
                                        <Grid item xs={12} md={6}>
                                            <TextField select value={this.state.ticketTypeCode} label="Type de ticket *"
                                                       fullWidth onChange={() => null}
                                                       style={{"marginTop": 20 + "px"}} variant="outlined" disabled
                                            >
                                                {
                                                    getAllTicketsTypeOptionList(this.props.allTicketsCode, false)
                                                }
                                            </TextField>
                                        </Grid>

                                        {/* Le ticket est valide */}
                                        <Grid item xs={12} md={6}>
                                            <FormControlLabel
                                                value="start"
                                                control={
                                                    <Checkbox
                                                        checked={this.state.isValid}
                                                        color="primary"
                                                        name="isValid"
                                                    />
                                                }
                                                label="Ticket validé"
                                                labelPlacement="start"
                                                variant="outlined"
                                            />
                                        </Grid>
                                    </Grid>
                                </Grid>

                                {/* DEUXIEME LIGNE : DATE + ISARCHIVED */}
                                <Grid container>
                                    {/* Selection de la date du ticket */}
                                    <Grid container justify="center" alignItems="center" spacing={1}>
                                        <Grid item xs={12} md={6}>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils} locale={frLocale}>
                                                {/* Choix de la date du ticket */}
                                                <KeyboardDatePicker
                                                    disableToolbar
                                                    variant="inline"
                                                    format="dd/MM/yyyy"
                                                    margin="normal"
                                                    id="date-picker-inline"
                                                    label="Date du justificatif *"
                                                    value={this.state.selectedDate}
                                                    onChange={this.handleSelectedDateChange}
                                                    KeyboardButtonProps={{
                                                        onFocus: () => {
                                                            this.handleIsOpenDatepicker(true);
                                                        }
                                                    }}
                                                    PopoverProps={{
                                                        disableRestoreFocus: true,
                                                        onClose: () => {
                                                            this.handleIsOpenDatepicker(false);
                                                        }
                                                    }}
                                                    InputProps={{
                                                        onFocus: () => {
                                                            this.handleIsOpenDatepicker(true);
                                                        },
                                                        disabled: !this.state.isEditable
                                                    }}
                                                    inputVariant="outlined"
                                                    open={this.state.isOpenDatepicker}
                                                    fullWidth
                                                />
                                            </MuiPickersUtilsProvider>
                                        </Grid>

                                        {/* Le ticket est archivé */}
                                        <Grid item xs={12} md={6}>
                                            <FormControlLabel
                                                value="start"
                                                control={
                                                    <Checkbox
                                                        checked={this.state.isArchived}
                                                        color="primary"
                                                        name="isArchived"
                                                    />
                                                }
                                                label="Ticket archivé"
                                                labelPlacement="start"
                                                variant="outlined"
                                            />
                                        </Grid>
                                    </Grid>
                                </Grid>
                                {/* DEBUT DU DEUXIEME CONTENUE LIE AU TYPE DE TICKET */}
                                {secondFormTicket}
                                {/* FIN DES CONTENUES LIE AU TYPE DE TICKET*/}
                            </div>
                        </Grid>
                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleModalTicketDetailsId(-1)} color="primary">
                            Retour
                        </Button>
                        {secondButton}
                    </DialogActions>
                </Dialog>
                <DeleteTicketDialog deleteDialogIsOpen={this.state.deleteDialogIsOpen}
                                    handleDeleteDialogIsOpen={this.handleDeleteDialogIsOpen}
                                    ticketId={this.props.modalTicketDetailsId}
                                    handleUpdateForMajNeeded={this.props.handleUpdateForMajNeeded}
                                    handleModalTicketDetailsId={this.props.handleModalTicketDetailsId}
                />
            </Container>
        );
    }
}

export default DetailsTicketDialog;