import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid,
    InputAdornment,
    TextField
} from '@material-ui/core';
import PlaceValue from "./components/components/PlaceValue";
import DistanceService from "../../../services/DistanceService";

/**
 * Composant permettant l'affichage du détails d'un ticket choisit.
 */
class DetailsDistanceDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isEditable: false, // Permet de savoir si on est en mode édition ou non

            // Places de départ et d'arrivé
            placeStartData: null,
            placeEndData: null,

            // Distance
            mileage: 0,

            // Gestion validation
            mileageError: false,
        };

        // Validation du formulaire
        this.formIsValid = this.formIsValid.bind(this);

        // Fonction permettant l'activation de la modification du formulaire
        this.toggleIsEditable = this.toggleIsEditable.bind(this);

        // Fonction appeler lors d'un clic sur le bouton enregistrer
        this.updateMileage = this.updateMileage.bind(this);

        // Fonction gérant la MAJ de l'input
        this.handleMileageChange = this.handleMileageChange.bind(this);

        // Fonction gérant l'initialisation de l'input
        this.handleInitData = this.handleInitData.bind(this);

        // Fonction permettant de clean le formulaire
        this.cleanForms = this.cleanForms.bind(this);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        // Si l'id de la place à changé
        // et qu'il est différent de -1
        // on récupère les données sur l'API
        if (prevProps.modalDistanceDetailsId !== this.props.modalDistanceDetailsId && this.props.modalDistanceDetailsId !== -1) {
            DistanceService.getDistanceById(this.props.modalDistanceDetailsId, this.handleInitData);
            this.setState({isEditable: false});
        }

        if (prevProps.modalDistanceDetailsId !== this.props.modalDistanceDetailsId && this.props.modalDistanceDetailsId === -1) {
            this.cleanForms();
        }
    }

    handleInitData(placeStartData, placeEndData, mileage) {
        this.setState({placeStartData: placeStartData, placeEndData: placeEndData, mileage: mileage});
    }

    formIsValid() {
        let isValid = true;

        // La distance doit etre > 0
        if (this.state.mileage <= 0) {
            this.setState({mileageError: true});
            isValid = false;
        } else {
            this.setState({mileageError: false});
        }

        return isValid;
    }

    toggleIsEditable() {
        this.setState({isEditable: !this.state.isEditable});
    }

    updateMileage() {
        if (this.formIsValid()) {
            DistanceService.updateDistance(this.props.modalDistanceDetailsId, this.state.placeStartData, this.state.placeEndData, this.state.mileage,
                this.props.doUpdate, this.toggleIsEditable, this.props.handleModalDistanceDetailsId);
        }
    }

    handleMileageChange(event) {
        this.setState({mileage: event.target.value, mileageError: event.target.value <= 0});
    }

    cleanForms() {
        this.setState({
            placeStartData: null,
            placeEndData: null,
            mileage: 0,
            mileageError: false,
        });
    }

    render() {

        let secondButton;

        if (!this.state.isEditable) {
            secondButton = <Button onClick={this.toggleIsEditable} color="primary">Modifier</Button>
        } else {
            secondButton = <Button onClick={this.updateMileage} color="primary">Enregistrer</Button>;
        }

        return (
            <Container>
                <Dialog open={this.props.modalDistanceDetailsId !== -1}
                        onClose={() => this.props.handleModalDistanceDetailsId(-1)}
                        aria-labelledby="form-dialog-detailsDistanceDialog" fullWidth={true} maxWidth={"md"}
                >
                    <DialogTitle id="form-dialog-detailsDistanceDialog">Détails de la distance</DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Modification de la distance selectionnée
                        </DialogContentText>

                        <Divider/>

                        <Grid container>
                            <Grid container justify="center" alignItems="center" spacing={1}>
                                <Grid item xs={12} md={10}>
                                    {/* Place de départ */}
                                    <PlaceValue label="Place de départ *" placeholder="Place de départ"
                                                selectKey="placeStartSelect"
                                                value={this.state.placeStartData}
                                                handler={this.state.handlePlaceStartDataChange}
                                                allPlaces={[this.state.placeStartData]}
                                                error={this.state.placeStartDataError}
                                                disabled={true}
                                    />
                                </Grid>
                                <Grid item xs={12} md={10}>
                                    {/* Place d'arrivé */}
                                    <PlaceValue label="Place d'arrivé *" placeholder="Place d'arrivé"
                                                selectKey="placeEndSelect"
                                                value={this.state.placeEndData}
                                                handler={this.state.handlePlaceEndDataChange}
                                                allPlaces={[this.state.placeEndData]}
                                                error={this.state.placeEndDataError}
                                                disabled={true}
                                    />
                                </Grid>
                                <Grid item xs={12} md={10}>
                                    <TextField type="number" value={this.state.mileage === 0 ? "" : this.state.mileage}
                                               inputProps={{"step": "0.001"}}
                                               onChange={this.handleMileageChange}
                                               fullWidth
                                               disabled={!this.state.isEditable}
                                               InputLabelProps={{shrink: true,}}
                                               InputProps={{
                                                   endAdornment: <InputAdornment position="end">km</InputAdornment>,
                                               }}
                                               label="Distance *"
                                               style={{"marginTop": "20px"}}
                                               variant="outlined"
                                               error={this.state.mileageError}
                                               placeholder="Distance (d'un aller)"
                                    />
                                </Grid>
                            </Grid>
                        </Grid>

                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleModalDistanceDetailsId(-1)} color="primary">
                            Retour
                        </Button>
                        {secondButton}
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default DetailsDistanceDialog;