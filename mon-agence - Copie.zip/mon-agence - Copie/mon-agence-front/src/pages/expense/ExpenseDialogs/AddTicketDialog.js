import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid,
    TextField
} from '@material-ui/core';
import {KeyboardDatePicker, MuiPickersUtilsProvider} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import frLocale from 'date-fns/locale/fr';
import TicketService from "../../../services/TicketService";
import moment from "moment";
import FormTicket from './components/FormTicket';
import {getAllTicketsTypeOptionList} from "../utilities";
import DistanceService from "../../../services/DistanceService";

/**
 * Composant permettant l'ajout d'un nouveau ticket.
 */
class AddTicketDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            // state lié à la première partie du formulaire
            ticketTypeCode: '',
            selectedDate: moment().format("YYYY-MM-DD"),

            // state lié au datepicker
            isOpenDatepicker: false,

            // state lié aux secondes parties du formulaire
            customer: "",
            employeeAmount: 0,
            vehicle: "",
            mileage: 0,
            purpose: "",
            siteOrMeeting: "",
            bedroomAmount: 0,
            breakfastAmount: 0,
            lunchAmount: 0,
            dinnerAmount: 0,
            placeStartData: null,
            placeEndData: null,
            distanceExist: false,
            expectedAmount: 0,
            isRoundTrip: true,
            receiptPicture: null,

            // state d'error liés à certains elements clefs
            // du formulaire
            employeeAmountError: false, // employeeAmount > 0
            purposeError: false, // purpose.length > 0
            placeStartDataError: false, // != null
            placeEndDataError: false, // != null
            mileageError: false, // mileage > 0     
            sumOfAmountsError: false, // Somme(bedroomAmount, breakfastAmount, lunchAmount, dinnerAmount) > 0
            mediaError: false, // est-ce qu'une image est présente ?
        };

        // Validation du formulaire
        this.formIsValid = this.formIsValid.bind(this);

        // Fonction appeler lors d'un clic sur le bouton d'ajout
        this.addNewTicket = this.addNewTicket.bind(this);

        // Fonction gérant l'affichage du datePicker
        this.handleIsOpenDatepicker = this.handleIsOpenDatepicker.bind(this);

        // Fonction gérant les MAJ des inputs
        this.handleTicketTypeCodeChange = this.handleTicketTypeCodeChange.bind(this);
        this.handleSelectedDateChange = this.handleSelectedDateChange.bind(this);
        this.handleCustomerChange = this.handleCustomerChange.bind(this);
        this.handleEmployeeAmountChange = this.handleEmployeeAmountChange.bind(this);
        this.handleVehiculeChange = this.handleVehiculeChange.bind(this);
        this.handleMileageChange = this.handleMileageChange.bind(this);
        this.handlePurposeChange = this.handlePurposeChange.bind(this);
        this.handleSiteOrMeetingChange = this.handleSiteOrMeetingChange.bind(this);
        this.handleBedroomAmountChange = this.handleBedroomAmountChange.bind(this);
        this.handleBreakfastAmountChange = this.handleBreakfastAmountChange.bind(this);
        this.handleLunchAmountChange = this.handleLunchAmountChange.bind(this);
        this.handleDinnerAmountChange = this.handleDinnerAmountChange.bind(this);
        this.handlePlaceStartDataChange = this.handlePlaceStartDataChange.bind(this);
        this.handlePlaceEndDataChange = this.handlePlaceEndDataChange.bind(this);
        this.handleDistanceExistChange = this.handleDistanceExistChange.bind(this);
        this.handleExpectedAmountChange = this.handleExpectedAmountChange.bind(this);
        this.handleIsRoundTripChange = this.handleIsRoundTripChange.bind(this);
        this.handleReceiptPictureChange = this.handleReceiptPictureChange.bind(this);

        // Fonction permettant de clean le formulaire
        this.cleanForms = this.cleanForms.bind(this);
    }

    static getDerivedStateFromProps(props, state) {
        if (state.ticketTypeCode === "") {
            // Si il y'a plus d'informations que juste "length" dans la liste des propriétés
            if (Object.getOwnPropertyNames(props.allTicketsCode).length > 1) {
                // On retourne le premier element de la liste de propriétés
                return {ticketTypeCode: Object.getOwnPropertyNames(props.allTicketsCode)[0]};
            }
        }
        return {ticketTypeCode: state.ticketTypeCode};
    }

    formIsValid() {
        let isValid = true;

        // L'image justificative ne doit pas être nulle SAUF pour le ticket 'EXCEPTIONAL_BUSINESS_TRAVEL'
        if (this.state.ticketTypeCode !== 'EXCEPTIONAL_BUSINESS_TRAVEL') {
            if (this.state.receiptPicture === null) {
                this.setState({mediaError: true});
                isValid = false;
            } else {
                this.setState({mediaError: false});
            }
        }

        // La valeur du ticker doit être > 0 SAUF pour les tickets 'EXCEPTIONAL_BUSINESS_TRAVEL' et 'LODGING_MEAL_BUSINESS'
        if (this.state.ticketTypeCode !== 'EXCEPTIONAL_BUSINESS_TRAVEL' && this.state.ticketTypeCode !== 'LODGING_MEAL_BUSINESS') {
            if (this.state.employeeAmount <= 0) {
                this.setState({employeeAmountError: true});
                isValid = false;
            } else {
                this.setState({employeeAmountError: false});
            }
        }

        // La taille du motif du ticket doit être > 0 pour les tickets 'VARIOUS_COST', 'FUEL' et 'VARIOUS_BUSINESS_TRAVEL'
        if (this.state.ticketTypeCode === 'VARIOUS_COST' ||
            this.state.ticketTypeCode === 'FUEL' ||
            this.state.ticketTypeCode === 'VARIOUS_BUSINESS_TRAVEL') {
            if (this.state.purpose.length <= 0) {
                this.setState({purposeError: true});
                isValid = false;
            } else {
                this.setState({purposeError: false});
            }
        }

        // Si le ticket est 'EXCEPTIONAL_BUSINESS_TRAVEL'
        if (this.state.ticketTypeCode === 'EXCEPTIONAL_BUSINESS_TRAVEL') {
            // Les informations de place de départ doivent être != null
            if (this.state.placeStartData === null) {
                this.setState({placeStartDataError: true});
                isValid = false;
            } else {
                this.setState({placeStartDataError: false});
            }
            // Les informations de place d'arrivée doivent être != null
            if (this.state.placeEndData === null) {
                this.setState({placeEndDataError: true});
                isValid = false;
            } else {
                this.setState({placeEndDataError: false});
            }
            // La distance doit être > 0
            if (this.state.mileage <= 0) {
                this.setState({mileageError: true});
                isValid = false;
            } else {
                this.setState({mileageError: false});
            }
        }

        // Si le ticket est 'LODGING_MEAL_BUSINESS'
        if (this.state.ticketTypeCode === 'LODGING_MEAL_BUSINESS') {
            // La somme des montants doit être > 0
            if (this.state.bedroomAmount + this.state.breakfastAmount + this.state.lunchAmount + this.state.dinnerAmount <= 0) {
                this.setState({sumOfAmountsError: true});
                isValid = false;
            } else {
                this.setState({sumOfAmountsError: false});
            }
        }

        return isValid;
    }

    addNewTicket() {
        // Si le formulaire est remplie avec les champs minimaux pour le type de ticket choisit
        if (this.formIsValid()) {
            // On ajoute le ticket
            TicketService.addNewTicket(this.state.ticketTypeCode, this.state.selectedDate, this.state.receiptPicture,
                this.state.customer, this.state.employeeAmount,
                this.state.vehicle, this.state.mileage, this.state.purpose,
                this.state.siteOrMeeting, this.state.bedroomAmount, this.state.breakfastAmount, this.state.lunchAmount, this.state.dinnerAmount,
                this.state.placeStartData, this.state.placeEndData, this.state.distanceExist, this.state.isRoundTrip,
                this.props.handleStartDateChange, this.props.handleEndDateChange,
                this.props.selectedStartDate, this.props.selectedEndDate, this.props.handleUpdateForMajNeeded);
            this.props.setModalAddTicketIsOpen(false);
            this.cleanForms();
        }
    }

    handleTicketTypeCodeChange(event) {
        this.cleanForms();
        this.setState({ticketTypeCode: event.target.value});

    }

    handleSelectedDateChange(date) {
        this.setState({selectedDate: date.toISOString().substr(0, 10)})
        this.handleIsOpenDatepicker(!this.state.isOpenDatepicker);
    }

    handleIsOpenDatepicker(isOpenDatepicker) {
        this.setState({isOpenDatepicker: isOpenDatepicker});
    }

    handleCustomerChange(event) {
        this.setState({customer: event.target.value});
    }

    handleEmployeeAmountChange(event) {
        this.setState({employeeAmount: event.target.value, employeeAmountError: event.target.value <= 0});
    }

    handleVehiculeChange(event) {
        this.setState({vehicle: event.target.value});
    }

    handleMileageChange(event) {
        this.setState({
            mileage: event.target.value, expectedAmount: event.target.value * this.props.mileageAllowance,
            mileageError: event.target.value <= 0
        });
    }

    handlePurposeChange(event) {
        this.setState({purpose: event.target.value, purposeError: event.target.value.length <= 0});
    }

    handleSiteOrMeetingChange(event) {
        this.setState({siteOrMeeting: event.target.value});
    }

    handleBedroomAmountChange(event) {
        this.setState({
            bedroomAmount: event.target.value
        });
        this.handleSumOfAmountsError(event.target.value, this.state.breakfastAmount, this.state.lunchAmount, this.state.dinnerAmount);
    }

    handleBreakfastAmountChange(event) {
        this.setState({
            breakfastAmount: event.target.value
        });
        this.handleSumOfAmountsError(this.state.bedroomAmount, event.target.value, this.state.lunchAmount, this.state.dinnerAmount);
    }

    handleLunchAmountChange(event) {
        this.setState({
            lunchAmount: event.target.value
        });
        this.handleSumOfAmountsError(this.state.bedroomAmount, this.state.breakfastAmount, event.target.value, this.state.dinnerAmount);
    }

    handleDinnerAmountChange(event) {
        this.setState({
            dinnerAmount: event.target.value
        });
        this.handleSumOfAmountsError(this.state.bedroomAmount, this.state.breakfastAmount, this.state.lunchAmount, event.target.value);
    }

    handleSumOfAmountsError(bedroom, breakfast, lunch, dinner) {
        this.setState({
                sumOfAmountsError: bedroom
                    + breakfast
                    + lunch
                    + dinner <= 0
            }
        )
    }

    handlePlaceStartDataChange(event, value) {
        this.setState({placeStartData: value});

        if (value !== null && this.state.placeEndData !== null) {
            DistanceService.getDistanceByPlaces(value.id, this.state.placeEndData.id, this.handleDistanceExistChange, this.handleMileageChange);
            this.setState({placeStartDataError: false});
        } else {
            this.handleDistanceExistChange(false);
            this.handleMileageChange({target: {value: 0}});
        }

        if (value === null) {
            this.setState({placeStartDataError: true});
        }
    }

    handlePlaceEndDataChange(event, value) {
        this.setState({placeEndData: value});

        if (value !== null && this.state.placeStartData !== null) {
            DistanceService.getDistanceByPlaces(value.id, this.state.placeStartData.id, this.handleDistanceExistChange, this.handleMileageChange);
            this.setState({placeEndDataError: false});
        } else {
            this.handleDistanceExistChange(false);
            this.handleMileageChange({target: {value: 0}});
        }

        if (value === null) {
            this.setState({placeEndDataError: true});
        }
    }

    handleDistanceExistChange(distanceExist) {
        this.setState({distanceExist: distanceExist});
    }

    handleExpectedAmountChange(expectedAmount) {
        this.setState({expectedAmount: expectedAmount});
    }

    handleIsRoundTripChange(event) {
        this.setState({isRoundTrip: event.target.checked});
    }

    handleReceiptPictureChange(newReceiptPicture) {
        this.setState({receiptPicture: newReceiptPicture});
    }

    cleanForms() {
        this.setState({
            ticketTypeCode: '',
            selectedDate: moment().format("YYYY-MM-DD"),
            customer: "",
            employeeAmount: 0,
            vehicle: "",
            mileage: 0,
            purpose: "",
            siteOrMeeting: "",
            bedroomAmount: 0,
            breakfastAmount: 0,
            lunchAmount: 0,
            dinnerAmount: 0,
            placeStartData: null,
            placeEndData: null,
            distanceExist: false,
            expectedAmount: 0,
            receiptPicture: null,

            employeeAmountError: false,
            purposeError: false,
            placeStartDataError: false,
            placeEndDataError: false,
            mileageError: false,
            sumOfAmountsError: false,
            mediaError: false,
        });
    }

    render() {

        const res = FormTicket({
            ticketTypeCode: this.state.ticketTypeCode,
            customer: this.state.customer,
            handleCustomerChange: this.handleCustomerChange,
            employeeAmount: this.state.employeeAmount,
            handleEmployeeAmountChange: this.handleEmployeeAmountChange,
            employeeAmountError: this.state.employeeAmountError,
            siteOrMeeting: this.state.siteOrMeeting,
            handleSiteOrMeetingChange: this.handleSiteOrMeetingChange,
            purpose: this.state.purpose,
            handlePurposeChange: this.handlePurposeChange,
            purposeError: this.state.purposeError,
            vehicle: this.state.vehicle,
            handleVehiculeChange: this.handleVehiculeChange,
            mileage: this.state.mileage,
            handleMileageChange: this.handleMileageChange,
            mileageError: this.state.mileageError,
            placeStartData: this.state.placeStartData,
            handlePlaceStartDataChange: this.handlePlaceStartDataChange,
            placeStartDataError: this.state.placeStartDataError,
            placeEndData: this.state.placeEndData,
            handlePlaceEndDataChange: this.handlePlaceEndDataChange,
            placeEndDataError: this.state.placeEndDataError,
            allPlaces: this.props.allPlaces,
            handleAllPlacesChange: this.handleAllPlacesChange,
            expectedAmount: this.state.expectedAmount,
            distanceExist: this.state.distanceExist,
            handleDistanceExistChange: this.state.handleDistanceExistChange,
            isRoundTrip: this.state.isRoundTrip,
            handleIsRoundTripChange: this.handleIsRoundTripChange,
            bedroomAmount: this.state.bedroomAmount,
            handleBedroomAmountChange: this.handleBedroomAmountChange,
            breakfastAmount: this.state.breakfastAmount,
            handleBreakfastAmountChange: this.handleBreakfastAmountChange,
            lunchAmount: this.state.lunchAmount,
            handleLunchAmountChange: this.handleLunchAmountChange,
            dinnerAmount: this.state.dinnerAmount,
            handleDinnerAmountChange: this.handleDinnerAmountChange,
            sumOfAmountsError: this.state.sumOfAmountsError,
            receiptPicture: this.state.receiptPicture,
            mediaError: this.state.mediaError,
            handleReceiptPictureChange: this.handleReceiptPictureChange,
            disabled: false, // Veut-on que tous les elements affichés ne soient qu'en lecture seul ?
            marginTop: 10,
        });

        let ticketTypeExplication = res.ticketTypeExplication;
        let secondFormTicket = res.secondFormTicket;

        return (
            <Container>
                <Dialog open={this.props.modalAddTicketIsOpen} onClose={() => {
                    this.props.setModalAddTicketIsOpen(false);
                    this.cleanForms();
                }}
                        aria-labelledby="form-dialog-addTicketDialog" fullWidth={true} maxWidth={"md"}
                >
                    <DialogTitle id="form-dialog-addTicketDialog">Ajout d'un nouveau ticket</DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION CONCERNANT LE TYPE DE TICKET CHOISIE */}
                        <DialogContentText>
                            {ticketTypeExplication}
                        </DialogContentText>

                        <Divider/>

                        {/* DEBUT DU PREMIER CONTENUE LIE A L AJOUT DE TICKET */}
                        <Grid container>
                            <div
                                style={{minHeight: '450px', minWidth: '100%'}}
                            >
                                <Grid container>

                                    {/* Selection du type de ticket*/}
                                    <Grid container justify="center" alignItems="center" spacing={1}>
                                        <Grid item xs={12} md={6}>
                                            <TextField select value={this.state.ticketTypeCode}
                                                       onChange={this.handleTicketTypeCodeChange}
                                                       label="Type de ticket *" fullWidth
                                                       style={{"marginTop": 10 + "px"}}
                                                       variant="outlined"
                                            >
                                                {
                                                    getAllTicketsTypeOptionList(this.props.allTicketsCode, false)
                                                }
                                            </TextField>
                                        </Grid>

                                        {/* Selection de la date du ticket */}
                                        <Grid item xs={12} md={6}>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils} locale={frLocale}>
                                                {/* Choix de la date du ticket */}
                                                <KeyboardDatePicker
                                                    disableToolbar
                                                    variant="inline"
                                                    format="dd/MM/yyyy"
                                                    margin="normal"
                                                    id="date-picker-inline"
                                                    label="Date du justificatif *"
                                                    value={this.state.selectedDate}
                                                    onChange={this.handleSelectedDateChange}
                                                    KeyboardButtonProps={{
                                                        onFocus: () => {
                                                            this.handleIsOpenDatepicker(true);
                                                        }
                                                    }}
                                                    PopoverProps={{
                                                        disableRestoreFocus: true,
                                                        onClose: () => {
                                                            this.handleIsOpenDatepicker(false);
                                                        }
                                                    }}
                                                    InputProps={{
                                                        onFocus: () => {
                                                            this.handleIsOpenDatepicker(true);
                                                        }
                                                    }}
                                                    inputVariant="outlined"
                                                    open={this.state.isOpenDatepicker}
                                                    fullWidth
                                                />
                                            </MuiPickersUtilsProvider>
                                        </Grid>
                                    </Grid>
                                </Grid>
                                {/* DEBUT DU DEUXIEME CONTENUE LIE AU TYPE DE TICKET */}
                                {secondFormTicket}
                                {/* FIN DES CONTENUES LIE AU TYPE DE TICKET*/}
                            </div>
                        </Grid>
                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.setModalAddTicketIsOpen(false)} color="primary">
                            Annuler
                        </Button>
                        <Button onClick={this.addNewTicket} color="primary">
                            Ajouter
                        </Button>
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default AddTicketDialog;