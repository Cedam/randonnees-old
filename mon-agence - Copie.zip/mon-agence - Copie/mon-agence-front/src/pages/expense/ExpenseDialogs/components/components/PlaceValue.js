import React from 'react';
import {Grid, TextField} from "@material-ui/core";
import Autocomplete from '@material-ui/lab/Autocomplete';

/**
 * Sous-composant pouvant être utilisé pour gérer la selection d'une valeur de type 'Place'.
 */
class PlaceValue extends React.Component {
    render() {

        const defaultProps = {
            options: this.props.allPlaces,
            getOptionLabel: (place) => place.name,
            getOptionSelected: (option, value) => value.id === option.id,
        };

        // Liste déroulante des places
        return (
            <Grid item xs>
                <Autocomplete
                    {...defaultProps}
                    id={this.props.selectKey}
                    clearOnEscape
                    fullWidth
                    value={this.props.value}
                    onChange={this.props.handler}
                    disabled={this.props.disabled}
                    renderInput={(params) => <TextField {...params}
                                                        label={this.props.label}
                                                        placeholder={this.props.placeholder}
                                                        margin="normal"
                                                        variant="outlined"
                                                        InputLabelProps={{shrink: true,}}
                                                        error={this.props.error}
                                                        disabled={this.props.disabled}
                    />}
                />
            </Grid>
        );
    }
}

export default PlaceValue;