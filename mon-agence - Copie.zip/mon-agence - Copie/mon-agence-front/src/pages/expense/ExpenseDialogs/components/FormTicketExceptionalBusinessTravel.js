import React from 'react';
import {Box, Button, FormControlLabel, Grid, InputAdornment, Switch, TextField} from "@material-ui/core";
import NoteAddIcon from '@material-ui/icons/NoteAddOutlined';

import MoneyValue from './components/MoneyValue';
import TextValue from './components/TextValue';
import PlaceValue from './components/PlaceValue';

import AddPlaceDialog from '../AddPlaceDialog';
import PlaceService from "../../../../services/PlaceService";

/**
 * Formulaire "Déplacement exceptionnel".
 */
class FormTicketExceptionalBusinessTravel extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            modalAddPlaceIsOpen: false,
        };

        this.setModalAddTicketIsOpen = this.setModalAddTicketIsOpen.bind(this);
        this.doUpdate = this.doUpdate.bind(this);
    }

    setModalAddTicketIsOpen(isOpen) {
        this.setState({modalAddPlaceIsOpen: isOpen});
    }

    doUpdate() {
        PlaceService.getAllPlacesList(this.props.handleAllPlacesChange);
    }

    render() {

        let roundTripComponent = "";
        let addPlaceComponent = "";

        // // Dois-je ajouter le switch aller-retour ?
        if (!this.props.isRoundTripHidden) {
            roundTripComponent = <FormControlLabel
                value="start"
                control={
                    <Switch
                        checked={this.props.isRoundTrip}
                        onChange={this.props.handleIsRoundTripChange}
                        color="primary"
                        name="isRoundTrip"
                        disabled={this.props.disabled}
                    />
                }
                label="Trajet aller-retour"
                labelPlacement="start"
                style={{"marginTop": this.props.marginTop + 5 + "px"}}
                variant="outlined"
            />;
        }

        // Dois-je ajouter le bouton d'ajout de place
        if (!this.props.isAddPlaceButtonHidden) {
            addPlaceComponent = <Box mt={this.props.marginTop + 5 + "px"}>
                <Button variant="contained"
                        disableElevation
                        onClick={() => this.setModalAddTicketIsOpen(true)}
                        disabled={this.props.disabled}
                        startIcon={<NoteAddIcon/>}
                >
                    Ajouter une place
                </Button>
            </Box>;
        }

        return (
            <Grid container>
                <Grid container justify="center" alignItems="center" spacing={1}>
                    <Grid item xs={12} md={6}>
                        {/* Véhicule utilisé */}
                        <TextValue label="Véhicule" placeholder="Véhicule" value={this.props.vehicle}
                                   handler={this.props.handleVehiculeChange}
                                   marginTop={this.props.marginTop} disabled={this.props.disabled}
                        />
                    </Grid>
                    <Grid item xs={12} md={6}>
                        {/* Nom du client */}
                        <TextValue label="Client" placeholder="Client" value={this.props.customer}
                                   handler={this.props.handleCustomerChange}
                                   marginTop={this.props.marginTop} disabled={this.props.disabled}
                        />
                    </Grid>
                </Grid>

                <Grid container justify="center" alignItems="center" spacing={1}>
                    <Grid item xs={12} md={6}>
                        {/* Place de départ */}
                        <PlaceValue label="Place de départ *" placeholder="Place de départ" selectKey="placeStartSelect"
                                    value={this.props.placeStartData}
                                    handler={this.props.handlePlaceStartDataChange} allPlaces={this.props.allPlaces}
                                    error={this.props.placeStartDataError}
                                    marginTop={this.props.marginTop} disabled={this.props.disabled}
                        />
                    </Grid>
                    <Grid item xs={12} md={6}>
                        {/* Place d'arrivé */}
                        <PlaceValue label="Place d'arrivée *" placeholder="Place d'arrivée" selectKey="placeEndSelect"
                                    value={this.props.placeEndData}
                                    handler={this.props.handlePlaceEndDataChange} allPlaces={this.props.allPlaces}
                                    error={this.props.placeEndDataError}
                                    marginTop={this.props.marginTop} disabled={this.props.disabled}
                        />
                    </Grid>
                </Grid>

                <Grid container justify="center" alignItems="center" spacing={1}>
                    <Grid item xs={12} md={6}>
                        {/* Kilomètre parcouru */}
                        {/* Si une distance entre les deux places choisies existe dans la BD, bloquer ce champs
                            avec la valeur de la BD. Sinon le débloquer et penser à ajouter la nouvelle distance en BD*/}
                        <TextField type="number" value={this.props.mileage === 0 ? "" : this.props.mileage}
                                   inputProps={{"step": "0.001"}} onChange={this.props.handleMileageChange} fullWidth
                                   disabled={this.props.disabled ? true : this.props.distanceExist}
                                   InputLabelProps={{shrink: true,}}
                                   InputProps={{endAdornment: <InputAdornment position="end">km</InputAdornment>,}}
                                   label="Distance *"
                                   style={{"marginTop": this.props.marginTop + "px"}} variant="outlined"
                                   error={this.props.mileageError}
                                   placeholder="Distance (d'un aller)"
                        />
                    </Grid>

                    <Grid item xs={12} md={6}>
                        {/* Valeur considéré comme payée par l'employé : */}
                        <MoneyValue label="Valeur considéré comme payée par l'employé"
                                    placeholder="Valeur considéré comme payée par l'employé"
                                    value={this.props.expectedAmount.toFixed(2)} disabled={true}
                                    marginTop={this.props.marginTop}
                        />
                    </Grid>

                </Grid>

                <Grid container justify="center" alignItems="center">
                    <Grid container item xs={12} md={6} justify="center" alignItems="center">
                        {/* Bouton permettant l'ajout d'une place */}
                        {addPlaceComponent}
                    </Grid>
                    <Grid container item xs={12} md={6} justify="center" alignItems="center">
                        {/* Le trajet est-il en aller-retour ? */}
                        {roundTripComponent}
                    </Grid>
                </Grid>

                <AddPlaceDialog addPlaceDialogIsOpen={this.state.modalAddPlaceIsOpen}
                                handleAddPlaceDialogIsOpen={this.setModalAddTicketIsOpen}
                                doUpdate={this.doUpdate}
                />

            </Grid>

        );
    }
}

export default FormTicketExceptionalBusinessTravel;