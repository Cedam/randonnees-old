import React from 'react';
import {Grid, TextField} from "@material-ui/core";

/**
 * Sous-composant pouvant être utilisé pour gérer l'entrée d'une valeur de type texte.
 */
class TextValue extends React.Component {
    render() {
        return (
            <Grid item xs>
                <TextField type="text" value={this.props.value} onChange={this.props.handler} fullWidth
                           label={this.props.label}
                           style={{"marginTop": this.props.marginTop + "px"}} placeholder={this.props.placeholder}
                           InputLabelProps={{shrink: true,}}
                           variant="outlined" error={this.props.error} disabled={this.props.disabled}
                />
            </Grid>
        );
    }
}

export default TextValue;