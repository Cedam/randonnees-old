import React from 'react';
import {Grid, IconButton, Paper, Typography} from "@material-ui/core";
import {GlassMagnifier,} from "react-image-magnifiers";
import Resizer from "react-image-file-resizer";
import DeleteIcon from '@material-ui/icons/Delete';
import ImageIcon from '@material-ui/icons/Image';
import BrokenImageIcon from '@material-ui/icons/BrokenImage';
import snackbarStore from "../../../../../store/SnackbarStore";

/**
 * Sous-composant pouvant être utilisé pour gérer la selection d'une image justificative.
 */
class MediaValue extends React.Component {
    // Variable permettant si savoir si le composant est monté ou non afin
    // de bloquer le setState dans les réponses de requetes asynchrones
    _isMounted = false;

    constructor(props) {
        super(props);

        this.state = {
            smallReceiptPicture: null
        };

        this.onSelectPicture = this.onSelectPicture.bind(this);
        this.updateSmallReceiptPicture = this.updateSmallReceiptPicture.bind(this);
    }

    componentDidMount() {
        this._isMounted = true;

        // Si une receiptPicture existe, on initialise sa version plus petite
        if (this.props.receiptPicture !== null) {
            this.updateSmallReceiptPicture(this.props.receiptPicture);
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.receiptPicture !== this.props.receiptPicture) {
            if (this.props.receiptPicture !== null) {
                this.updateSmallReceiptPicture(this.props.receiptPicture);
            } else {
                this.setState({smallReceiptPicture: null});
            }
        }
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    onSelectPicture(event) {
        // Si un fichier est présent
        if (event.target.files.length > 0) {

            const maxMo = 5; // 5 Mo maximum
            const maxPictureSize = 1024 * 1024 * maxMo; // valeur en bytes

            // Si la taille du fichier est < au maximum autorisé
            if (event.target.files[0].size < maxPictureSize) {
                // MAJ de l'image chez le parent
                this.props.handleReceiptPictureChange(event.target.files[0]);
            } else {
                // On prévient l'utilisateur que l'on dépasse la taille autorisée
                snackbarStore.addSnackbarError("Votre image ne doit pas dépasser " + maxMo + " Mo au maximum.");
            }
        }
    }

    updateSmallReceiptPicture(receiptPicture) {
        if(receiptPicture !== null && receiptPicture !== undefined) {
            Resizer.imageFileResizer(
                receiptPicture,
                300,
                300,
                'JPEG',
                100,
                0,
                uri => {
                    if(this._isMounted) {
                        this.setState({smallReceiptPicture: uri});
                    }
                },
                'blob',
                200,
                200,
            );
        }
        this.setState({smallReceiptPicture: null});
    }

    render() {
        let receiptComponent;
        let deletePictureButton = null;

        if (this.props.receiptPicture === null) {
            if (this.props.disabled) {
                receiptComponent = <IconButton
                    variant={"contained"}
                    component={"label"}
                    disabled={true}>
                    <BrokenImageIcon fontSize={"large"}/>
                </IconButton>
            } else {
                receiptComponent = <IconButton
                    variant="contained"
                    component="label"
                    disabled={this.props.disabled}
                >
                    <ImageIcon fontSize="large" color={this.props.mediaError ? "secondary" : "inherit"}/>
                    <input
                        type="file"
                        accept=".jpg,.jpeg,.png"
                        style={{display: "none"}}
                        onChange={this.onSelectPicture}
                        disabled={this.props.disabled}
                    />
                </IconButton>
            }
        } else {
            receiptComponent = <>
                <GlassMagnifier
                    imageSrc={(this.state.smallReceiptPicture !== null) ?
                        URL.createObjectURL(this.state.smallReceiptPicture) :
                        URL.createObjectURL(this.props.receiptPicture)}
                    imageAlt={"Vous ne devriez pas voir cela."}
                    largeImageSrc={URL.createObjectURL(this.props.receiptPicture)}
                    magnifierSize={"60%"}
                    allowOverflow={false}
                    magnifierBorderSize={2}
                />
            </>;

            if(this.props.handleReceiptPictureChange !== null && this.props.handleReceiptPictureChange !== undefined) {
                deletePictureButton =
                    <IconButton aria-label="deleteReceiptPicture"
                                onClick={() => {this.props.handleReceiptPictureChange(null)}}
                                color={"inherit"}
                                disabled={this.props.disabled}>
                        <DeleteIcon fontSize="small"/>
                    </IconButton>;
            }
        }

        return (
            <Grid item xs>
                <Paper className="paper" style={{"marginTop": this.props.marginTop + "px"}}>

                    <Typography variant="subtitle1" gutterBottom style={{"marginLeft": "10px"}}>
                        <Grid container>
                            <Grid container item xs={6} style={{"marginTop": "10px"}}>Justificatif *</Grid>
                            <Grid container item xs={6} justify="flex-end">{deletePictureButton}</Grid>
                        </Grid>
                    </Typography>

                    <Grid container alignItems="center" justify="center"
                          style={{"minHeight": "300px", "maxHeight": "300px"}}>
                        {receiptComponent}
                    </Grid>

                </Paper>
            </Grid>
        );
    }
}

export default MediaValue;