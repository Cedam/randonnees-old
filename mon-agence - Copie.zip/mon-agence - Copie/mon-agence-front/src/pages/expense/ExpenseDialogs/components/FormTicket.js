import React from 'react';

import FormTicketCustomerMealCost from "./FormTicketCustomerMealCost";
import FormTicketExceptionalBusinessTravel from "./FormTicketExceptionalBusinessTravel";
import FormTicketFuel from "./FormTicketFuel";
import FormTicketLodgingMealBusiness from "./FormTicketLodgingMealBusiness";
import FormTicketSiteMealCost from "./FormTicketSiteMealCost";
import FormTicketVariousBusinessTravel from "./FormTicketVariousBusinessTravel";
import FormTicketVariousCost from "./FormTicketVariousCost";

/**
 * Fonction permettant de récuperer le second morceau des formulaires d'ajout / modification
 * concernant les données propres à un type de ticket ainsi qu'une phrase explicative concernant
 * ce type de ticket
 *
 * @param props
 * @returns {{ticketTypeExplication: JSX.Element, secondFormTicket: JSX.Element}}
 * @constructor
 */
export default function FormTicket(props) {
    const marginTop = 10;

    let ticketTypeExplication;
    let secondFormTicket;

    switch (props.ticketTypeCode) {
        case 'CUSTOMER_MEAL_COST':
            ticketTypeExplication = <span>Tickets liés aux frais de repas client. (En attente de la réponse de Charles)</span>;
            secondFormTicket = <FormTicketCustomerMealCost
                customer={props.customer} handleCustomerChange={props.handleCustomerChange}
                employeeAmount={props.employeeAmount} handleEmployeeAmountChange={props.handleEmployeeAmountChange}
                employeeAmountError={props.employeeAmountError}
                receiptPicture={props.receiptPicture} handleReceiptPictureChange={props.handleReceiptPictureChange}
                mediaError={props.mediaError}
                disabled={props.disabled}
                marginTop={marginTop}
            />;
            break;
        case 'SITE_MEAL_COST':
            ticketTypeExplication = <span>Tickets liés aux frais de repas de chantier et réunion de travail. (En attente de la réponse de Charles)</span>;
            secondFormTicket = <FormTicketSiteMealCost
                siteOrMeeting={props.siteOrMeeting} handleSiteOrMeetingChange={props.handleSiteOrMeetingChange}
                employeeAmount={props.employeeAmount} handleEmployeeAmountChange={props.handleEmployeeAmountChange}
                employeeAmountError={props.employeeAmountError}
                receiptPicture={props.receiptPicture} handleReceiptPictureChange={props.handleReceiptPictureChange}
                mediaError={props.mediaError}
                disabled={props.disabled}
                marginTop={marginTop}
            />;
            break;
        case 'VARIOUS_COST':
            ticketTypeExplication = <span>Tickets liés aux frais divers hors déplacement. (materiel, welcome pack, poste, ...)</span>;
            secondFormTicket = <FormTicketVariousCost
                purpose={props.purpose} handlePurposeChange={props.handlePurposeChange}
                purposeError={props.purposeError}
                customer={props.customer} handleCustomerChange={props.handleCustomerChange}
                employeeAmount={props.employeeAmount} handleEmployeeAmountChange={props.handleEmployeeAmountChange}
                employeeAmountError={props.employeeAmountError}
                receiptPicture={props.receiptPicture} handleReceiptPictureChange={props.handleReceiptPictureChange}
                mediaError={props.mediaError}
                disabled={props.disabled}
                marginTop={marginTop}
            />;
            break;
        case 'EXCEPTIONAL_BUSINESS_TRAVEL':
            ticketTypeExplication = <span>Tickets liés aux frais de déplacements exceptionnels.</span>;
            secondFormTicket = <FormTicketExceptionalBusinessTravel
                vehicle={props.vehicle} handleVehiculeChange={props.handleVehiculeChange}
                mileage={props.mileage} handleMileageChange={props.handleMileageChange}
                mileageError={props.mileageError}
                customer={props.customer} handleCustomerChange={props.handleCustomerChange}
                placeStartData={props.placeStartData} handlePlaceStartDataChange={props.handlePlaceStartDataChange}
                placeStartDataError={props.placeStartDataError}
                placeEndData={props.placeEndData} handlePlaceEndDataChange={props.handlePlaceEndDataChange}
                placeEndDataError={props.placeEndDataError}
                allPlaces={props.allPlaces} handleAllPlacesChange={props.handleAllPlacesChange}
                expectedAmount={props.expectedAmount}
                distanceExist={props.distanceExist} handleDistanceExistChange={props.handleDistanceExistChange}
                isRoundTrip={props.isRoundTripHidden ? null : props.isRoundTrip}
                handleIsRoundTripChange={props.isRoundTripHidden ? null : props.handleIsRoundTripChange}
                isRoundTripHidden={props.isRoundTripHidden}
                isAddPlaceButtonHidden={props.isAddPlaceButtonHidden}
                disabled={props.disabled}
                marginTop={marginTop}
            />;
            break;
        case 'FUEL':
            ticketTypeExplication = <span>Tickets liés aux frais de carburants.</span>;
            secondFormTicket = <FormTicketFuel
                purpose={props.purpose} handlePurposeChange={props.handlePurposeChange}
                purposeError={props.purposeError}
                customer={props.customer} handleCustomerChange={props.handleCustomerChange}
                employeeAmount={props.employeeAmount} handleEmployeeAmountChange={props.handleEmployeeAmountChange}
                employeeAmountError={props.employeeAmountError}
                receiptPicture={props.receiptPicture} handleReceiptPictureChange={props.handleReceiptPictureChange}
                mediaError={props.mediaError}
                disabled={props.disabled}
                marginTop={marginTop}
            />;
            break;
        case 'VARIOUS_BUSINESS_TRAVEL':
            ticketTypeExplication =
                <span>Tickets liés aux frais divers suite à un déplacement (parking, péage, téléphone, ...).</span>;
            secondFormTicket = <FormTicketVariousBusinessTravel
                purpose={props.purpose} handlePurposeChange={props.handlePurposeChange}
                purposeError={props.purposeError}
                customer={props.customer} handleCustomerChange={props.handleCustomerChange}
                employeeAmount={props.employeeAmount} handleEmployeeAmountChange={props.handleEmployeeAmountChange}
                employeeAmountError={props.employeeAmountError}
                receiptPicture={props.receiptPicture} handleReceiptPictureChange={props.handleReceiptPictureChange}
                mediaError={props.mediaError}
                disabled={props.disabled}
                marginTop={marginTop}
            />;
            break;
        case 'LODGING_MEAL_BUSINESS':
            ticketTypeExplication = <span>Tickets liés aux frais d'hébergements et de repas individuels.</span>;
            secondFormTicket = <FormTicketLodgingMealBusiness
                bedroomAmount={props.bedroomAmount} handleBedroomAmountChange={props.handleBedroomAmountChange}
                breakfastAmount={props.breakfastAmount} handleBreakfastAmountChange={props.handleBreakfastAmountChange}
                lunchAmount={props.lunchAmount} handleLunchAmountChange={props.handleLunchAmountChange}
                dinnerAmount={props.dinnerAmount} handleDinnerAmountChange={props.handleDinnerAmountChange}
                customer={props.customer} handleCustomerChange={props.handleCustomerChange}
                sumOfAmountsError={props.sumOfAmountsError}
                receiptPicture={props.receiptPicture} handleReceiptPictureChange={props.handleReceiptPictureChange}
                mediaError={props.mediaError}
                disabled={props.disabled}
                marginTop={marginTop}
            />;
            break;
        default:
            ticketTypeExplication =
                <span>Si vous voyez ce message, une erreur est survenue : Le ticket choisit n'est pas géré par le système.</span>;
            secondFormTicket = null;
    }

    ticketTypeExplication =
        <span>{ticketTypeExplication}<span>Tous les champs * doivent être renseignés. Au moins un des champs ** doit être renseigné.</span></span>;

    return ({ticketTypeExplication, secondFormTicket});
}