import React from 'react';
import {Grid} from "@material-ui/core";

import MoneyValue from './components/MoneyValue';
import TextValue from './components/TextValue';
import MediaValue from './components/MediaValue';

/**
 * Formulaire "Frais divers non lié à un déplacement".
 */
class FormTicketVariousCost extends React.Component {
    render() {
        return (
            <Grid container>
                <Grid container justify="center" spacing={1}>
                    {/* Colonne de gauche */}
                    <Grid item xs={12} md={6}>
                        <Grid container
                              spacing={2}
                              direction="column"
                        >
                            {/* Ecriture du la raison */}
                            <TextValue label="Motif *" placeholder="Motif" value={this.props.purpose}
                                       handler={this.props.handlePurposeChange}
                                       error={this.props.purposeError} marginTop={this.props.marginTop}
                                       disabled={this.props.disabled}
                            />

                            {/* Nom du client */}
                            <TextValue label="Client" placeholder="Client" value={this.props.customer}
                                       handler={this.props.handleCustomerChange}
                                       disabled={this.props.disabled}
                            />

                            {/* Valeur du ticket*/}
                            <MoneyValue label="Valeur du ticket *" placeholder="Valeur du ticket"
                                        value={this.props.employeeAmount}
                                        handler={this.props.handleEmployeeAmountChange}
                                        error={this.props.employeeAmountError} disabled={this.props.disabled}
                            />

                        </Grid>
                    </Grid>

                    {/* Colonne de droite */}
                    <Grid item xs={12} md={6}>
                        {/* Image justificative */}
                        <MediaValue receiptPicture={this.props.receiptPicture}
                                    handleReceiptPictureChange={this.props.handleReceiptPictureChange}
                                    mediaError={this.props.mediaError}
                                    marginTop={this.props.marginTop}
                                    disabled={this.props.disabled}
                        />
                    </Grid>
                </Grid>
            </Grid>
        );
    }
}

export default FormTicketVariousCost;