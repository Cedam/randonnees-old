import React from 'react';
import {Grid} from "@material-ui/core";

import MoneyValue from './components/MoneyValue';
import TextValue from './components/TextValue';
import MediaValue from './components/MediaValue';

/**
 * Formulaire "Frais de repas et d'hébergement individuel".
 */
class FormTicketLodgingMealBusiness extends React.Component {
    render() {
        return (
            <Grid container>

                <Grid container justify="center" spacing={1}>
                    {/* Colonne de gauche */}
                    <Grid item xs={12} md={6}>
                        <Grid container
                              spacing={2}
                              direction="column"
                        >

                            {/* Nom du client */}
                            <TextValue label="Client" placeholder="Client" value={this.props.customer}
                                       handler={this.props.handleCustomerChange}
                                       marginTop={10} disabled={this.props.disabled}
                            />

                            {/* Valeur du ticket pour la chambre*/}
                            <MoneyValue label="Prix de la chambre **" placeholder="Prix de la chambre"
                                        value={this.props.bedroomAmount}
                                        handler={this.props.handleBedroomAmountChange}
                                        error={this.props.sumOfAmountsError}
                                        disabled={this.props.disabled}
                            />

                            {/* Valeur du ticket pour le petit déjeuner*/}
                            <MoneyValue label="Prix du petit déjeuner **" placeholder="Prix du petit déjeuner"
                                        value={this.props.breakfastAmount}
                                        handler={this.props.handleBreakfastAmountChange}
                                        error={this.props.sumOfAmountsError} disabled={this.props.disabled}
                            />

                            {/* Valeur du ticket pour le déjeuner*/}
                            <MoneyValue label="Prix du déjeuner **" placeholder="Prix du déjeuner"
                                        value={this.props.lunchAmount}
                                        handler={this.props.handleLunchAmountChange}
                                        error={this.props.sumOfAmountsError} disabled={this.props.disabled}
                            />

                            {/* Valeur du ticket pour le diner*/}
                            <MoneyValue label="Prix du diner **" placeholder="Prix du diner"
                                        value={this.props.dinnerAmount}
                                        handler={this.props.handleDinnerAmountChange}
                                        error={this.props.sumOfAmountsError} disabled={this.props.disabled}
                            />
                        </Grid>
                    </Grid>

                    {/* Colonne de droite */}
                    <Grid item xs={12} md={6}>
                        {/* Image justificative */}
                        <MediaValue receiptPicture={this.props.receiptPicture}
                                    handleReceiptPictureChange={this.props.handleReceiptPictureChange}
                                    mediaError={this.props.mediaError}
                                    marginTop={this.props.marginTop}
                                    disabled={this.props.disabled}
                        />
                    </Grid>
                </Grid>
            </Grid>
        );
    }
}

export default FormTicketLodgingMealBusiness;