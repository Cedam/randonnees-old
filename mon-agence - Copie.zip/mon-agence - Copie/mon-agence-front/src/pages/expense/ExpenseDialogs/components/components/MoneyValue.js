import React from 'react';
import {Grid, InputAdornment, TextField} from "@material-ui/core";

/**
 * Sous-composant pouvant être utilisé pour gérer l'entrée d'une valeur de type monètaire.
 */
class MoneyValue extends React.Component {
    render() {
        return (
            <Grid item xs>
                <TextField type="number" inputProps={{"step": "0.01"}}
                           value={this.props.value === 0 ? "" : this.props.value} onChange={this.props.handler}
                           disabled={this.props.disabled} fullWidth label={this.props.label}
                           InputProps={{endAdornment: <InputAdornment position="end">€</InputAdornment>,}}
                           style={{"marginTop": this.props.marginTop + "px"}} variant="outlined"
                           InputLabelProps={{shrink: true,}}
                           placeholder={this.props.placeholder} error={this.props.error}
                />
            </Grid>
        );
    }
}

export default MoneyValue;