import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid,
    TextField
} from '@material-ui/core';
import PlaceService from "../../../services/PlaceService";

/**
 * Composant permettant l'affichage du détails d'une place choisit.
 */
class DetailsPlaceDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isEditable: false, // Permet de savoir si on est en mode édition ou non

            // Nom de la place
            placeName: "",

            // Gestion validation
            placeNameError: false,
        };

        // Validation du formulaire
        this.formIsValid = this.formIsValid.bind(this);

        // Fonction permettant l'activation de la modification du formulaire
        this.toggleIsEditable = this.toggleIsEditable.bind(this);

        // Fonction appeler lors d'un clic sur le bouton enregistrer
        this.updatePlace = this.updatePlace.bind(this);

        // Fonction gérant la MAJ de l'input
        this.handlePlaceNameChange = this.handlePlaceNameChange.bind(this);

        // Fonction gérant l'initialisation de l'input
        this.handleInitPlaceName = this.handleInitPlaceName.bind(this);

        // Fonction permettant de clean le formulaire
        this.cleanForms = this.cleanForms.bind(this);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        // Si l'id de la place à changé
        // et qu'il est différent de -1
        // on récupère les données sur l'API
        if (prevProps.modalPlaceDetailsId !== this.props.modalPlaceDetailsId && this.props.modalPlaceDetailsId !== -1) {
            PlaceService.getPlaceById(this.props.modalPlaceDetailsId, this.handleInitPlaceName);
            this.setState({isEditable: false});
        }

        if (prevProps.modalPlaceDetailsId !== this.props.modalPlaceDetailsId && this.props.modalPlaceDetailsId === -1) {
            this.cleanForms();
        }
    }

    handleInitPlaceName(newPlaceName) {
        this.setState({placeName: newPlaceName});
    }

    handlePlaceNameChange(event) {
        this.setState({placeName: event.target.value});
    }

    formIsValid() {
        let isValid = true;

        // La taille du nom de la place doit être > 0
        if (this.state.placeName.length <= 0) {
            this.setState({placeNameError: true});
            isValid = false;
        } else {
            this.setState({placeNameError: false});
        }

        return isValid;
    }

    toggleIsEditable() {
        this.setState({isEditable: !this.state.isEditable});
    }

    updatePlace() {
        if (this.formIsValid()) {
            PlaceService.updatePlace(this.props.modalPlaceDetailsId, this.state.placeName, this.props.doUpdate, this.toggleIsEditable,
                this.props.handleModalPlaceDetailsId);
        }
    }

    cleanForms() {
        this.setState({
            // Nom de la place
            placeName: "",

            // Gestion validation
            placeNameError: false,
        });
    }

    render() {

        let secondButton;

        if (!this.state.isEditable) {
            secondButton = <Button onClick={this.toggleIsEditable} color="primary">Modifier</Button>
        } else {
            secondButton = <Button onClick={this.updatePlace} color="primary">Enregistrer</Button>;
        }

        return (
            <Container>
                <Dialog open={this.props.modalPlaceDetailsId !== -1}
                        onClose={() => this.props.handleModalPlaceDetailsId(-1)}
                        aria-labelledby="form-dialog-detailsPlaceDialog" fullWidth={true} maxWidth={"md"}
                >
                    <DialogTitle id="form-dialog-detailsPlaceDialog">Détails de la Place</DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Modification du nom de la place sélectionnée.
                        </DialogContentText>

                        <Divider/>

                        <Grid container>
                            <Grid container justify="center" alignItems="center" spacing={1}>
                                <Grid item xs={12} md={10}>
                                    <TextField
                                        value={this.state.placeName}
                                        label="Nom de la place *"
                                        fullWidth
                                        onChange={this.handlePlaceNameChange}
                                        style={{"marginTop": 20 + "px"}}
                                        variant="outlined"
                                        disabled={!this.state.isEditable}
                                    />
                                </Grid>
                            </Grid>
                        </Grid>

                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleModalPlaceDetailsId(-1)} color="primary">
                            Retour
                        </Button>
                        {secondButton}
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default DetailsPlaceDialog;