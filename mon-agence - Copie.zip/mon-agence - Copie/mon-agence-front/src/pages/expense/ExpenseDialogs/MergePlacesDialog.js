import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid
} from '@material-ui/core';
import PlaceValue from "./components/components/PlaceValue";
import PlaceService from "../../../services/PlaceService";

/**
 * Composant gérant l'affichage d'une boite de dialogue permettant la fusion de deux places.
 */
class MergePlacesDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            // Data des places choisies pour la fusion
            placeDeleteData: null,
            placeResultData: null,

            // Gestion validation
            placeDeleteDataError: false, // != null
            placeResultDataError: false, // != null
        };

        this.mergePlaces = this.mergePlaces.bind(this);

        this.handlePlaceDeleteDataChange = this.handlePlaceDeleteDataChange.bind(this);
        this.handlePlaceResultDataChange = this.handlePlaceResultDataChange.bind(this);

        this.handleDialogClose = this.handleDialogClose.bind(this);
    }

    mergePlaces() {
        if (this.state.placeDeleteData !== null && this.state.placeResultData !== null) {
            PlaceService.mergePlace(this.state.placeDeleteData.id, this.state.placeResultData.id, this.handleDialogClose, this.props.doUpdate);
        } else {
            this.setState({
                placeDeleteDataError: this.state.placeDeleteData === null,
                placeResultDataError: this.state.placeResultData === null
            });
        }
    }

    handlePlaceDeleteDataChange(event, value) {
        this.setState({placeDeleteData: value, placeDeleteDataError: value === null});
    }

    handlePlaceResultDataChange(event, value) {
        this.setState({placeResultData: value, placeResultDataError: value === null});
    }

    handleDialogClose() {
        this.props.handleMergePlacesDialogIsOpen(false);
        this.setState({
            placeDeleteData: null,
            placeResultData: null,
            placeDeleteDataError: false,
            placeResultDataError: false
        });
    }

    render() {
        return (
            <Container>
                <Dialog open={this.props.mergePlacesDialogIsOpen} onClose={this.handleDialogClose}
                        aria-labelledby="form-dialog-mergePlacesDialog" fullWidth={true} maxWidth={"sm"}
                >
                    <DialogTitle id="form-dialog-mergePlacesDialog">
                        Fusion de deux places
                    </DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            INFORMATION TEXT A FAIRE
                        </DialogContentText>

                        <Divider/>

                        <Grid container justify="center" alignItems="center" spacing={1}>
                            <Grid item xs={12} md={12}>
                                {/* Place qui sera supprimée */}
                                <PlaceValue label="Place à supprimer *" placeholder="Place à supprimer"
                                            selectKey="placeDeletedSelect"
                                            value={this.state.placeDeleteData}
                                            handler={this.handlePlaceDeleteDataChange}
                                            allPlaces={this.props.allPlaces}
                                            error={this.state.placeDeleteDataError}
                                />
                            </Grid>
                            <Grid item xs={12} md={12}>
                                {/* Place qui récupérera tous les tickets de l'autre place */}
                                <PlaceValue label="Place à garder *" placeholder="Place à garder"
                                            selectKey="placeKeepedSelect"
                                            value={this.state.placeResultData}
                                            handler={this.handlePlaceResultDataChange}
                                            allPlaces={this.props.allPlaces}
                                            error={this.state.placeResultDataError}
                                />
                            </Grid>
                        </Grid>

                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleMergePlacesDialogIsOpen(false)} color="primary">
                            Retour
                        </Button>
                        <Button onClick={() => this.mergePlaces()} color="secondary">
                            Fusionner
                        </Button>
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default MergePlacesDialog;