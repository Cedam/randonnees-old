import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid,
    TextField
} from '@material-ui/core';
import Autocomplete from "@material-ui/lab/Autocomplete";
import ReportService from "../../../services/ReportService";
import {withRouter} from 'react-router-dom';

/**
 * Composant gérant l'affichage d'une boite de dialogue permettant le téléchargement du compte-rendu.
 */
class DownloadReportDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            monthSelected: {
                id: 1, name: "Janvier"
            },
        };

        this.downloadReport = this.downloadReport.bind(this);
        this.handleMonthSelectedChange = this.handleMonthSelectedChange.bind(this);
        this.handleDialogClose = this.handleDialogClose.bind(this);
    }

    handleMonthSelectedChange(event, value) {
        this.setState({monthSelected: value});
    }

    downloadReport() {
        ReportService.getReport(this.props.selectedStartDate,
            this.props.selectedEndDate,
            this.state.monthSelected.id,
            () => this.props.history.push("/expenseManager"));
    }

    handleDialogClose() {
        this.props.handleDownloadReportDialogIsOpen(false);
        this.setState({monthSelected: {id: 1, name: "Janvier"}});
    }

    render() {

        const defaultProps = {
            options: [
                {
                    id: 1, name: "Janvier"
                },
                {
                    id: 2, name: "Février"
                },
                {
                    id: 3, name: "Mars"
                },
                {
                    id: 4, name: "Avril"
                },
                {
                    id: 5, name: "Mai"
                },
                {
                    id: 6, name: "Juin"
                },
                {
                    id: 7, name: "Juillet"
                },
                {
                    id: 8, name: "Août"
                },
                {
                    id: 9, name: "Septembre"
                },
                {
                    id: 10, name: "Octobre"
                },
                {
                    id: 11, name: "Novembre"
                },
                {
                    id: 12, name: "Décembre"
                }
            ],
            getOptionLabel: (month) => month.name,
            getOptionSelected: (option, value) => value.id === option.id,
        };

        return (
            <Container>
                <Dialog open={this.props.downloadReportDialogIsOpen} onClose={this.handleDialogClose}
                        aria-labelledby="form-dialog-downloadReportDialog" fullWidth={true} maxWidth={"sm"}
                >
                    <DialogTitle id="form-dialog-downloadReportDialog">
                        Télécharger mon compte-rendu
                    </DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Choisissez le mois auquel rattacher vos frais.
                        </DialogContentText>

                        <Divider/>

                        <Grid container justify="center" alignItems="center" spacing={1}>
                            <Grid item xs={12} md={12}>
                                <Autocomplete
                                    {...defaultProps}
                                    id="monthSelectedForReport"
                                    clearOnEscape
                                    fullWidth
                                    value={this.state.monthSelected}
                                    onChange={this.handleMonthSelectedChange}
                                    renderInput={(params) => <TextField {...params}
                                                                        label="Mois du compte-rendu"
                                                                        placeholder="Mois du compte-rendu"
                                                                        margin="normal"
                                                                        variant="outlined"
                                                                        InputLabelProps={{shrink: true,}}
                                    />}
                                />
                            </Grid>
                        </Grid>

                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleDownloadReportDialogIsOpen(false)} color="primary">
                            Annuler
                        </Button>
                        <Button onClick={() => this.downloadReport()} color="secondary">
                            Télécharger
                        </Button>
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default withRouter(DownloadReportDialog);