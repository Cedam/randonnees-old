import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid
} from '@material-ui/core';
import TextValue from './components/components/TextValue';
import PlaceService from "../../../services/PlaceService";

/**
 * Composant gérant l'affichage d'une boite de dialogue permettant la création d'une place.
 */
class AddPlaceDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            // Nom de la place
            placeName: "",

            // Gestion validation
            placeNameError: false,
        };

        this.addPlace = this.addPlace.bind(this);
        this.handlePlaceNameChange = this.handlePlaceNameChange.bind(this);
        this.handleDialogClose = this.handleDialogClose.bind(this);
    }

    handlePlaceNameChange(event) {
        this.setState({placeName: event.target.value});

        this.setState({placeNameError: event.target.value === ""})
    }

    addPlace() {
        if (this.state.placeName !== "") {
            PlaceService.addPlace(this.state.placeName, this.props.handleAddPlaceDialogIsOpen, this.props.doUpdate);
            this.setState({placeName: ""});
        } else {
            this.setState({placeNameError: true});
        }
    }

    handleDialogClose() {
        this.props.handleAddPlaceDialogIsOpen(false);
        this.setState({placeName: "", placeNameError: false});
    }

    render() {
        return (
            <Container>
                <Dialog open={this.props.addPlaceDialogIsOpen} onClose={this.handleDialogClose}
                        aria-labelledby="form-dialog-addPlaceDialog" fullWidth={true} maxWidth={"sm"}
                >
                    <DialogTitle id="form-dialog-addPlaceDialog">
                        Ajout d'une place
                    </DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Avant d'ajouter une nouvelle place, merci de bien vérifier que celle-ci n'est pas déjà
                            proposée dans la liste déroulante.
                        </DialogContentText>

                        <Divider/>

                        <Grid container justify="center" alignItems="center" spacing={1}>
                            <Grid item xs={12} md={12}>
                                <TextValue label="Place *" placeholder="Place" value={this.state.placeName}
                                           marginTop={10} handler={this.handlePlaceNameChange}
                                           error={this.state.placeNameError}
                                />
                            </Grid>
                        </Grid>

                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleAddPlaceDialogIsOpen(false)} color="primary">
                            Retour
                        </Button>
                        <Button onClick={() => this.addPlace()} color="secondary">
                            Ajouter
                        </Button>
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default AddPlaceDialog;