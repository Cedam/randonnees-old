import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid,
    TextField
} from '@material-ui/core';
import CompensationService from "../../../services/CompensationService";

/**
 * Composant gérant l'affichage d'une boite de dialogue permettant la création d'une compensation.
 */
class AddCompensationDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            // cv de la compensation
            cv: 0,

            // indemnité de la compensation
            mileageAllowance: 0,

            // Gestion validation
            cvError: false,
            mileageAllowanceError: false,

        };

        this.addCompensation = this.addCompensation.bind(this);
        this.handleCvChange = this.handleCvChange.bind(this);
        this.handleMileageAllowanceChange = this.handleMileageAllowanceChange.bind(this);
        this.handleDialogClose = this.handleDialogClose.bind(this);
    }

    handleCvChange(event) {
        this.setState({cv: event.target.value});
        this.setState({cvError: event.target.value === 0});
    }

    handleMileageAllowanceChange(event) {
        this.setState({mileageAllowance: event.target.value});
        this.setState({mileageAllowanceError: event.target.value === 0});
    }

    addCompensation() {
        if (this.state.cv !== 0 && this.state.mileageAllowance !== 0) {
            CompensationService.addCompensation(this.state.cv, this.state.mileageAllowance, this.props.doUpdate, this.handleDialogClose);
        } else {
            this.setState({cvError: this.state.cv === "" || this.state.cv === 0});
            this.setState({mileageAllowanceError: this.state.mileageAllowance === "" || this.state.mileageAllowance === 0});
        }
    }

    handleDialogClose() {
        this.props.handleAddCompensationDialogIsOpen(false);
        this.setState({cv: 0, mileageAllowance: 0, cvError: false, mileageAllowanceError: false});
    }

    render() {
        return (
            <Container>
                <Dialog open={this.props.addCompensationDialogIsOpen} onClose={this.handleDialogClose}
                        aria-labelledby="form-dialog-addCompensationDialog" fullWidth={true} maxWidth={"sm"}
                >
                    <DialogTitle id="form-dialog-addCompensationDialog">
                        Ajout d'une compensation
                    </DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Ajouter un niveau d'indemnité kilométrique.
                        </DialogContentText>

                        <Divider/>

                        <Grid container justify="center" alignItems="center" spacing={1}>
                            <Grid item xs={12} md={12}>
                                <TextField type="number"
                                           value={this.state.cv === 0 ? "" : this.state.cv}
                                           onChange={this.handleCvChange}
                                           fullWidth
                                           variant="outlined"
                                           InputLabelProps={{shrink: true,}}
                                           error={this.state.cvError}
                                           label="Cv *"
                                           placeholder="Cv"
                                           style={{"marginTop": "10px"}}
                                />
                            </Grid>
                            <Grid item xs={12} md={12}>
                                <TextField type="number"
                                           inputProps={{"step": "0.001"}}
                                           value={this.state.mileageAllowance === 0 ? "" : this.state.mileageAllowance}
                                           onChange={this.handleMileageAllowanceChange}
                                           fullWidth
                                           variant="outlined"
                                           InputLabelProps={{shrink: true,}}
                                           error={this.state.mileageAllowanceError}
                                           label="Indemnité *"
                                           placeholder="Indemnité"
                                />
                            </Grid>
                        </Grid>

                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleAddCompensationDialogIsOpen(false)} color="primary">
                            Retour
                        </Button>
                        <Button onClick={() => this.addCompensation()} color="secondary">
                            Ajouter
                        </Button>
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default AddCompensationDialog;