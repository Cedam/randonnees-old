import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid,
    InputAdornment,
    TextField
} from '@material-ui/core';
import PlaceValue from "./components/components/PlaceValue";
import PlaceService from "../../../services/PlaceService";
import DistanceService from "../../../services/DistanceService";
import snackbarStore from "../../../store/SnackbarStore";

/**
 * Composant gérant l'affichage d'une boite de dialogue permettant la création d'une distance entre deux places.
 */
class AddDistanceDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            placeStartData: null,
            placeEndData: null,
            allPlaces: [],
            mileage: 0,
            distanceExist: false,

            placeStartDataError: false, // != null
            placeEndDataError: false, // != null
            mileageError: false // >= 0
        };

        this.addDistance = this.addDistance.bind(this);

        this.handleDialogClose = this.handleDialogClose.bind(this);

        this.handlePlaceStartDataChange = this.handlePlaceStartDataChange.bind(this);
        this.handlePlaceEndDataChange = this.handlePlaceEndDataChange.bind(this);
        this.handleMileageChange = this.handleMileageChange.bind(this);
        this.handleAllPlacesChange = this.handleAllPlacesChange.bind(this);
        this.handleDistanceExistChange = this.handleDistanceExistChange.bind(this);

        // Récupération des places existantes
        PlaceService.getAllPlacesList(this.handleAllPlacesChange);
    }

    formIsValid() {
        let isValid = true;

        // Les informations de place de départ doivent être != null
        if (this.state.placeStartData === null) {
            this.setState({placeStartDataError: true});
            isValid = false;
        } else {
            this.setState({placeStartDataError: false});
        }

        // Les informations de place d'arrivée doivent être != null
        if (this.state.placeEndData === null) {
            this.setState({placeEndDataError: true});
            isValid = false;
        } else {
            this.setState({placeEndDataError: false});
        }

        // La distance ne doit pas déjà exister
        if (this.state.distanceExist) {
            snackbarStore.addSnackbarError("La distance entre ces deux places existent déjà.")
            isValid = false;
        }

        // La distance doit être > 0
        if (this.state.mileage <= 0) {
            this.setState({mileageError: true});
            isValid = false;
        } else {
            this.setState({mileageError: false});
        }

        return isValid;
    }

    addDistance() {
        // Si le formulaire est complet :
        if (this.formIsValid()) {
            DistanceService.addDistance(this.state.placeStartData, this.state.placeEndData, this.state.mileage, this.props.doUpdate, this.handleDialogClose)
        }
    }

    handleDialogClose() {
        this.props.handleAddDistanceDialogIsOpen(false);
        this.setState({
            placeStartData: null,
            placeEndData: null,
            mileage: 0,
            distanceExist: false,

            placeStartDataError: false,
            placeEndDataError: false,
            mileageError: false
        });
    }

    handlePlaceStartDataChange(event, value) {
        this.setState({placeStartData: value});

        if (value !== null && this.state.placeEndData !== null) {
            DistanceService.getDistanceByPlaces(value.id, this.state.placeEndData.id, this.handleDistanceExistChange, this.handleMileageChange);
            this.setState({placeStartDataError: false});
        } else {
            this.handleMileageChange({target: {value: 0}});
        }

        if (value === null) {
            this.setState({placeStartDataError: true});
        }
    }

    handlePlaceEndDataChange(event, value) {
        this.setState({placeEndData: value});

        if (value !== null && this.state.placeStartData !== null) {
            DistanceService.getDistanceByPlaces(value.id, this.state.placeStartData.id, this.handleDistanceExistChange, this.handleMileageChange);
            this.setState({placeEndDataError: false});
        } else {
            this.handleMileageChange({target: {value: 0}});
        }

        if (value === null) {
            this.setState({placeEndDataError: true});
        }
    }

    handleMileageChange(event) {
        this.setState({
            mileage: event.target.value,
            mileageError: event.target.value <= 0
        });
    }

    handleAllPlacesChange(newAllPlaces) {
        this.setState({allPlaces: newAllPlaces});
    }

    handleDistanceExistChange(distanceExist) {
        this.setState({distanceExist: distanceExist});
    }

    render() {
        return (
            <Container>
                <Dialog open={this.props.addDistanceDialogIsOpen} onClose={this.handleDialogClose}
                        aria-labelledby="form-dialog-addDistanceDialog" fullWidth={true} maxWidth={"sm"}
                >
                    <DialogTitle id="form-dialog-addDistanceDialog">
                        Ajout d'une distance entre deux places
                    </DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Avant d'ajouter une nouvelle distance, merci de bien vérifier que celle-ci n'est pas déjà
                            proposée dans la liste déroulante.
                        </DialogContentText>

                        <Divider/>

                        <Grid container justify="center" alignItems="center" spacing={1}>
                            <Grid item xs={12} md={12}>
                                {/* Place de départ */}
                                <PlaceValue label="Place de départ *" placeholder="Place de départ"
                                            selectKey="placeStartSelect"
                                            value={this.state.placeStartData}
                                            handler={this.handlePlaceStartDataChange} allPlaces={this.state.allPlaces}
                                            error={this.state.placeStartDataError}
                                />
                            </Grid>
                        </Grid>

                        <Grid container justify="center" alignItems="center" spacing={1}>
                            <Grid item xs={12} md={12}>
                                {/* Place d'arrivé */}
                                <PlaceValue label="Place d'arrivée *" placeholder="Place d'arrivée"
                                            selectKey="placeEndSelect"
                                            value={this.state.placeEndData}
                                            handler={this.handlePlaceEndDataChange} allPlaces={this.state.allPlaces}
                                            error={this.state.placeEndDataError}
                                />
                            </Grid>
                        </Grid>

                        <Grid container justify="center" alignItems="center" spacing={1}>
                            <Grid item xs={12} md={12}>
                                {/* Kilomètre parcouru */}
                                {/* Si une distance entre les deux places choisies existe dans la BD, bloquer ce champs
                            avec la valeur de la BD. Sinon le débloquer et penser à ajouter la nouvelle distance en BD*/}
                                <TextField type="number" value={this.state.mileage === 0 ? "" : this.state.mileage}
                                           inputProps={{"step": "0.001"}} onChange={this.handleMileageChange} fullWidth
                                           disabled={this.state.distanceExist}
                                           InputLabelProps={{shrink: true,}}
                                           InputProps={{
                                               endAdornment: <InputAdornment position="end">km</InputAdornment>,
                                           }}
                                           style={{"marginTop": "20px"}}
                                           label="Distance *"
                                           variant="outlined"
                                           error={this.state.mileageError}
                                           placeholder="Distance (d'un aller)"
                                />
                            </Grid>
                        </Grid>

                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleAddDistanceDialogIsOpen(false)} color="primary">
                            Retour
                        </Button>
                        <Button onClick={() => this.addDistance()} color="secondary">
                            Ajouter
                        </Button>
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default AddDistanceDialog;