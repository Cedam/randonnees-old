import React from "react";
import {Container} from '@material-ui/core';
import ExpenseGeneratorBreadcrumbs from './components/ExpenseGeneratorBreadcrumbs';
import ExpenseGeneratorButtons from "./components/ExpenseGeneratorButtons";
import ExpenseGeneratorStatistics from "./components/ExpenseGeneratorStatistics";
import TicketService from "../../../services/TicketService";
import moment from "moment";

/**
 * Composant permettant la génération d'un compte rendu.
 */
class ExpenseGenerator extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            selectedStartDate: moment().date(1).format("YYYY-MM-DD"), // Date de début actuellement filtrée
            selectedEndDate: moment().endOf('month').format("YYYY-MM-DD"), // Date de fin actuellement filtrée

            allTicketsCode: [], // Listes des types de TicketCode existants et d'une chaine les representants
        };

        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.handleEndDateChange = this.handleEndDateChange.bind(this);

        // handler permettant l'initialisation de la liste de types de ticket
        this.handleAllTicketsCodeChange = this.handleAllTicketsCodeChange.bind(this);
    }

    componentDidMount() {
        // Récupération de la liste des types de tickets
        TicketService.getAllTicketsCode(this.handleAllTicketsCodeChange);
    }

    handleStartDateChange(date) {
        if (typeof date === "object") {
            this.setState({selectedStartDate: date.toISOString().substr(0, 10)});
        } else {
            this.setState({selectedStartDate: date});
        }
    }

    handleEndDateChange(date) {
        if (typeof date === "object") {
            this.setState({selectedEndDate: date.toISOString().substr(0, 10)})
        } else {
            this.setState({selectedEndDate: date});
        }
    }

    handleAllTicketsCodeChange(allTicketsCode) {
        this.setState({allTicketsCode: allTicketsCode});
    }

    render() {
        return (
            <Container>

                <ExpenseGeneratorBreadcrumbs/>

                <ExpenseGeneratorStatistics
                    selectedStartDate={this.state.selectedStartDate}
                    handleStartDateChange={this.handleStartDateChange}
                    selectedEndDate={this.state.selectedEndDate}
                    handleEndDateChange={this.handleEndDateChange}
                    allTicketsCode={this.state.allTicketsCode}
                />

                <ExpenseGeneratorButtons
                    selectedStartDate={this.state.selectedStartDate}
                    selectedEndDate={this.state.selectedEndDate}
                />

            </Container>
        );
    }
}

export default ExpenseGenerator;