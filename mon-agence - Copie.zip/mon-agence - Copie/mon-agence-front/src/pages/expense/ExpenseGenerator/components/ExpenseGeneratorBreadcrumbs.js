import React from 'react';

import {Breadcrumbs, Container, Link, Typography} from '@material-ui/core';
import {Grain as GrainIcon, Home as HomeIcon} from '@material-ui/icons';
import {useHistory} from "react-router-dom";
import {makeStyles} from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    link: {
        display: 'flex',
        cursor: 'pointer',
    },
    flat: {
        display: 'flex',
    },
    icon: {
        marginRight: theme.spacing(0.5),
        width: 22,
        height: 22,
    },
}));

/**
 * Composant fil d'Arianne pour le composant "ExpenseGenerator.js".
 */
function ExpenseGeneratorBreadcrumbs(props) {
    const history = useHistory();
    const classes = useStyles();

    return (
        <Container>
            <Breadcrumbs style={{"marginTop": 10 + "px", "marginLeft": -20 + "px"}}>
                <Link color="inherit" onClick={() => history.push("/")} className={classes.link}>
                    <HomeIcon className={classes.icon}/>Accueil
                </Link>
                <Typography color="textPrimary" className={classes.flat}>
                    ...
                </Typography>
                <Link color="inherit" onClick={() => history.push("/expenseManager")} className={classes.link}>
                    <GrainIcon className={classes.icon}/>Mes tickets
                </Link>
                <Typography color="textPrimary" className={classes.flat}>
                    <GrainIcon className={classes.icon}/>Créer ma note de frais
                </Typography>
            </Breadcrumbs>
        </Container>
    );
}

export default ExpenseGeneratorBreadcrumbs;