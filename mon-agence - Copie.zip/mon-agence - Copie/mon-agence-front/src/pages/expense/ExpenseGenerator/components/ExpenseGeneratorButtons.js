import React, {useState} from 'react';

import {Button, Container, Grid} from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import GetAppIcon from '@material-ui/icons/GetApp';

import {useHistory} from "react-router-dom";
import DownloadReportDialog from "../../ExpenseDialogs/DownloadReportDialog";

/** Ensemble de boutons utilisé par le composant "ExpenseGenerator.js".
 *
 * @param props
 * @returns {JSX.Element}
 * @constructor
 */
function ExpenseGeneratorButtons(props) {
    const [downloadReportDialogIsOpen, handleDownloadReportDialogIsOpen] = useState(false);
    let history = useHistory();

    return (
        <Container>
            <Grid container justify="center" alignItems="center" spacing={1} style={{"marginTop": "10px"}}>

                <Grid container item justify="center" alignItems="center" xs={12} sm={3} md={3}>
                    <Button color="default"
                            variant="contained"
                            onClick={() => history.push("/expenseManager")}
                            startIcon={<ArrowBackIcon/>}
                    >
                        Retour
                    </Button>
                </Grid>

                <Grid container item justify="center" alignItems="center" xs={12} sm={3} md={3}>
                    <Button color="primary"
                            variant="contained"
                            onClick={() => handleDownloadReportDialogIsOpen(true)}
                            startIcon={<GetAppIcon/>}
                    >
                        Télécharger</Button>
                </Grid>

            </Grid>
            <DownloadReportDialog downloadReportDialogIsOpen={downloadReportDialogIsOpen}
                                  handleDownloadReportDialogIsOpen={handleDownloadReportDialogIsOpen}
                                  selectedStartDate={props.selectedStartDate}
                                  selectedEndDate={props.selectedEndDate}
            />
        </Container>
    );
}

export default ExpenseGeneratorButtons;