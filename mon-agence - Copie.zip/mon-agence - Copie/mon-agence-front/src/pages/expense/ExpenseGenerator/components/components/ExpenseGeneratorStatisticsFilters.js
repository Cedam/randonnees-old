import React, {useState} from 'react';
import {Grid} from '@material-ui/core';
import {KeyboardDatePicker, MuiPickersUtilsProvider} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import frLocale from 'date-fns/locale/fr';

/**
 * Composant permettant le filtrage des statistiques présentes dans le composant "ExpenseGeneratorStatistics.js".
 *
 * @param props
 * @returns {JSX.Element}
 * @constructor
 */
function ExpenseGeneratorStatisticsFilters(props) {
    const [isStartDateDatepickerOpen, setIsStartDateDatepickerOpen] = useState(false);
    const [isEndDateDatepickerOpen, setIsEndDateDatepickerOpen] = useState(false);

    const handleStartDateChange = (date) => {
        props.handleStartDateChange(date);
        setIsStartDateDatepickerOpen(!isStartDateDatepickerOpen);
    }

    const handleEndDateChange = (date) => {
        props.handleEndDateChange(date);
        setIsEndDateDatepickerOpen(!isEndDateDatepickerOpen);
    }

    return (
        <Grid container direction="row" justify="center" alignItems="center" spacing={3}>

            <Grid item>
                <MuiPickersUtilsProvider utils={DateFnsUtils} locale={frLocale}>
                    {/* Choix d'une date de début de période */}
                    <KeyboardDatePicker
                        disableToolbar
                        variant="inline"
                        format="dd/MM/yyyy"
                        margin="normal"
                        id="date-picker-inline-startDate"
                        label="Date de début (incluse)"
                        value={props.selectedStartDate}
                        onChange={handleStartDateChange}
                        KeyboardButtonProps={{
                            onFocus: e => {
                                setIsStartDateDatepickerOpen(true);
                            }
                        }}
                        PopoverProps={{
                            disableRestoreFocus: true,
                            onClose: () => {
                                setIsStartDateDatepickerOpen(false);
                            }
                        }}
                        InputProps={{
                            onFocus: () => {
                                setIsStartDateDatepickerOpen(true);
                            }
                        }}
                        open={isStartDateDatepickerOpen}
                    />
                </MuiPickersUtilsProvider>
            </Grid>

            <Grid item>
                <MuiPickersUtilsProvider utils={DateFnsUtils} locale={frLocale}>
                    {/* Choix d'une date de fin de période */}
                    <KeyboardDatePicker
                        disableToolbar
                        variant="inline"
                        format="dd/MM/yyyy"
                        margin="normal"
                        id="date-picker-inline-startEnd"
                        label="Date de fin (incluse)"
                        value={props.selectedEndDate}
                        onChange={handleEndDateChange}
                        KeyboardButtonProps={{
                            onFocus: e => {
                                setIsEndDateDatepickerOpen(true);
                            }
                        }}
                        PopoverProps={{
                            disableRestoreFocus: true,
                            onClose: () => {
                                setIsEndDateDatepickerOpen(false);
                            }
                        }}
                        InputProps={{
                            onFocus: () => {
                                setIsEndDateDatepickerOpen(true);
                            }
                        }}
                        open={isEndDateDatepickerOpen}
                    />
                </MuiPickersUtilsProvider>
            </Grid>
        </Grid>
    );
}

export default ExpenseGeneratorStatisticsFilters;