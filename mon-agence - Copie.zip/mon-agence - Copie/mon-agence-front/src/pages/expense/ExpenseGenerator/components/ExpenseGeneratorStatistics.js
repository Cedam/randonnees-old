import React from "react";
import ExpenseGeneratorStatisticsFilters from "./components/ExpenseGeneratorStatisticsFilters";
import {Box} from "@material-ui/core";
import TableContainer from "@material-ui/core/TableContainer";
import Table from "@material-ui/core/Table";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import Paper from "@material-ui/core/Paper";
import TableBody from "@material-ui/core/TableBody";
import Tooltip from "@material-ui/core/Tooltip";
import ReportService from "../../../../services/ReportService";

class ExpenseGeneratorStatistics extends React.Component {

    constructor(props) {
        super(props);

        // Cette variable permet de bloquer le doUpdate si jamais l'initialisation
        // du composant est en cours
        this.initializationInProgress = false;

        this.state = {
            ticketTypeCode: "", // Type de ticket actuellement selectionné afin d'en afficher les statistiques liées

            statsTickets: [], // Statistiques des tickets à afficher
        };

        this.handleTicketTypeCodeChange = this.handleTicketTypeCodeChange.bind(this);
        this.handleStatsTicketsChange = this.handleStatsTicketsChange.bind(this);
        this.doUpdate = this.doUpdate.bind(this);
        this.handleInitialisation = this.handleInitialisation.bind(this);
    }

    componentDidMount() {
        // On previent le componentDidUpdate qu'il ne doit pas refaire la requete malgré le changement des dates filtrées
        this.initializationInProgress = true;

        ReportService.getInitialStatsTickets(this.props.selectedStartDate, this.props.selectedEndDate, this.handleInitialisation);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.selectedStartDate !== this.props.selectedStartDate || prevProps.selectedEndDate !== this.props.selectedEndDate) {
            this.doUpdate();
        }
    }

    doUpdate() {
        // Si il faut faire la requête
        if (!this.initializationInProgress) {
            ReportService.getStatsTickets(this.props.selectedStartDate, this.props.selectedEndDate, this.handleStatsTicketsChange);
        }
    }

    // Fonction utilisée une seule fois lors de l'initialisation du composant
    handleInitialisation(realStartDate, realEndDate, allStatsTickets) {

        this.props.handleStartDateChange(realStartDate);
        this.props.handleEndDateChange(realEndDate);
        this.setState({statsTickets: allStatsTickets});

        this.initializationInProgress = false;
    }

    handleTicketTypeCodeChange(event) {
        this.setState({ticketTypeCode: event.target.value});
    }

    handleStatsTicketsChange(statsTickets) {
        this.setState({statsTickets: statsTickets});
    }

    ccyFormat(num) {
        return `${num.toFixed(2)}`;
    }

    getTicketTypeCodeTooltip(ticketTypeCode) {
        switch (ticketTypeCode) {
            case 'CUSTOMER_MEAL_COST':
                return (<span>En attente de la réponse de Charles</span>);
            case 'SITE_MEAL_COST':
                return (<span>En attente de la réponse de Charles</span>);
            case 'VARIOUS_COST':
                return (<span>Materiel, welcome pack, poste, ...</span>);
            case 'EXCEPTIONAL_BUSINESS_TRAVEL':
                return (<span>Remboursements kilométriques.</span>);
            case 'FUEL':
                return (<span>Essence, diesel, ...</span>);
            case 'VARIOUS_BUSINESS_TRAVEL':
                return (<span>Parking, péage, téléphone, ...</span>
                );
            case 'LODGING_MEAL_BUSINESS':
                return (<span>Hotel et repas associés.</span>);
            default:
                return (
                    <span>
                        Si vous voyez ce message, une erreur est survenue : Le ticket choisit n'est pas géré par le système.
                    </span>
                );
        }
    }

    render() {

        let nbTicket = 0;
        let sumTotalValue = 0;
        let rows = [];

        for (const ticketProperty in this.state.statsTickets) {
            if (this.state.statsTickets[ticketProperty] != null) {
                const qte = this.state.statsTickets[ticketProperty].qte;
                const value = this.state.statsTickets[ticketProperty].value;

                nbTicket += qte;
                sumTotalValue += value;

                rows.push({ticketProperty, qte, value});
            } else {
                rows.push({ticketProperty, qte: 0, value: 0});
            }
        }

        return (
            <>
                <ExpenseGeneratorStatisticsFilters
                    selectedStartDate={this.props.selectedStartDate}
                    handleStartDateChange={this.props.handleStartDateChange}
                    selectedEndDate={this.props.selectedEndDate}
                    handleEndDateChange={this.props.handleEndDateChange}
                />

                <TableContainer component={Paper} style={{"marginTop": "25px"}}>
                    <Table aria-label="spanning table">
                        <TableHead>
                            <TableRow>
                                <TableCell align="center" colSpan={2}>Details</TableCell>
                                <TableCell align="right">Remboursement</TableCell>
                            </TableRow>
                            <TableRow>
                                <TableCell>Type de ticket</TableCell>
                                <TableCell align="right">Quantité</TableCell>
                                <TableCell align="right">Total en €</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.map((row) => (
                                <Tooltip title={this.getTicketTypeCodeTooltip(row.ticketProperty)} arrow
                                         key={row.ticketProperty}>
                                    <TableRow>
                                        <TableCell>{this.props.allTicketsCode[row.ticketProperty]}</TableCell>
                                        <TableCell align="right">{row.qte}</TableCell>
                                        <TableCell align="right">{this.ccyFormat(row.value)}</TableCell>
                                    </TableRow>
                                </Tooltip>
                            ))}

                            <TableRow key="total-row">
                                <TableCell align="right"><Box fontWeight="fontWeightBold">Totaux pour la période
                                    selectionnée</Box></TableCell>
                                <TableCell align="right">{nbTicket}</TableCell>
                                <TableCell align="right"><Box
                                    fontWeight="fontWeightBold">{this.ccyFormat(sumTotalValue)}</Box></TableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                </TableContainer>
            </>
        );
    }
}

export default ExpenseGeneratorStatistics;