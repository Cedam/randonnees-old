import React from "react";
import TableContainer from "@material-ui/core/TableContainer";
import Table from "@material-ui/core/Table";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import Paper from "@material-ui/core/Paper";
import TableBody from "@material-ui/core/TableBody";
import GeneratedReportService from "../../../../services/GeneratedReportService";
import moment from "moment";
import {showFormattedDate} from '../../utilities';
import {PictureAsPdf as PdfIcon, TableChart as ExcelIcon, Archive as ZipIcon} from "@material-ui/icons";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";

class ExpenseArchiveTab extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            allFiles: [], // Informations des fichiers de compte rendu téléchargeable à afficher
        };

        this.handleAllFilesChange = this.handleAllFilesChange.bind(this);
    }

    componentDidMount() {
        // On récupère la liste des informations des fichiers de compte rendu téléchargeable à afficher
        GeneratedReportService.getAllReportsList(this.handleAllFilesChange);
    }

    handleAllFilesChange(allFiles) {
        this.setState({allFiles: allFiles});
    }

    render() {
        return (
            <>
                <TableContainer component={Paper} style={{"marginTop": "25px"}}>
                    <Table aria-label="spanning table">
                        <TableHead>
                            <TableRow>
                                <TableCell align="left">Date de génération</TableCell>
                                <TableCell align="left">Mois concernés</TableCell>
                                <TableCell align="right">Formats téléchargeables</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {this.state.allFiles.map(row => (
                                <TableRow key={row.id}>
                                    <TableCell>{showFormattedDate(row.creationDate)}</TableCell>
                                    <TableCell>{moment().month(row.month - 1).format("MMMM")}</TableCell>
                                    <TableCell align="right">
                                        <Tooltip title="Excel">
                                            <IconButton color="primary" component="span" onClick={() => {
                                                GeneratedReportService.getExcelArchive(row.id)
                                            }}>
                                                <ExcelIcon/>
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="PDF">
                                            <IconButton color="primary" component="span" onClick={() => {
                                                GeneratedReportService.getPdfArchive(row.id)
                                            }}>
                                                <PdfIcon/>
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Zip (Excel+PDF)">
                                            <IconButton color="primary" component="span" onClick={() => {
                                                GeneratedReportService.getZipArchive(row.id)
                                            }}>
                                                <ZipIcon/>
                                            </IconButton>
                                        </Tooltip>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </>
        );
    }
}

export default ExpenseArchiveTab;