import React from "react";
import {Container} from '@material-ui/core';
import ExpenseArchiveBreadcrumbs from "./components/ExpenseArchiveBreadcrumbs";
import ExpenseArchiveTab from "./components/ExpenseArchiveTab";

/**
 * Composant permettant la génération d'un compte rendu.
 */
class ExpenseArchive extends React.Component {

    render() {
        return (
            <Container>
                <ExpenseArchiveBreadcrumbs/>
                <ExpenseArchiveTab/>
            </Container>
        );
    }
}

export default ExpenseArchive;