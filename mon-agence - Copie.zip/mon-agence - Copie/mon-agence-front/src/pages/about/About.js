import React from 'react';
import * as styles from './About.module.scss';

function About() {
  return (
    <div className={styles.Root}>
      <span>À propos</span>
    </div>
  );
}

export default About;
