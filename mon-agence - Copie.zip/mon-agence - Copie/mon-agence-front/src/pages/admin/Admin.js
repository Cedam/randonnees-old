import React from 'react';
import {AppBar, Container, Tab, Tabs} from "@material-ui/core";
import {observer} from "mobx-react";
import userStore from "../../store/UserStore";
import UserList from "./components/global_admin/UserList";
import ExpenseAdmin from "./components/expense_admin/ExpenseAdmin";

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

/**
 * Composant permettant de choix entre les différents composants d'administration accessible par l'utilisateur connecté.
 *
 * @type {function(): JSX.Element}
 */
const AdminTab = observer(() => {
    const [value, setValue] = React.useState(0);

    const handleTabsChange = (event, newValue) => {
        setValue(newValue);
    };

    let tabsTab = [];
    let tabComponent = [];

    // Initialisatin des Tabs relatifs à "ROLE_ADMIN"
    if (userStore.hasRole("ROLE_ADMIN")) {
        tabsTab.push(<Tab value={tabsTab.length} label={"Comptes utilisateurs"} {...a11yProps(tabsTab.length)}
                          key={"simple-tab-" + tabsTab.length}/>);
        tabComponent.push(<UserList/>);
    }

    // Initialisatin des Tabs relatifs à "ROLE_ADMIN_EXPENSE"
    if (userStore.hasRole("ROLE_ADMIN_EXPENSE")) {
        tabsTab.push(<Tab value={tabsTab.length} label={"Module : Notes de frais"} {...a11yProps(tabsTab.length)}
                          key={"simple-tab-" + tabsTab.length}/>);
        tabComponent.push(<ExpenseAdmin/>);
    }

    // Initialisation des Tabs relatifs à "ROLE_ADMIN_SUPPLY"
    if (userStore.hasRole("ROLE_ADMIN_SUPPLY")) {
        tabsTab.push(<Tab value={tabsTab.length} label={"Module : SUPPLY"} {...a11yProps(tabsTab.length)}
                          key={"simple-tab-" + tabsTab.length}/>);
        tabComponent.push(<span>ADMIN_SUPPLY_TAB_PANEL IN PROGRESS ...</span>);
    }

    // Initialisation des Tabs relatifs à "ROLE_ADMIN_PUB"
    if (userStore.hasRole("ROLE_ADMIN_PUB")) {
        tabsTab.push(<Tab value={tabsTab.length} label={"Module : Le bon coin"} {...a11yProps(tabsTab.length)}
                          key={"simple-tab-" + tabsTab.length}/>);
        tabComponent.push(<span>ADMIN_PUB_TAB_PANEL IN PROGRESS ...</span>);
    }

    return (
        <Container>
            <AppBar position="static" style={{marginTop: "15px"}}>
                <Tabs value={value} onChange={handleTabsChange} aria-label="simple tabs example" centered
                      indicatorColor={"primary"}>
                    {tabsTab.map((tab, index) => {
                        return tab;
                    })}
                </Tabs>
            </AppBar>

            {tabComponent.map((component, index) => {
                return value === index ? <Container key={"tabComponent-" + index}>{component}</Container> : null;
            })}

        </Container>
    )
})

/**
 * Composant permettant de gérer l'affichage de la selection des différentes partie de l'Administration.
 * @returns {JSX.Element}
 * @constructor
 */
function Admin() {
    return (
        <div>
            <AdminTab/>
        </div>
    );
}

export default Admin;
