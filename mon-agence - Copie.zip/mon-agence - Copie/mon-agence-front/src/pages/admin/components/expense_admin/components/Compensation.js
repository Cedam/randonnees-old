import React from "react";
import {Button, Grid, Table, TableBody, TableCell, TableContainer, TablePagination, TableRow} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import EnhancedTableToolbar from "../../../../expense/EnhancedTableComponents/EnhancedTableToolbar";
import EnhancedTableHead from "../../../../expense/EnhancedTableComponents/EnhancedTableHead";
import AddCompensationDialog from "../../../../expense/ExpenseDialogs/AddCompensationDialog";
import DetailsCompensationDialog from "../../../../expense/ExpenseDialogs/DetailsCompensationDialog";
import NoteAddIcon from '@material-ui/icons/NoteAddOutlined';
import CompensationService from "../../../../../services/CompensationService";

/**
 * Partie 'Indemnités kilométrique' du composant 'Notes de frais' de la page d'administration.
 */
class Compensation extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            page: 0, // Page actuellement choisie
            rowsPerPage: 8, // Nombre d'elements à afficher par page
            order: 'asc', // Ordre actuellement choisi
            orderBy: 'cv', // En-tête du tableau actuellement ordonné
            allCompensations: [], // Liste de toutes les compensations
            paginationTotalElement: 0, // Nombre d'élement total, afin de gérer les calculs de pagination
            emptyRows: 10, // Nombre de ligne vide à afficher

            modalAddCompensationIsOpen: false, // Doit-on afficher le dialogue d'ajout d'une compensation
            modalCompensationDetailsId: -1, // Id de la compensation selectionné afin de la modifier
        };

        this.handleRequestSort = this.handleRequestSort.bind(this);
        this.handleChangeRowsPerPage = this.handleChangeRowsPerPage.bind(this);
        this.handleChangePage = this.handleChangePage.bind(this);
        this.updateAllCompensationsAndPagination = this.updateAllCompensationsAndPagination.bind(this);

        this.setModalAddCompensationIsOpen = this.setModalAddCompensationIsOpen.bind(this);
        this.handleModalCompensationDetailsId = this.handleModalCompensationDetailsId.bind(this);

        this.doUpdate = this.doUpdate.bind(this);
    }

    componentDidMount() {
        this.doUpdate();
    }

    doUpdate() {
        CompensationService.getPageCompensations(this.state.page, this.state.rowsPerPage, this.state.order, this.state.orderBy,
            this.updateAllCompensationsAndPagination);
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.page !== this.state.page ||
            prevState.rowsPerPage !== this.state.rowsPerPage ||
            prevState.order !== this.state.order ||
            prevState.orderBy !== this.state.orderBy) {
            this.doUpdate();
        }
    }

    // Fonction permettant de mettre à jour les informations lors de la récupération des compensations
    updateAllCompensationsAndPagination(newCompensations, newPaginationTotalElement) {
        // Si la page demandée est > 0 et que la liste retournée est vide, il faut remettre page à 0
        if (this.state.page > 0 && newCompensations.length === 0) {
            this.setState({page: 0});
        } else {
            this.setState({allCompensations: newCompensations});
            this.setState({emptyRows: this.state.rowsPerPage - Math.min(this.state.rowsPerPage, newCompensations.length)});
            this.setState({paginationTotalElement: newPaginationTotalElement});
        }
    }

    setModalAddCompensationIsOpen(isOpen) {
        this.setState({modalAddCompensationIsOpen: isOpen});
    }

    handleRequestSort(event, property) {
        const isAsc = this.state.orderBy === property && this.state.order === 'asc';

        this.setState({order: isAsc ? 'desc' : 'asc', orderBy: property});
    }

    handleChangeRowsPerPage(event) {
        this.setState({rowsPerPage: parseInt(event.target.value, 10), page: 0});
    }

    handleChangePage(event, newPage) {
        this.setState({page: newPage});
    }

    handleModalCompensationDetailsId(modalCompensationDetailsId) {
        this.setState({modalCompensationDetailsId: modalCompensationDetailsId});
    }

    render() {

        const headCells = [
            {id: 'cv', label: 'Cv'},
            {id: 'mileageAllowance', label: 'Indemnités kilométrique'},
        ];

        return (
            <div style={{"marginTop": "15px"}}>
                <Paper>
                    <EnhancedTableToolbar title={"Barèmes d'indemnités"}/>
                    <TableContainer>
                        <Table
                            size={'medium'}
                        >
                            <EnhancedTableHead
                                order={this.state.order}
                                orderBy={this.state.orderBy}
                                onRequestSort={this.handleRequestSort}
                                rowCount={this.state.allCompensations.length}
                                headCells={headCells}
                            />
                            <TableBody>
                                {this.state.allCompensations.map((row, index) => {
                                    const labelId = `enhanced-table-checkbox-compensations-${index}`;

                                    return (
                                        <TableRow
                                            hover
                                            onClick={() => this.handleModalCompensationDetailsId(row.id)}
                                            key={row.id}
                                        >
                                            <TableCell component="th" id={labelId} scope="row" align="left"
                                                       padding="default">{row.cv}</TableCell>
                                            <TableCell align="left"
                                                       padding="default">{row.mileageAllowance}</TableCell>
                                        </TableRow>
                                    )
                                })}

                                {this.state.emptyRows > 0 && (
                                    <TableRow style={{height: 53 * this.state.emptyRows}}>
                                        <TableCell colSpan={6}/>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        rowsPerPageOptions={[4, 8, 16]}
                        component="div"
                        count={this.state.paginationTotalElement}
                        rowsPerPage={this.state.rowsPerPage}
                        page={this.state.page}
                        onChangePage={this.handleChangePage}
                        onChangeRowsPerPage={this.handleChangeRowsPerPage}
                        labelRowsPerPage="Lignes par page : "
                    />
                </Paper>

                <Grid
                    container
                    direction="row"
                    justify="center"
                    alignItems="center"
                >
                    <Grid container justify="center" alignItems="center" spacing={1} style={{"marginTop": "15px"}}>
                        <Grid container item justify="center" alignItems="center" xs={12} sm={12} md={12}>
                            <Button variant="contained"
                                    color="primary"
                                    onClick={() => this.setModalAddCompensationIsOpen(true)}
                                    startIcon={<NoteAddIcon/>}
                            >
                                Ajouter un barème
                            </Button>
                        </Grid>
                    </Grid>

                </Grid>

                <AddCompensationDialog addCompensationDialogIsOpen={this.state.modalAddCompensationIsOpen}
                                       handleAddCompensationDialogIsOpen={this.setModalAddCompensationIsOpen}
                                       doUpdate={this.doUpdate}
                />
                <DetailsCompensationDialog modalCompensationDetailsId={this.state.modalCompensationDetailsId}
                                           handleModalCompensationDetailsId={this.handleModalCompensationDetailsId}
                                           doUpdate={this.doUpdate}
                />
            </div>
        )
    }
}

export default Compensation;