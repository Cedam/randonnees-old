import React from "react";
import {Button, Grid, Table, TableBody, TableCell, TableContainer, TablePagination, TableRow} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import EnhancedTableToolbar from "../../../../expense/EnhancedTableComponents/EnhancedTableToolbar";
import EnhancedTableHead from "../../../../expense/EnhancedTableComponents/EnhancedTableHead";
import AddPlaceDialog from "../../../../expense/ExpenseDialogs/AddPlaceDialog";
import DetailsPlaceDialog from "../../../../expense/ExpenseDialogs/DetailsPlaceDialog";
import MergePlacesDialog from "../../../../expense/ExpenseDialogs/MergePlacesDialog";
import NoteAddIcon from "@material-ui/icons/NoteAddOutlined";
import MergeTypeIcon from "@material-ui/icons/MergeType";
import PlaceService from "../../../../../services/PlaceService";

/**
 * Partie 'Place' du composant 'Notes de frais' de la page d'administration.
 */
class Place extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            page: 0, // Page actuellement choisie
            rowsPerPage: 8, // Nombre d'elements à afficher par page
            order: 'asc', // Ordre actuellement choisi
            orderBy: 'name', // En-tête du tableau actuellement ordonnée
            allPlaces: [], // Liste de toutes les places
            paginationTotalElement: 0, // Nombre d'élement total, afin de gérer les calculs de pagination
            emptyRows: 10, // Nombre de ligne vide à afficher

            modalAddPlaceIsOpen: false, // Doit-on afficher le dialogue d'ajout d'une place

            modalPlaceDetailsId: -1, // Id de la place dont on doit afficher les détails

            modalMergePlacesIsOpen: false // Doit-on afficher le dialogue de fusion de places
        };

        this.doUpdate = this.doUpdate.bind(this);
        this.handleRequestSort = this.handleRequestSort.bind(this);
        this.handleChangeRowsPerPage = this.handleChangeRowsPerPage.bind(this);
        this.handleChangePage = this.handleChangePage.bind(this);
        this.updateAllPlacesAndPagination = this.updateAllPlacesAndPagination.bind(this);

        this.setModalAddPlaceIsOpen = this.setModalAddPlaceIsOpen.bind(this);
        this.handleModalPlaceDetailsId = this.handleModalPlaceDetailsId.bind(this);
        this.setModalMergePlacesIsOpen = this.setModalMergePlacesIsOpen.bind(this);
    }

    componentDidMount() {
        this.doUpdate();
    }

    doUpdate() {
        PlaceService.getAllPlacesPage(this.state.page, this.state.rowsPerPage, this.state.order, this.state.orderBy,
            this.updateAllPlacesAndPagination);
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.page !== this.state.page ||
            prevState.rowsPerPage !== this.state.rowsPerPage ||
            prevState.order !== this.state.order ||
            prevState.orderBy !== this.state.orderBy) {
            this.doUpdate();
        }
    }

    // Fonction permettant de mettre à jour les informations lors de la récupération des distances
    updateAllPlacesAndPagination(newPlaces, newPaginationTotalElement) {
        // Si la page demandée est > 0 et que la liste retournée est vide, il faut remettre page à 0
        if (this.state.page > 0 && newPlaces.length === 0) {
            this.setState({page: 0});
        } else {
            this.setState({allPlaces: newPlaces});
            this.setState({emptyRows: this.state.rowsPerPage - Math.min(this.state.rowsPerPage, newPlaces.length)});
            this.setState({paginationTotalElement: newPaginationTotalElement});
        }
    }

    setModalAddPlaceIsOpen(isOpen) {
        this.setState({modalAddPlaceIsOpen: isOpen});
    }

    setModalMergePlacesIsOpen(isOpen) {
        this.setState({modalMergePlacesIsOpen: isOpen});
    }

    handleRequestSort(event, property) {
        const isAsc = this.state.orderBy === property && this.state.order === 'asc';

        this.setState({order: isAsc ? 'desc' : 'asc', orderBy: property});
    }

    handleChangeRowsPerPage(event) {
        this.setState({rowsPerPage: parseInt(event.target.value, 10), page: 0});
    }

    handleChangePage(event, newPage) {
        this.setState({page: newPage});
    }

    handleModalPlaceDetailsId(idPlace) {
        this.setState({modalPlaceDetailsId: idPlace});
    }

    render() {

        const headCells = [
            {id: 'name', label: 'Nom de la place'},
        ];

        return (
            <div style={{"marginTop": "15px"}}>
                <Paper>
                    <EnhancedTableToolbar title={"Mes places"}/>
                    <TableContainer>
                        <Table
                            size={'medium'}
                        >
                            <EnhancedTableHead
                                order={this.state.order}
                                orderBy={this.state.orderBy}
                                onRequestSort={this.handleRequestSort}
                                rowCount={this.state.allPlaces.length}
                                headCells={headCells}
                            />
                            <TableBody>
                                {this.state.allPlaces.map((row, index) => {
                                    const labelId = `enhanced-table-checkbox-places-${index}`;

                                    return (
                                        <TableRow
                                            hover
                                            onClick={() => this.handleModalPlaceDetailsId(row.id)}
                                            key={row.id}
                                        >
                                            <TableCell component="th" id={labelId} scope="row" align="left"
                                                       padding="default">{row.name}</TableCell>
                                        </TableRow>
                                    )
                                })}

                                {this.state.emptyRows > 0 && (
                                    <TableRow style={{height: 53 * this.state.emptyRows}}>
                                        <TableCell colSpan={6}/>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        rowsPerPageOptions={[4, 8, 16]}
                        component="div"
                        count={this.state.paginationTotalElement}
                        rowsPerPage={this.state.rowsPerPage}
                        page={this.state.page}
                        onChangePage={this.handleChangePage}
                        onChangeRowsPerPage={this.handleChangeRowsPerPage}
                        labelRowsPerPage="Lignes par page : "
                    />
                </Paper>
                <Grid
                    container
                    direction="row"
                    justify="center"
                    alignItems="center"
                >
                    <Grid container justify="center" alignItems="center" spacing={1} style={{"marginTop": "15px"}}>
                        <Grid container item justify="center" alignItems="center" xs={12} sm={3} md={3}>
                            <Button variant="contained"
                                    color="primary"
                                    onClick={() => this.setModalAddPlaceIsOpen(true)}
                                    startIcon={<NoteAddIcon/>}
                            >
                                Ajouter une place
                            </Button>
                        </Grid>

                        <Grid container item justify="center" alignItems="center" xs={12} sm={3} md={3}>
                            <Button variant="contained"
                                    color="default"
                                    onClick={() => this.setModalMergePlacesIsOpen(true)}
                                    startIcon={<MergeTypeIcon/>}
                            >
                                Fusionner des doublons
                            </Button>
                        </Grid>
                    </Grid>
                </Grid>
                <AddPlaceDialog addPlaceDialogIsOpen={this.state.modalAddPlaceIsOpen}
                                handleAddPlaceDialogIsOpen={this.setModalAddPlaceIsOpen}
                                doUpdate={this.doUpdate}
                />
                <DetailsPlaceDialog modalPlaceDetailsId={this.state.modalPlaceDetailsId}
                                    handleModalPlaceDetailsId={this.handleModalPlaceDetailsId}
                                    doUpdate={this.doUpdate}
                />
                <MergePlacesDialog mergePlacesDialogIsOpen={this.state.modalMergePlacesIsOpen}
                                   handleMergePlacesDialogIsOpen={this.setModalMergePlacesIsOpen}
                                   doUpdate={this.doUpdate}
                                   allPlaces={this.state.allPlaces}
                />
            </div>
        )
    }
}

export default Place;