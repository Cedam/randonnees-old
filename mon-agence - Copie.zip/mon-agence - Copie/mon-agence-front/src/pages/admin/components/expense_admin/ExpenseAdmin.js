import React from "react";
import {AppBar, Container, Tab, Tabs} from "@material-ui/core";
import Distance from "./components/Distance";
import Place from "./components/Place";
import MileageAllowance from "./components/Compensation";

function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

/**
 * Composant 'Notes de frais' de la page d'administration.
 */
class ExpenseAdmin extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            value: 0,
        };

        this.handleTabsChange = this.handleTabsChange.bind(this);
    }

    handleTabsChange(event, newValue) {
        this.setState({value: newValue});
    }

    render() {

        let tabsTab = [];
        let tabComponent = [];

        // Initialisation des Tabs relatifs aux Places
        tabsTab.push(<Tab value={tabsTab.length} label={"Places"} {...a11yProps(tabsTab.length)}
                          key={"simple-expense-tab-" + tabsTab.length}/>);
        tabComponent.push(
            <Container key={"expenseTabComponent-" + tabsTab.length}>
                <Place/>
            </Container>
        );

        // Initialisation des Tabs relatifs aux Distances
        tabsTab.push(<Tab value={tabsTab.length} label={"Distances"} {...a11yProps(tabsTab.length)}
                          key={"simple-expense-tab-" + tabsTab.length}/>);
        tabComponent.push(
            <Container key={"expenseTabComponent-" + tabsTab.length}>
                <Distance/>
            </Container>
        );

        // Initialisation des Tabs relatifs aux Indemnités kilométrique
        tabsTab.push(<Tab value={tabsTab.length} label={"Indemnités kilométrique"} {...a11yProps(tabsTab.length)}
                          key={"simple-expense-tab-" + tabsTab.length}/>);
        tabComponent.push(
            <Container key={"expenseTabComponent-" + tabsTab.length}>
                <MileageAllowance/>
            </Container>
        );

        return (
            <Container>
                <AppBar position="static" style={{marginTop: "10px"}}>
                    <Tabs value={this.state.value} onChange={this.handleTabsChange} aria-label="simple tabs example"
                          centered indicatorColor={"primary"}>
                        {tabsTab.map((tab, index) => {
                            return tab;
                        })}
                    </Tabs>
                </AppBar>

                {tabComponent.map((component, index) => {
                    return this.state.value === index ? component : null;
                })}

            </Container>
        );
    }
}

export default ExpenseAdmin;