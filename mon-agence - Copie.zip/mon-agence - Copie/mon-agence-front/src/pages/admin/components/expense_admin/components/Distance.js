import React from "react";
import {Button, Grid, Table, TableBody, TableCell, TableContainer, TablePagination, TableRow} from "@material-ui/core";
import Paper from "@material-ui/core/Paper";
import EnhancedTableToolbar from "../../../../expense/EnhancedTableComponents/EnhancedTableToolbar";
import EnhancedTableHead from "../../../../expense/EnhancedTableComponents/EnhancedTableHead";
import AddDistanceDialog from "../../../../expense/ExpenseDialogs/AddDistanceDialog";
import DetailsDistanceDialog from "../../../../expense/ExpenseDialogs/DetailsDistanceDialog";
import NoteAddIcon from "@material-ui/icons/NoteAddOutlined";
import DistanceService from "../../../../../services/DistanceService";

/**
 * Partie 'Distance' du composant 'Notes de frais' de la page d'administration.
 */
class Distance extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            page: 0, // Page actuellement choisie
            rowsPerPage: 8, // Nombre d'elements à afficher par page
            order: 'asc', // Ordre actuellement choisi
            orderBy: 'value', // En-tête du tableau actuellement ordonnée
            allDistances: [], // Liste de toutes les distances
            paginationTotalElement: 0, // Nombre d'élement total, afin de gérer les calculs de pagination
            emptyRows: 10, // Nombre de ligne vide à afficher

            modalAddDistanceIsOpen: false, // Doit-on afficher le dialogue d'ajout d'une place
            modalDistanceDetailsId: -1 // Id de la distance dont on doit afficher le détail
        };

        this.doUpdate = this.doUpdate.bind(this);
        this.handleRequestSort = this.handleRequestSort.bind(this);
        this.handleChangeRowsPerPage = this.handleChangeRowsPerPage.bind(this);
        this.handleChangePage = this.handleChangePage.bind(this);
        this.updateAllDistancesAndPagination = this.updateAllDistancesAndPagination.bind(this);
        this.setModalAddDistanceIsOpen = this.setModalAddDistanceIsOpen.bind(this);
        this.handleModalDistanceDetailsId = this.handleModalDistanceDetailsId.bind(this);
    }

    componentDidMount() {
        this.doUpdate();
    }

    doUpdate() {
        DistanceService.getAllDistances(this.state.page, this.state.rowsPerPage, this.state.order, this.state.orderBy,
            this.updateAllDistancesAndPagination);
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.page !== this.state.page ||
            prevState.rowsPerPage !== this.state.rowsPerPage ||
            prevState.order !== this.state.order ||
            prevState.orderBy !== this.state.orderBy) {
            this.doUpdate();
        }
    }

    // Fonction permettant de mettre à jour les informations lors de la récupération des distances
    updateAllDistancesAndPagination(newDistances, newPaginationTotalElement) {
        // Si la page demandée est > 0 et que la liste retournée est vide, il faut remettre page à 0
        if (this.state.page > 0 && newDistances.length === 0) {
            this.setState({page: 0});
        } else {
            this.setState({allDistances: newDistances});
            this.setState({emptyRows: this.state.rowsPerPage - Math.min(this.state.rowsPerPage, newDistances.length)});
            this.setState({paginationTotalElement: newPaginationTotalElement});
        }
    }

    setModalAddDistanceIsOpen(isOpen) {
        this.setState({modalAddDistanceIsOpen: isOpen});
    }

    handleModalDistanceDetailsId(idDistance) {
        this.setState({modalDistanceDetailsId: idDistance});
    }

    handleRequestSort(event, property) {
        const isAsc = this.state.orderBy === property && this.state.order === 'asc';

        this.setState({order: isAsc ? 'desc' : 'asc', orderBy: property});
    }

    handleChangeRowsPerPage(event) {
        this.setState({rowsPerPage: parseInt(event.target.value, 10), page: 0});
    }

    handleChangePage(event, newPage) {
        this.setState({page: newPage});
    }

    render() {

        const headCells = [
            {id: 'placeStart.name', label: 'Place A'},
            {id: 'placeEnd.name', label: 'Place B'},
            {id: 'value', label: 'Distance (en km)'},
        ];

        return (
            <div style={{"marginTop": "15px"}}>
                <Paper>
                    <EnhancedTableToolbar title={"Mes distances"}/>
                    <TableContainer>
                        <Table
                            size={'medium'}
                        >
                            <EnhancedTableHead
                                order={this.state.order}
                                orderBy={this.state.orderBy}
                                onRequestSort={this.handleRequestSort}
                                rowCount={this.state.allDistances.length}
                                headCells={headCells}
                            />
                            <TableBody>
                                {this.state.allDistances.map((row, index) => {
                                    const labelId = `enhanced-table-checkbox-distances-${index}`;

                                    return (
                                        <TableRow
                                            hover
                                            onClick={() => this.handleModalDistanceDetailsId(row.id)}
                                            key={row.id}
                                        >
                                            <TableCell component="th" id={labelId} scope="row" align="left"
                                                       padding="default">{row.placeStart.name}</TableCell>
                                            <TableCell align="left"
                                                       padding="default">{row.placeEnd.name}</TableCell>
                                            <TableCell align="left"
                                                       padding="default">{row.value}</TableCell>
                                        </TableRow>
                                    )
                                })}

                                {this.state.emptyRows > 0 && (
                                    <TableRow style={{height: 53 * this.state.emptyRows}}>
                                        <TableCell colSpan={6}/>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        rowsPerPageOptions={[4, 8, 16]}
                        component="div"
                        count={this.state.paginationTotalElement}
                        rowsPerPage={this.state.rowsPerPage}
                        page={this.state.page}
                        onChangePage={this.handleChangePage}
                        onChangeRowsPerPage={this.handleChangeRowsPerPage}
                        labelRowsPerPage="Lignes par page : "
                    />
                </Paper>

                <Grid
                    container
                    direction="row"
                    justify="center"
                    alignItems="center"
                >
                    <Grid container justify="center" alignItems="center" spacing={1} style={{"marginTop": "15px"}}>
                        <Grid container item justify="center" alignItems="center" xs={12} sm={6} md={3}>
                            <Button variant="contained"
                                    color="primary"
                                    onClick={() => this.setModalAddDistanceIsOpen(true)}
                                    disabled={this.props.disabled}
                                    startIcon={<NoteAddIcon/>}
                            >
                                Ajouter une distance
                            </Button>
                        </Grid>
                    </Grid>
                </Grid>

                <AddDistanceDialog addDistanceDialogIsOpen={this.state.modalAddDistanceIsOpen}
                                   handleAddDistanceDialogIsOpen={this.setModalAddDistanceIsOpen}
                                   doUpdate={this.doUpdate}
                />
                <DetailsDistanceDialog modalDistanceDetailsId={this.state.modalDistanceDetailsId}
                                       handleModalDistanceDetailsId={this.handleModalDistanceDetailsId}
                                       doUpdate={this.doUpdate}
                />
            </div>
        )
    }
}

export default Distance;