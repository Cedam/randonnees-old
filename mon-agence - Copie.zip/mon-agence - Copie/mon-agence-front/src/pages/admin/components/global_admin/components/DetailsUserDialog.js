import React from "react";
import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    Divider,
    Grid,
    IconButton,
    TextField
} from "@material-ui/core";
import DeleteIcon from '@material-ui/icons/Delete';
import UserService from "../../../../../services/UserService";
import DeleteUserDialog from "./DeleteUserDialog";

/**
 * Composant permettant l'affichage du détails d'un utilisateur choisit.
 */
class DetailsUserDialog extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isEditable: false, // Permet de savoir si on est en mode édition ou non

            deleteDialogIsOpen: false, // Permet de savoir si le dialog de suppression d'un utilisateur doit être ouvert

            username: '',
            firstname: '',
            lastname: '',
        }

        // Fonction gérant l'initialisation du formulaire
        this.handleInitUser = this.handleInitUser.bind(this);

        // Fonction gérant l'état d'ouverture du dialogue de suppression d'un utilisateur
        this.handleDeleteDialogIsOpen = this.handleDeleteDialogIsOpen.bind(this);

        // Fonction permettant de clean le formulaire
        this.cleanForms = this.cleanForms.bind(this);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        // Si l'id du user à changé
        // et qu'il est différent de -1
        // on récupère les données sur l'API
        if (prevProps.modalUserDetailsId !== this.props.modalUserDetailsId && this.props.modalUserDetailsId !== -1) {
            UserService.getUserById(this.props.modalUserDetailsId, this.handleInitUser);
        }

        if (prevProps.modalUserDetailsId !== this.props.modalUserDetailsId && this.props.modalUserDetailsId === -1) {
            this.cleanForms();
        }
    }

    handleInitUser(newUser) {
        this.setState({
            username: newUser.username,
            firstname: newUser.firstname,
            lastname: newUser.lastname,
        });
    }

    handleDeleteDialogIsOpen(deleteDialogIsOpen) {
        this.setState({deleteDialogIsOpen: deleteDialogIsOpen});
    }

    cleanForms() {
        this.setState({
            username: '',
            firstname: '',
            lastname: '',
        });
    }

    render() {
        return (
            <Container>
                <Dialog open={this.props.modalUserDetailsId !== -1}
                        onClose={() => this.props.handleModalUserDetailsId(-1)}
                        aria-labelledby="form-dialog-detailsUserDialog" fullWidth={true} maxWidth={"md"}
                >
                    <DialogTitle id="form-dialog-detailsUserDialog">Détails de l'utilisateur</DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            Informations relatives à l'utilisateur sélectionné.
                        </DialogContentText>

                        <Divider/>

                        <Grid container>
                            <div
                                style={{minHeight: '450px', minWidth: '100%'}}
                            >
                                <Grid container>
                                    <Grid container justify="center" alignItems="center" spacing={1}>
                                        <Grid item xs={12} md={6}>
                                            <TextField
                                                value={this.state.lastname}
                                                label="Nom de l'utilisateur *"
                                                fullWidth
                                                // onChange={this.}
                                                style={{"marginTop": 20 + "px"}}
                                                variant="outlined"
                                                disabled={!this.state.isEditable}
                                            />
                                        </Grid>
                                        <Grid item xs={12} md={6}>
                                            <TextField
                                                value={this.state.firstname}
                                                label="Prénom de l'utilisateur *"
                                                fullWidth
                                                // onChange={this.}
                                                style={{"marginTop": 20 + "px"}}
                                                variant="outlined"
                                                disabled={!this.state.isEditable}
                                            />
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid container>
                                    <Grid container justify="center" alignItems="center" spacing={1}>
                                        <Grid item xs={12} md={6}>
                                            <TextField
                                                value={this.state.username}
                                                label="Nom de compte de l'utilisateur *"
                                                fullWidth
                                                // onChange={this.}
                                                style={{"marginTop": 20 + "px"}}
                                                variant="outlined"
                                                disabled={!this.state.isEditable}
                                            />
                                        </Grid>
                                        <Grid item xs={12} md={6}>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </div>
                        </Grid>
                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleModalUserDetailsId(-1)} color="primary">
                            Retour
                        </Button>
                        <IconButton aria-label="delete"
                                    onClick={() => this.handleDeleteDialogIsOpen(true)}
                                    color="primary"
                        >
                            <DeleteIcon/>
                        </IconButton>
                    </DialogActions>
                </Dialog>
                <DeleteUserDialog deleteDialogIsOpen={this.state.deleteDialogIsOpen}
                                  handleDeleteDialogIsOpen={this.handleDeleteDialogIsOpen}
                                  userId={this.props.modalUserDetailsId}
                                  doUpdate={this.props.doUpdate}
                                  handleModalUserDetailsId={this.props.handleModalUserDetailsId}
                />
            </Container>
        );
    }
}

export default DetailsUserDialog;