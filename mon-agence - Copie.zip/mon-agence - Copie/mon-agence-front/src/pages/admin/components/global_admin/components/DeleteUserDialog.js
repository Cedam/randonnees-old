import React from 'react';

import {
    Button,
    Container,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle
} from '@material-ui/core';
import UserService from "../../../../../services/UserService";

/**
 * Composant permettant l'affichage d'une boite demandant la confirmation de suppression d'un utilisateur.
 */
class DeleteUserDialog extends React.Component {
    constructor(props) {
        super(props);

        this.deleteUser = this.deleteUser.bind(this);
    }

    deleteUser() {
        UserService.deleteUserById(this.props.userId, this.props.handleDeleteDialogIsOpen, this.props.handleModalUserDetailsId, this.props.doUpdate);
    }

    render() {
        return (
            <Container>
                <Dialog open={this.props.deleteDialogIsOpen} onClose={() => this.props.handleDeleteDialogIsOpen(false)}
                        aria-labelledby="form-dialog-deleteUserDialog" fullWidth={true} maxWidth={"xs"}
                >
                    <DialogTitle id="form-dialog-deleteUserDialog">
                        Suppression de l'utilisateur
                    </DialogTitle>

                    <DialogContent>
                        {/* PHRASE D'EXPLICATION */}
                        <DialogContentText>
                            <span >
                                Etes-vous sûr de vouloir supprimer cet utilisateur ainsi que toutes ses informations ?
                                <br/>
                                <b style={{color: "#8B0000"}}> Cette action est irreversible ! </b>
                            </span>
                        </DialogContentText>
                    </DialogContent>
                    {/* Boutons d'actions */}
                    <DialogActions>
                        <Button onClick={() => this.props.handleDeleteDialogIsOpen(false)} color="primary">
                            Retour
                        </Button>
                        <Button onClick={() => this.deleteUser()} color="secondary">
                            Confirmer
                        </Button>
                    </DialogActions>
                </Dialog>
            </Container>
        );
    }
}

export default DeleteUserDialog;