import React from "react";
import Paper from "@material-ui/core/Paper";
import EnhancedTableToolbar from "../../../expense/EnhancedTableComponents/EnhancedTableToolbar";
import {Table, TableBody, TableCell, TableContainer, TablePagination, TableRow} from "@material-ui/core";
import EnhancedTableHead from "../../../expense/EnhancedTableComponents/EnhancedTableHead";
import DetailsUserDialog from "./components/DetailsUserDialog";
import UserService from "../../../../services/UserService";

/**
 * Partie 'Comptes utilisateurs' de la page d'administration.
 */
class UserList extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            order: 'asc', // Ordre actuellement choisi
            orderBy: 'username', // En-tête du tableau actuellement ordonné
            paginationTotalElement: 0, // Nombre d'élement total, afin de gérer les calculs de pagination
            rowsPerPage: 8, // Nombre d'elements à afficher par page
            page: 0,// Page actuellement choisie

            allUsers: [],

            modalUserDetailsId: -1 // Id du user dont on doit afficher le détail (-1 si il ne faut pas afficher le détail d'un user)
        };

        this.handleRequestSort = this.handleRequestSort.bind(this);
        this.handleChangePage = this.handleChangePage.bind(this);
        this.handleChangeRowsPerPage = this.handleChangeRowsPerPage.bind(this);
        this.handleModalUserDetailsId = this.handleModalUserDetailsId.bind(this);
        this.updateAllUsersAndPagination = this.updateAllUsersAndPagination.bind(this);
        this.doUpdate = this.doUpdate.bind(this);
    }

    componentDidMount() {
        this.doUpdate()
    }

    doUpdate() {
        UserService.getAllUsers(this.state.page, this.state.rowsPerPage, this.state.orderBy, this.state.order, this.updateAllUsersAndPagination);
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.page !== this.state.page ||
            prevState.rowsPerPage !== this.state.rowsPerPage ||
            prevState.order !== this.state.order ||
            prevState.orderBy !== this.state.orderBy) {
            this.doUpdate();
        }
    }

    handleRequestSort(event, property) {
        const isAsc = this.state.orderBy === property && this.state.order === 'asc';

        this.setState({order: isAsc ? 'desc' : 'asc', orderBy: property});
    }

    handleChangePage(event, newPage) {
        this.setState({page: newPage});
    }

    handleChangeRowsPerPage(event) {
        this.setState({rowsPerPage: parseInt(event.target.value, 10), page: 0});
    }

    handleModalUserDetailsId(idUser) {
        this.setState({modalUserDetailsId: idUser});
    }

    updateAllUsersAndPagination(newUsers, newPaginationTotalElement) {
        // Si la page demandée est > 0 et que la liste retournée est vide, il faut remettre page à 0
        if (this.state.page > 0 && newUsers.length === 0) {
            this.setState({page: 0});
        } else {
            this.setState({allUsers: newUsers});
            this.setState({emptyRows: this.state.rowsPerPage - Math.min(this.state.rowsPerPage, newUsers.length)});
            this.setState({paginationTotalElement: newPaginationTotalElement});
        }
    }

    render() {
        const headCells = [
            {id: 'username', label: 'Nom de compte'},
            {id: 'firstname', label: 'Prénom'},
            {id: 'lastname', label: 'Nom'},
        ];

        return (
            <div style={{"marginTop": "15px"}}>
                <Paper>
                    <EnhancedTableToolbar title={"Comptes utilisateurs"}/>
                    <TableContainer>
                        <Table
                            size={'medium'}
                        >
                            <EnhancedTableHead
                                order={this.state.order}
                                orderBy={this.state.orderBy}
                                onRequestSort={this.handleRequestSort}
                                rowCount={this.state.allUsers.length}
                                headCells={headCells}
                            />
                            <TableBody>
                                {this.state.allUsers.map((row, index) => {
                                    const labelId = `enhanced-table-checkbox-compensations-${index}`;

                                    return (
                                        <TableRow
                                            hover
                                            onClick={() => this.handleModalUserDetailsId(row.id)}
                                            key={row.id}
                                        >
                                            <TableCell component="th" id={labelId} scope="row" align="left"
                                                       padding="default">{row.username}</TableCell>
                                            <TableCell align="left"
                                                       padding="default">{row.firstname}</TableCell>
                                            <TableCell align="left"
                                                       padding="default">{row.lastname}</TableCell>
                                        </TableRow>
                                    )
                                })}

                                {this.state.emptyRows > 0 && (
                                    <TableRow style={{height: 53 * this.state.emptyRows}}>
                                        <TableCell colSpan={6}/>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        rowsPerPageOptions={[4, 8, 16]}
                        component="div"
                        count={this.state.paginationTotalElement}
                        rowsPerPage={this.state.rowsPerPage}
                        page={this.state.page}
                        onChangePage={this.handleChangePage}
                        onChangeRowsPerPage={this.handleChangeRowsPerPage}
                        labelRowsPerPage="Lignes par page : "
                    />
                </Paper>
                <DetailsUserDialog modalUserDetailsId={this.state.modalUserDetailsId}
                                   handleModalUserDetailsId={this.handleModalUserDetailsId}
                                   doUpdate={this.doUpdate}
                />
            </div>
        );
    }

}

export default UserList;